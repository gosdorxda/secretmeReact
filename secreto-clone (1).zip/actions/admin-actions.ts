"use server"

import { getSupabaseServer } from "@/lib/supabase/server"
import { z } from "zod"

// Validasi form tambah admin
const addAdminSchema = z.object({
  email: z.string().email("Email tidak valid"),
  password: z.string().min(8, "Password minimal 8 karakter"),
  role: z.enum(["admin", "super_admin"]).default("admin"),
})

export async function addAdmin(formData: FormData) {
  const supabase = getSupabaseServer()

  // Dapatkan session pengguna saat ini
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return { error: "Tidak ada session pengguna" }
  }

  // Cek apakah pengguna saat ini adalah admin
  const { data: currentAdmin, error: adminCheckError } = await supabase
    .from("admins")
    .select("role")
    .eq("id", session.user.id)
    .single()

  if (adminCheckError || !currentAdmin) {
    return { error: "Anda tidak memiliki izin untuk menambahkan admin" }
  }

  // Hanya super_admin yang dapat menambahkan admin baru
  if (currentAdmin.role !== "super_admin") {
    return { error: "Hanya super admin yang dapat menambahkan admin baru" }
  }

  // Validasi input
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const role = (formData.get("role") as string) || "admin"

  const result = addAdminSchema.safeParse({ email, password, role })
  if (!result.success) {
    return { error: result.error.flatten().fieldErrors }
  }

  try {
    // Buat user baru di Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    })

    if (authError) {
      return { error: authError.message }
    }

    if (!authData.user) {
      return { error: "Gagal membuat user" }
    }

    // Tambahkan user ke tabel admins
    const { error: insertError } = await supabase.from("admins").insert({
      id: authData.user.id,
      email: authData.user.email,
      role,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (insertError) {
      // Rollback: hapus user dari auth jika gagal menambahkan ke tabel admins
      await supabase.auth.admin.deleteUser(authData.user.id)
      return { error: insertError.message }
    }

    return { success: true, message: "Admin berhasil ditambahkan" }
  } catch (error) {
    console.error("Error adding admin:", error)
    return { error: "Terjadi kesalahan saat menambahkan admin" }
  }
}

export async function removeAdmin(adminId: string) {
  const supabase = getSupabaseServer()

  // Dapatkan session pengguna saat ini
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return { error: "Tidak ada session pengguna" }
  }

  // Cek apakah pengguna saat ini adalah super_admin
  const { data: currentAdmin, error: adminCheckError } = await supabase
    .from("admins")
    .select("role")
    .eq("id", session.user.id)
    .single()

  if (adminCheckError || !currentAdmin) {
    return { error: "Anda tidak memiliki izin untuk menghapus admin" }
  }

  if (currentAdmin.role !== "super_admin") {
    return { error: "Hanya super admin yang dapat menghapus admin" }
  }

  // Cek apakah admin yang akan dihapus bukan diri sendiri
  if (adminId === session.user.id) {
    return { error: "Anda tidak dapat menghapus diri sendiri" }
  }

  try {
    // Hapus dari tabel admins
    const { error: deleteError } = await supabase.from("admins").delete().eq("id", adminId)

    if (deleteError) {
      return { error: deleteError.message }
    }

    // Hapus user dari auth
    const { error: authDeleteError } = await supabase.auth.admin.deleteUser(adminId)

    if (authDeleteError) {
      return { error: authDeleteError.message }
    }

    return { success: true, message: "Admin berhasil dihapus" }
  } catch (error) {
    console.error("Error removing admin:", error)
    return { error: "Terjadi kesalahan saat menghapus admin" }
  }
}

