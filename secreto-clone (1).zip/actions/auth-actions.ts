"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { getSupabaseServer } from "@/lib/supabase/server"
import { z } from "zod"

// Ganti implementasi dengan pendekatan yang kompatibel dengan Pages Router
// Gunakan createServerSupabaseClient dari @supabase/auth-helpers-nextjs

// Validasi form register
const registerSchema = z
  .object({
    username: z.string().min(3).max(50),
    email: z.string().email(),
    password: z.string().min(8),
    confirmPassword: z.string().min(8),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  })

// Perbaiki fungsi registerUser untuk mengatasi masalah duplicate key

export async function registerUser(formData: FormData) {
  // Implementasi yang ada...
  // Tidak perlu diubah karena ini adalah server action yang hanya digunakan di App Router
  // Jika ada error, berarti ada file lain yang menggunakan ini di Pages Router
  const username = formData.get("username") as string
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const confirmPassword = formData.get("confirmPassword") as string

  // Validasi input
  const result = registerSchema.safeParse({ username, email, password, confirmPassword })
  if (!result.success) {
    return { error: result.error.flatten().fieldErrors }
  }

  const supabase = getSupabaseServer()

  // Cek apakah username sudah digunakan
  const { data: existingUser, error: checkError } = await supabase
    .from("users")
    .select("username")
    .eq("username", username)
    .maybeSingle()

  if (checkError) {
    console.error("Error checking existing user:", checkError)
    return { error: { general: ["Terjadi kesalahan saat memeriksa username"] } }
  }

  if (existingUser) {
    return { error: { username: ["Username sudah digunakan"] } }
  }

  // Cek apakah email sudah digunakan
  const { data: existingEmail, error: checkEmailError } = await supabase
    .from("users")
    .select("email")
    .eq("email", email)
    .maybeSingle()

  if (checkEmailError) {
    console.error("Error checking existing email:", checkEmailError)
    return { error: { general: ["Terjadi kesalahan saat memeriksa email"] } }
  }

  if (existingEmail) {
    return { error: { email: ["Email sudah digunakan"] } }
  }

  // Daftarkan user dengan Supabase Auth
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username,
        display_name: username,
      },
    },
  })

  if (authError) {
    console.error("Auth error:", authError)
    return { error: { email: [authError.message] } }
  }

  if (!authData.user) {
    return { error: { general: ["Gagal membuat akun"] } }
  }

  try {
    // Auto-confirm the email if needed
    if (!authData.user.email_confirmed_at) {
      const { error: confirmError } = await supabase.auth.admin.updateUserById(authData.user.id, {
        email_confirm: true,
      })

      if (confirmError) {
        console.error("Error confirming email:", confirmError)
        return { error: { general: ["Gagal mengonfirmasi email"] } }
      }
    }

    // Cek apakah user sudah ada di tabel users
    const { data: existingUserRecord, error: existingUserError } = await supabase
      .from("users")
      .select("id")
      .eq("id", authData.user.id)
      .maybeSingle()

    if (existingUserError && existingUserError.code !== "PGRST116") {
      console.error("Error checking existing user record:", existingUserError)
      return { error: { general: ["Terjadi kesalahan saat memeriksa user"] } }
    }

    // Jika user sudah ada di tabel users, tidak perlu insert lagi
    if (existingUserRecord) {
      console.log("User already exists in users table, skipping insert")
      return { success: true }
    }

    // Tambahkan user ke tabel users
    const { error: insertError } = await supabase.from("users").insert({
      id: authData.user.id,
      username,
      email,
      display_name: username,
      is_premium: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (insertError) {
      console.error("Insert user error:", insertError)
      return { error: { general: [insertError.message] } }
    }

    // Buat profil untuk user
    const { error: profileError } = await supabase.from("profiles").insert({
      user_id: authData.user.id,
      theme: "default",
      total_views: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (profileError) {
      console.error("Profile error:", profileError)
      return { error: { general: [profileError.message] } }
    }

    // Buat pengaturan notifikasi default
    const { error: notifSettingError } = await supabase.from("notification_settings").insert({
      user_id: authData.user.id,
      email_enabled: true,
      whatsapp_enabled: false,
      frequency: "instant",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (notifSettingError) {
      console.error("Notification settings error:", notifSettingError)
      return { error: { general: [notifSettingError.message] } }
    }

    return { success: true }
  } catch (error) {
    console.error("Unexpected error:", error)
    return { error: { general: ["Terjadi kesalahan yang tidak terduga"] } }
  }
}

// Validasi form login
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, "Password is required"),
})

// Perbaiki fungsi loginUser untuk mengatasi masalah dengan user yang tidak ada di tabel users

export async function loginUser(formData: FormData) {
  // Implementasi yang ada...
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  // Validasi input
  const result = loginSchema.safeParse({ email, password })
  if (!result.success) {
    return { error: result.error.flatten().fieldErrors }
  }

  const supabase = getSupabaseServer()

  // Login dengan Supabase Auth
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  // Handle specific error for unconfirmed email
  if (error && error.message.includes("Email not confirmed")) {
    // Auto-confirm the email
    const { error: confirmError } = await supabase.auth.admin.updateUserById(data?.user?.id || "", {
      email_confirm: true,
    })

    if (confirmError) {
      console.error("Error confirming email:", confirmError)
      return { error: { general: ["Gagal mengonfirmasi email"] } }
    }

    // Try login again after confirming email
    const { data: confirmedData, error: confirmedError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (confirmedError) {
      console.error("Login error after confirmation:", confirmedError)
      return { error: { general: [confirmedError.message] } }
    }

    if (!confirmedData.user) {
      return { error: { general: ["User tidak ditemukan"] } }
    }

    // Continue with the confirmed user
    data.user = confirmedData.user
  } else if (error) {
    console.error("Login error:", error)
    return { error: { general: [error.message] } }
  }

  if (!data.user) {
    return { error: { general: ["User tidak ditemukan"] } }
  }

  // Periksa apakah user ada di tabel users
  const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", data.user.id).single()

  if (userError) {
    console.error("User data error:", userError)

    // Jika user tidak ditemukan di tabel users, coba buat data user
    if (userError.code === "PGRST116") {
      try {
        // Cek apakah username sudah ada di metadata
        const username = data.user.user_metadata.username || email.split("@")[0]

        // Cek apakah username sudah digunakan
        const { data: existingUser, error: checkError } = await supabase
          .from("users")
          .select("username")
          .eq("username", username)
          .maybeSingle()

        if (checkError) {
          console.error("Error checking existing username:", checkError)
          return { error: { general: ["Terjadi kesalahan saat memeriksa username"] } }
        }

        // Jika username sudah digunakan, tambahkan random suffix
        let finalUsername = username
        if (existingUser) {
          finalUsername = `${username}_${Math.floor(Math.random() * 10000)}`
        }

        const { error: insertError } = await supabase.from("users").insert({
          id: data.user.id,
          username: finalUsername,
          email: data.user.email,
          display_name: data.user.user_metadata.display_name || finalUsername,
          is_premium: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (insertError) {
          console.error("Insert user error:", insertError)
          return { error: { general: ["Gagal membuat data user"] } }
        }

        // Buat profil untuk user
        const { error: profileError } = await supabase.from("profiles").insert({
          user_id: data.user.id,
          theme: "default",
          total_views: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (profileError) {
          console.error("Profile error:", profileError)
          return { error: { general: [profileError.message] } }
        }

        // Buat pengaturan notifikasi default
        const { error: notifSettingError } = await supabase.from("notification_settings").insert({
          user_id: data.user.id,
          email_enabled: true,
          whatsapp_enabled: false,
          frequency: "instant",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (notifSettingError) {
          console.error("Notification settings error:", notifSettingError)
          return { error: { general: [notifSettingError.message] } }
        }
      } catch (error) {
        console.error("Unexpected error:", error)
        return { error: { general: ["Terjadi kesalahan yang tidak terduga"] } }
      }
    } else {
      return { error: { general: ["User tidak ditemukan"] } }
    }
  }

  return { success: true }
}

export async function logoutUser() {
  const supabase = getSupabaseServer()
  await supabase.auth.signOut()
  cookies().delete("supabase-auth-token")
  redirect("/")
}

export async function getCurrentUser() {
  const supabase = getSupabaseServer()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  const { data: user, error } = await supabase.from("users").select("*").eq("id", session.user.id).single()

  if (error || !user) {
    console.error("Error getting current user:", error)
    return null
  }

  return user
}

