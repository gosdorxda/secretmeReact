"use server"

import { getSupabaseServer } from "@/lib/supabase/server"
import { getCurrentUser } from "./auth-actions"
import { z } from "zod"
import { Redis } from "@upstash/redis"
import { Ratelimit } from "@upstash/ratelimit" // Import Ratelimit

// Inisialisasi Redis client
const redis = Redis.fromEnv()

// Validasi form pesan
const messageSchema = z.object({
  content: z.string().min(1).max(1000),
  recipientUsername: z.string().min(1),
})

// Create a new ratelimiter, that allows 5 requests per 10 minutes
const ratelimit = new Ratelimit({
  redis: redis,
  limiter: Ratelimit.slidingWindow(5, "10 m"),
  analytics: true,
})

export async function sendMessage(formData: FormData) {
  const content = formData.get("content") as string
  const recipientUsername = formData.get("recipientUsername") as string

  // Validasi input
  const result = messageSchema.safeParse({ content, recipientUsername })
  if (!result.success) {
    return { error: result.error.flatten().fieldErrors }
  }

  const supabase = getSupabaseServer()

  try {
    // Cari user berdasarkan username
    const { data: recipient, error: recipientError } = await supabase
      .from("users")
      .select("id")
      .eq("username", recipientUsername)
      .single()

    if (recipientError || !recipient) {
      console.error("Error finding recipient:", recipientError)
      return { error: { recipientUsername: ["User tidak ditemukan"] } }
    }

    // Tambahkan rate limiting berdasarkan IP
    // Hapus penggunaan headers dari next/headers
    // Gunakan pendekatan alternatif atau hapus fitur rate limiting untuk sementara
    const { success, reset } = await ratelimit.limit(`send-message:${recipientUsername}`)

    if (!success) {
      const resetTime = new Date(reset * 1000)
      return {
        error: {
          general: [`Terlalu banyak permintaan. Coba lagi setelah ${resetTime.toLocaleTimeString()}`],
        },
      }
    }

    // Kirim pesan
    const { error: messageError } = await supabase.from("messages").insert({
      recipient_id: recipient.id,
      content,
      is_read: false,
      is_public: false,
      created_at: new Date().toISOString(),
    })

    if (messageError) {
      console.error("Error inserting message:", messageError)
      return { error: { general: [messageError.message] } }
    }

    // Tambahkan notifikasi untuk penerima
    await supabase.from("notifications").insert({
      user_id: recipient.id,
      type: "new_message",
      content: "Anda menerima pesan baru",
      is_read: false,
      created_at: new Date().toISOString(),
    })

    // Increment total pesan di Redis untuk statistik real-time
    try {
      await redis.incr(`user:${recipient.id}:message_count`)
    } catch (redisError) {
      console.error("Redis error (non-critical):", redisError)
      // Continue even if Redis fails
    }

    return { success: true }
  } catch (error) {
    console.error("Unexpected error in sendMessage:", error)
    return { error: { general: ["Terjadi kesalahan yang tidak terduga"] } }
  }
}

export async function getMessages(isPublic?: boolean) {
  const user = await getCurrentUser()

  if (!user) {
    return { error: "Unauthorized" }
  }

  const supabase = getSupabaseServer()

  let query = supabase
    .from("messages")
    .select("*, replies(*)")
    .eq("recipient_id", user.id)
    .order("created_at", { ascending: false })

  if (isPublic !== undefined) {
    query = query.eq("is_public", isPublic)
  }

  const { data, error } = await query

  if (error) {
    return { error: error.message }
  }

  return { messages: data }
}

export async function replyToMessage(formData: FormData) {
  const user = await getCurrentUser()

  if (!user) {
    return { error: "Unauthorized" }
  }

  const messageId = formData.get("messageId") as string
  const content = formData.get("content") as string
  const makePublic = formData.get("makePublic") === "true"

  if (!content || !messageId) {
    return { error: "Content and messageId are required" }
  }

  const supabase = getSupabaseServer()

  // Verifikasi bahwa pesan adalah milik user
  const { data: message } = await supabase
    .from("messages")
    .select("id, recipient_id")
    .eq("id", messageId)
    .eq("recipient_id", user.id)
    .single()

  if (!message) {
    return { error: "Message not found or not authorized" }
  }

  // Buat balasan
  const { error: replyError } = await supabase.from("replies").insert({
    message_id: messageId,
    user_id: user.id,
    content,
  })

  if (replyError) {
    return { error: replyError.message }
  }

  // Update status pesan jika perlu
  if (makePublic) {
    await supabase.from("messages").update({ is_public: true }).eq("id", messageId)
  }

  return { success: true }
}

export async function getPublicMessages(username: string) {
  const supabase = getSupabaseServer()

  // Cari user berdasarkan username
  const { data: user } = await supabase.from("users").select("id").eq("username", username).single()

  if (!user) {
    return { error: "User not found" }
  }

  // Ambil pesan publik dan balasannya
  const { data, error } = await supabase
    .from("messages")
    .select(`
      *,
      replies(*)
    `)
    .eq("recipient_id", user.id)
    .eq("is_public", true)
    .order("created_at", { ascending: false })

  if (error) {
    return { error: error.message }
  }

  // Increment view counter
  await supabase
    .from("profiles")
    .update({ total_views: supabase.rpc("increment", { x: 1 }) })
    .eq("user_id", user.id)

  // Juga update di Redis untuk statistik real-time
  await redis.incr(`user:${user.id}:view_count`)

  return { messages: data }
}

