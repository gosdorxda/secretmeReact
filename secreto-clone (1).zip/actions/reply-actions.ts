"use server"

import { getSupabaseServer } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function replyToMessage(formData: FormData) {
  const supabase = getSupabaseServer()

  // Get form data
  const messageId = formData.get("messageId") as string
  const content = formData.get("content") as string
  const recipientUsername = formData.get("recipientUsername") as string

  if (!content || !messageId) {
    return { error: "Content and messageId are required" }
  }

  if (!recipientUsername) {
    return { error: "Recipient username is required" }
  }

  try {
    // Get the recipient user ID from username
    const { data: recipient, error: recipientError } = await supabase
      .from("users")
      .select("id")
      .eq("username", recipientUsername)
      .single()

    if (recipientError || !recipient) {
      console.error("Error finding recipient:", recipientError)
      return { error: "User not found" }
    }

    // Verify that the message exists and belongs to the recipient
    const { data: message, error: messageError } = await supabase
      .from("messages")
      .select("id, recipient_id")
      .eq("id", messageId)
      .eq("recipient_id", recipient.id)
      .single()

    if (messageError || !message) {
      console.error("Error verifying message:", messageError)
      return { error: "Message not found" }
    }

    // Create the reply - use the recipient's user ID for all replies
    // This ensures we're using a valid user ID that exists in the database
    const { error: replyError } = await supabase.from("replies").insert({
      message_id: messageId,
      user_id: recipient.id, // Use recipient's ID for all replies
      content,
      created_at: new Date().toISOString(),
    })

    if (replyError) {
      console.error("Error creating reply:", replyError)
      return { error: replyError.message }
    }

    // Make the message public if it's not already
    const { error: updateError } = await supabase.from("messages").update({ is_public: true }).eq("id", messageId)

    if (updateError) {
      console.error("Error updating message visibility:", updateError)
      // Continue even if this fails
    }

    // Revalidate paths to update UI
    revalidatePath("/dashboard")
    revalidatePath(`/u/${recipientUsername}`)

    return { success: true }
  } catch (error) {
    console.error("Unexpected error in replyToMessage:", error)
    return { error: "An unexpected error occurred" }
  }
}

