"use server"

import { getSupabaseServer } from "@/lib/supabase/server"
import { incrementProfileViews, incrementMessageCount } from "@/lib/redis"

// Fungsi untuk menambah jumlah tayangan profil
export async function incrementProfileViewCount(userId: string) {
  const supabase = getSupabaseServer()

  try {
    // Increment di Redis untuk statistik real-time
    await incrementProfileViews(userId)

    // Increment di database untuk penyimpanan permanen
    // Menggunakan query UPDATE langsung daripada RPC
    const { error } = await supabase
      .from("profiles")
      .update({
        total_views: supabase.rpc("increment_counter", {
          table_name: "profiles",
          column_name: "total_views",
          user_id_value: userId,
        }),
      })
      .eq("user_id", userId)

    if (error) {
      console.error("Error incrementing profile views in database:", error)

      // Fallback jika RPC gagal: gunakan query UPDATE langsung
      const { error: updateError } = await supabase.rpc("increment_counter", {
        table_name: "profiles",
        column_name: "total_views",
        user_id_value: userId,
      })

      if (updateError) {
        console.error("Fallback update also failed:", updateError)

        // Fallback kedua: query UPDATE paling sederhana
        const { error: simpleUpdateError } = await supabase
          .from("profiles")
          .update({
            total_views: supabase.raw("COALESCE(total_views, 0) + 1"),
          })
          .eq("user_id", userId)

        if (simpleUpdateError) {
          console.error("Simple update also failed:", simpleUpdateError)
        }
      }
    }

    return { success: true }
  } catch (error) {
    console.error("Unexpected error in incrementProfileViewCount:", error)
    return { error: "Terjadi kesalahan yang tidak terduga" }
  }
}

// Fungsi untuk menambah jumlah pesan
export async function incrementMessageCounter(userId: string) {
  const supabase = getSupabaseServer()

  try {
    // Increment di Redis untuk statistik real-time
    await incrementMessageCount(userId)

    // Increment di database untuk penyimpanan permanen
    // Menggunakan RPC function yang baru dibuat
    const { data: incrementResult, error: incrementError } = await supabase.rpc("increment_message_count", {
      user_id_param: userId,
    })

    if (incrementError) {
      console.error("Error calling increment_message_count RPC:", incrementError)

      // Fallback to direct update
      const { data: profileData } = await supabase
        .from("profiles")
        .select("total_messages")
        .eq("user_id", userId)
        .single()

      const newCount = (profileData?.total_messages || 0) + 1

      const { error: updateError } = await supabase
        .from("profiles")
        .update({ total_messages: newCount })
        .eq("user_id", userId)

      if (updateError) {
        console.error("Error in fallback update:", updateError)
        return { error: updateError.message }
      } else {
        console.log("Fallback update successful, new count:", newCount)
        return { success: true, newCount }
      }
    }

    console.log("RPC increment successful, new count:", incrementResult)
    return { success: true, newCount: incrementResult }
  } catch (error) {
    console.error("Unexpected error in incrementMessageCounter:", error)
    return { error: "Terjadi kesalahan yang tidak terduga" }
  }
}

// Fungsi untuk mendapatkan statistik profil
export async function getProfileStats(userId: string) {
  const supabase = getSupabaseServer()

  try {
    // Ambil data dari database
    const { data, error } = await supabase
      .from("profiles")
      .select("total_views, total_messages")
      .eq("user_id", userId)
      .single()

    if (error) {
      console.error("Error fetching profile stats from database:", error)
      return {
        stats: {
          profileViews: 0,
          messageCount: 0,
        },
      }
    }

    return {
      stats: {
        profileViews: data?.total_views || 0,
        messageCount: data?.total_messages || 0,
      },
    }
  } catch (error) {
    console.error("Unexpected error in getProfileStats:", error)
    return {
      stats: {
        profileViews: 0,
        messageCount: 0,
      },
    }
  }
}

// Fungsi untuk menambah jumlah tayangan profil dengan metode alternatif
export async function incrementProfileViewDirectly(userId: string) {
  const supabase = getSupabaseServer()

  try {
    // Increment di Redis untuk statistik real-time
    await incrementProfileViews(userId)

    // Dapatkan nilai saat ini
    const { data, error: fetchError } = await supabase
      .from("profiles")
      .select("total_views")
      .eq("user_id", userId)
      .single()

    if (fetchError) {
      console.error("Error fetching current view count:", fetchError)
      return { error: fetchError.message }
    }

    // Increment nilai dan update
    const newCount = (data?.total_views || 0) + 1

    const { error: updateError } = await supabase
      .from("profiles")
      .update({ total_views: newCount })
      .eq("user_id", userId)

    if (updateError) {
      console.error("Error updating view count:", updateError)
      return { error: updateError.message }
    }

    return { success: true, newCount }
  } catch (error) {
    console.error("Unexpected error in incrementProfileViewDirectly:", error)
    return { error: "Terjadi kesalahan yang tidak terduga" }
  }
}

// Fungsi untuk menambah jumlah pesan dengan metode alternatif
export async function incrementMessageCountDirectly(userId: string) {
  const supabase = getSupabaseServer()

  try {
    console.log("incrementMessageCountDirectly called for user ID:", userId)

    // Increment di Redis untuk statistik real-time
    await incrementMessageCount(userId)

    // Gunakan RPC function yang baru dibuat
    const { data: incrementResult, error: incrementError } = await supabase.rpc("increment_message_count", {
      user_id_param: userId,
    })

    if (incrementError) {
      console.error("Error calling increment_message_count RPC:", incrementError)

      // Fallback to direct update
      const { data: profileData } = await supabase
        .from("profiles")
        .select("total_messages")
        .eq("user_id", userId)
        .single()

      console.log("Current message count from database:", profileData?.total_messages)

      const newCount = (profileData?.total_messages || 0) + 1
      console.log("New message count will be:", newCount)

      const { error: updateError } = await supabase
        .from("profiles")
        .update({ total_messages: newCount })
        .eq("user_id", userId)

      if (updateError) {
        console.error("Error updating message count:", updateError)
        return { error: updateError.message }
      }

      console.log("Message count successfully updated to:", newCount)
      return { success: true, newCount }
    }

    console.log("RPC increment successful, new count:", incrementResult)
    return { success: true, newCount: incrementResult }
  } catch (error) {
    console.error("Unexpected error in incrementMessageCountDirectly:", error)
    return { error: "Terjadi kesalahan yang tidak terduga" }
  }
}

