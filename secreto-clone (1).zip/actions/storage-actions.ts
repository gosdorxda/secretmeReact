"use server"
import { getSupabaseAdmin } from "@/lib/supabase/admin"

// Nama bucket untuk penyimpanan file
export const AVATAR_BUCKET = "avatars"
export const MESSAGE_ATTACHMENTS_BUCKET = "message-attachments"

// Perbaiki fungsi initializeStorageBuckets untuk menangani kesalahan dengan lebih baik
export async function initializeStorageBuckets() {
  console.log("[StorageAction] Initializing storage buckets...")

  try {
    // Dapatkan klien admin Supabase
    const supabase = getSupabaseAdmin()

    // Coba buat bucket avatars dengan penanganan kesalahan yang lebih baik
    console.log("[StorageAction] Creating avatar bucket...")
    try {
      const { data, error } = await supabase.storage.createBucket("avatars", {
        public: true,
        fileSizeLimit: 1024 * 1024 * 2, // 2MB
        allowedMimeTypes: ["image/png", "image/jpeg", "image/jpg", "image/webp"],
      })

      if (error) {
        if (error.message.includes("already exists")) {
          console.log("[StorageAction] Avatar bucket already exists")
        } else {
          console.error("[StorageAction] Error creating avatar bucket:", error)
          // Jangan throw error, lanjutkan eksekusi
        }
      } else {
        console.log("[StorageAction] Avatar bucket created successfully")
      }
    } catch (err) {
      console.error("[StorageAction] Exception creating avatar bucket:", err)
      // Jangan throw error, lanjutkan eksekusi
    }

    // Coba buat bucket message-attachments dengan penanganan kesalahan yang lebih baik
    console.log("[StorageAction] Creating message attachments bucket...")
    try {
      const { data, error } = await supabase.storage.createBucket("message-attachments", {
        public: true,
        fileSizeLimit: 1024 * 1024 * 5, // 5MB
        allowedMimeTypes: ["image/png", "image/jpeg", "image/jpg", "image/webp", "application/pdf"],
      })

      if (error) {
        if (error.message.includes("already exists")) {
          console.log("[StorageAction] Message attachments bucket already exists")
        } else {
          console.error("[StorageAction] Error creating message attachments bucket:", error)
          // Jangan throw error, lanjutkan eksekusi
        }
      } else {
        console.log("[StorageAction] Message attachments bucket created successfully")
      }
    } catch (err) {
      console.error("[StorageAction] Exception creating message attachments bucket:", err)
      // Jangan throw error, lanjutkan eksekusi
    }

    // Buat kebijakan RLS untuk bucket
    await createStoragePolicies()

    console.log("[StorageAction] Storage buckets initialization completed")
    return { success: true }
  } catch (error) {
    console.error("[StorageAction] Fatal error initializing storage buckets:", error)
    return { error: error instanceof Error ? error.message : "Unknown error" }
  }
}

// Fungsi untuk membuat kebijakan RLS untuk bucket storage
async function createStoragePolicies() {
  console.log("[StorageAction] Creating storage policies...")
  const supabase = getSupabaseAdmin()

  try {
    // Kebijakan untuk bucket avatars - read policy
    try {
      const { data, error } = await supabase.storage.from(AVATAR_BUCKET).createPolicy("avatars_read_policy", {
        name: "Public Read Access",
        definition: {
          statements: ["SELECT"],
          roles: ["anon", "authenticated"],
        },
      })

      if (error && !error.message.includes("already exists")) {
        console.error("[StorageAction] Error creating avatar read policy:", error)
      }
    } catch (err) {
      console.log("[StorageAction] Avatar read policy might already exist:", err)
    }

    // Kebijakan untuk bucket avatars - write policy
    try {
      const { data, error } = await supabase.storage.from(AVATAR_BUCKET).createPolicy("avatars_write_policy", {
        name: "Authenticated Write Access",
        definition: {
          statements: ["INSERT", "UPDATE", "DELETE"],
          roles: ["authenticated"],
        },
      })

      if (error && !error.message.includes("already exists")) {
        console.error("[StorageAction] Error creating avatar write policy:", error)
      }
    } catch (err) {
      console.log("[StorageAction] Avatar write policy might already exist:", err)
    }

    // Kebijakan untuk bucket message-attachments - read policy
    try {
      const { data, error } = await supabase.storage
        .from(MESSAGE_ATTACHMENTS_BUCKET)
        .createPolicy("message_attachments_read_policy", {
          name: "Public Read Access",
          definition: {
            statements: ["SELECT"],
            roles: ["anon", "authenticated"],
          },
        })

      if (error && !error.message.includes("already exists")) {
        console.error("[StorageAction] Error creating message attachments read policy:", error)
      }
    } catch (err) {
      console.log("[StorageAction] Message attachments read policy might already exist:", err)
    }

    // Kebijakan untuk bucket message-attachments - write policy
    try {
      const { data, error } = await supabase.storage
        .from(MESSAGE_ATTACHMENTS_BUCKET)
        .createPolicy("message_attachments_write_policy", {
          name: "Authenticated Write Access",
          definition: {
            statements: ["INSERT", "UPDATE", "DELETE"],
            roles: ["authenticated"],
          },
        })

      if (error && !error.message.includes("already exists")) {
        console.error("[StorageAction] Error creating message attachments write policy:", error)
      }
    } catch (err) {
      console.log("[StorageAction] Message attachments write policy might already exist:", err)
    }

    console.log("[StorageAction] Storage policies created successfully")
    return true
  } catch (error) {
    console.error("[StorageAction] Error creating storage policies:", error)
    // Jangan throw error di sini, karena kebijakan mungkin sudah ada
    return false
  }
}

// Perbaiki fungsi uploadAvatar untuk menangani kesalahan dengan lebih baik
export async function uploadAvatar(formData: FormData) {
  console.log("[StorageAction] uploadAvatar called")

  try {
    const file = formData.get("file") as File
    const userId = formData.get("userId") as string

    if (!file || !userId) {
      return { error: "File and userId are required" }
    }

    // Konversi File ke ArrayBuffer
    const arrayBuffer = await file.arrayBuffer()

    // Buat nama file unik
    const fileExt = file.name.split(".").pop()
    const fileName = `${userId}-${Date.now()}.${fileExt}`

    // Gunakan admin client untuk melewati RLS
    const supabase = getSupabaseAdmin()

    // Coba unggah file dengan penanganan kesalahan yang lebih baik
    console.log("[StorageAction] Uploading file to avatars bucket:", fileName)
    const { data, error } = await supabase.storage.from("avatars").upload(fileName, arrayBuffer, {
      contentType: file.type,
      cacheControl: "3600",
      upsert: true,
    })

    if (error) {
      console.error("[StorageAction] Error uploading avatar:", error)
      return { error: error.message }
    }

    // Dapatkan URL publik
    console.log("[StorageAction] Getting public URL for file:", fileName)
    const { data: publicUrlData } = supabase.storage.from("avatars").getPublicUrl(fileName)

    console.log("[StorageAction] Public URL:", publicUrlData.publicUrl)
    return { success: true, url: publicUrlData.publicUrl }
  } catch (error) {
    console.error("[StorageAction] Error in uploadAvatar:", error)
    return { error: error instanceof Error ? error.message : "Unknown error" }
  }
}

// Server action untuk menghapus avatar
export async function deleteAvatar(fileName: string) {
  console.log("[StorageAction] deleteAvatar called for file:", fileName)

  try {
    // Ekstrak nama file dari URL
    const fileNameOnly = fileName.includes("/") ? fileName.split("/").pop() : fileName

    if (!fileNameOnly) {
      throw new Error("Invalid file name")
    }

    // Gunakan admin client untuk melewati RLS
    const supabase = getSupabaseAdmin()

    // Hapus file
    const { error } = await supabase.storage.from(AVATAR_BUCKET).remove([fileNameOnly])

    if (error) {
      console.error("[StorageAction] Error deleting avatar:", error)
      throw new Error(error.message)
    }

    return true
  } catch (error) {
    console.error("[StorageAction] Error in deleteAvatar:", error)
    throw error
  }
}

// Server action untuk mengunggah avatar (untuk digunakan dari client)
export async function uploadAvatarAction(formData: FormData) {
  try {
    const file = formData.get("file") as File
    const userId = formData.get("userId") as string

    if (!file || !userId) {
      return { error: "File and userId are required" }
    }

    // Pastikan bucket ada
    await initializeStorageBuckets()

    // Unggah avatar
    const publicUrl = await uploadAvatar(formData)

    // Update user dengan URL avatar baru
    const supabase = getSupabaseAdmin()
    const { error: updateError } = await supabase
      .from("users")
      .update({
        avatar_url: publicUrl.url,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId)

    if (updateError) {
      console.error("[StorageAction] Error updating user with avatar:", updateError)
      return {
        success: true,
        url: publicUrl.url,
        databaseUpdateFailed: true,
        databaseError: updateError.message,
      }
    }

    return { success: true, url: publicUrl.url }
  } catch (error) {
    console.error("[StorageAction] Error in uploadAvatarAction:", error)
    return { error: error instanceof Error ? error.message : "Unknown error" }
  }
}

// Server action untuk menghapus avatar (untuk digunakan dari client)
export async function deleteAvatarAction(fileName: string, userId: string) {
  try {
    if (!fileName || !userId) {
      return { error: "Filename and userId are required" }
    }

    // Hapus avatar
    await deleteAvatar(fileName)

    // Update user untuk menghapus URL avatar
    const supabase = getSupabaseAdmin()
    const { error: updateError } = await supabase
      .from("users")
      .update({
        avatar_url: null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId)

    if (updateError) {
      console.error("[StorageAction] Error updating user after avatar deletion:", updateError)
      return { error: updateError.message }
    }

    return { success: true }
  } catch (error) {
    console.error("[StorageAction] Error in deleteAvatarAction:", error)
    return { error: error instanceof Error ? error.message : "Unknown error" }
  }
}

