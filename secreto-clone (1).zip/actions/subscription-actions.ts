"use server"

import { getSupabaseServer } from "@/lib/supabase/server"
import { getCurrentUser } from "./auth-actions"
import { addDays } from "date-fns"

export async function upgradeToPremium() {
  const user = await getCurrentUser()

  if (!user) {
    return { error: "Unauthorized" }
  }

  // Di sini seharusnya ada integrasi dengan payment gateway
  // Untuk contoh, kita langsung upgrade user ke premium

  const supabase = getSupabaseServer()

  // Set tanggal mulai dan berakhir
  const startsAt = new Date()
  const expiresAt = addDays(startsAt, 30) // 30 hari

  // Update status premium di user
  const { error: userError } = await supabase
    .from("users")
    .update({
      is_premium: true,
      premium_expires_at: expiresAt.toISOString(),
    })
    .eq("id", user.id)

  if (userError) {
    return { error: userError.message }
  }

  // Tambahkan data subscription
  const { error: subscriptionError } = await supabase.from("subscriptions").insert({
    user_id: user.id,
    plan_type: "premium",
    status: "active",
    starts_at: startsAt.toISOString(),
    expires_at: expiresAt.toISOString(),
  })

  if (subscriptionError) {
    return { error: subscriptionError.message }
  }

  return { success: true }
}

export async function cancelPremium() {
  const user = await getCurrentUser()

  if (!user) {
    return { error: "Unauthorized" }
  }

  const supabase = getSupabaseServer()

  // Update status subscription
  const { error: subscriptionError } = await supabase
    .from("subscriptions")
    .update({
      status: "cancelled",
    })
    .eq("user_id", user.id)
    .eq("status", "active")

  if (subscriptionError) {
    return { error: subscriptionError.message }
  }

  // User tetap premium sampai masa berlaku habis
  // Jadi tidak perlu update is_premium di tabel users

  return { success: true }
}

export async function getSubscriptionStatus() {
  const user = await getCurrentUser()

  if (!user) {
    return { error: "Unauthorized" }
  }

  const supabase = getSupabaseServer()

  // Ambil data subscription
  const { data, error } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", user.id)
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(1)
    .single()

  if (error && error.code !== "PGRST116") {
    // PGRST116 adalah kode untuk "no rows returned"
    return { error: error.message }
  }

  return {
    subscription: data,
    isPremium: user.is_premium,
    expiresAt: user.premium_expires_at,
  }
}

