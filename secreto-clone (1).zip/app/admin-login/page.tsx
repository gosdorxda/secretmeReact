"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { getSupabaseClient } from "@/lib/supabase/client"

export default function AdminLoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = getSupabaseClient()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Sign in with Supabase Auth
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (authError) {
        throw authError
      }

      if (!data.user) {
        throw new Error("Login gagal")
      }

      // Check if user is admin
      const { data: adminData, error: adminError } = await supabase
        .from("admins")
        .select("id")
        .eq("id", data.user.id)
        .single()

      if (adminError || !adminData) {
        // Sign out if not admin
        await supabase.auth.signOut()
        throw new Error("Anda tidak memiliki akses admin")
      }

      // Redirect to admin panel
      router.push("/admin-panel")
    } catch (err) {
      console.error("Login error:", err)
      setError(err instanceof Error ? err.message : "Terjadi kesalahan saat login")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-4">
      <Card className="w-full max-w-md neo-brutalism">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <Link href="/" className="flex items-center gap-2 font-heading text-xl">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
                S
              </div>
              <span>Secreto</span>
            </Link>
          </div>
          <CardTitle className="text-2xl font-heading text-center">Admin Login</CardTitle>
          <CardDescription className="text-center font-base">
            Masukkan email dan password admin untuk mengakses panel admin
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="p-3 rounded-md bg-red-100 border-2 border-red-300 text-red-800 text-sm">{error}</div>
          )}
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-heading" htmlFor="email">
                Email Admin
              </label>
              <Input
                id="email"
                type="email"
                placeholder="admin@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-heading" htmlFor="password">
                Password
              </label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" variant="blue" className="w-full" disabled={loading}>
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-t-transparent border-current"></div>
                  <span>Memproses...</span>
                </div>
              ) : (
                "Login"
              )}
            </Button>
          </form>
          <div className="text-center text-sm">
            <Link href="/" className="text-blue-600 hover:underline">
              Kembali ke Beranda
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

