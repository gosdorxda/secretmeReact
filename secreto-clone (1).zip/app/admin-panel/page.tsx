"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AdminUserList } from "@/components/admin/user-list"
import { AdminStats } from "@/components/admin/stats"
import { AdminHeader } from "@/components/admin/header"

export default function AdminPanelPage() {
  const [loading, setLoading] = useState(true)
  const [adminData, setAdminData] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    async function checkAdminStatus() {
      try {
        // Get current session
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        if (sessionError || !session) {
          router.push("/admin-login")
          return
        }

        // Check if user is admin
        const { data: admin, error: adminError } = await supabase
          .from("admins")
          .select("*")
          .eq("id", session.user.id)
          .single()

        if (adminError || !admin) {
          router.push("/unauthorized")
          return
        }

        setAdminData(admin)
      } catch (err) {
        console.error("Error checking admin status:", err)
        setError("Terjadi kesalahan saat memeriksa status admin")
      } finally {
        setLoading(false)
      }
    }

    checkAdminStatus()
  }, [router, supabase])

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push("/admin-login")
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-main border-t-transparent"></div>
          <p className="text-lg font-heading">Memuat...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="p-3 rounded-md bg-red-100 border-2 border-red-300 text-red-800 mb-4">{error}</div>
            <Button asChild variant="blue">
              <Link href="/admin-login">Kembali ke Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-bg">
      <AdminHeader onLogout={handleLogout} adminEmail={adminData?.email} />

      <main className="container mx-auto p-4 max-w-6xl">
        <h1 className="text-3xl font-heading mb-6">Admin Panel</h1>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="w-full neo-brutalism bg-blank h-12">
            <TabsTrigger value="users" className="text-sm font-heading data-[state=active]:bg-main">
              Pengguna
            </TabsTrigger>
            <TabsTrigger value="stats" className="text-sm font-heading data-[state=active]:bg-main">
              Statistik
            </TabsTrigger>
            <TabsTrigger value="messages" className="text-sm font-heading data-[state=active]:bg-main">
              Pesan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <AdminUserList />
          </TabsContent>

          <TabsContent value="stats">
            <AdminStats />
          </TabsContent>

          <TabsContent value="messages">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Moderasi Pesan</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-mtext mb-4">
                  Fitur moderasi pesan memungkinkan Anda untuk melihat dan mengelola pesan yang dilaporkan oleh
                  pengguna.
                </p>
                <div className="p-4 bg-yellow-50 rounded-base border-[3px] border-bw neo-brutalism">
                  <h3 className="text-lg font-heading mb-2">Fitur Sedang Dikembangkan</h3>
                  <p className="text-mtext">Fitur moderasi pesan sedang dalam pengembangan dan akan segera tersedia.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

