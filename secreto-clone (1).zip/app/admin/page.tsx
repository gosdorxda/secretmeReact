"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { addDays } from "date-fns"
import { getSupabaseClient } from "@/lib/supabase/client"

type User = {
  id: string
  username: string
  email: string
  display_name?: string
  is_premium: boolean
  premium_expires_at?: string
  created_at: string
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const router = useRouter()

  // Untuk demo, kita gunakan password sederhana
  const DEMO_ADMIN_PASSWORD = "admin123"

  // Fungsi untuk mengambil data pengguna dari database
  async function fetchUsers() {
    try {
      setLoading(true)
      setError(null)

      const supabase = getSupabaseClient()

      const { data, error } = await supabase
        .from("users")
        .select("id, username, email, display_name, is_premium, premium_expires_at, created_at")
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching users:", error)
        setError("Gagal memuat data pengguna")
        return
      }

      console.log("Fetched users:", data)
      setUsers(data || [])
    } catch (err) {
      console.error("Unexpected error:", err)
      setError("Terjadi kesalahan yang tidak terduga")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    // Cek apakah admin sudah login
    const adminAuth = localStorage.getItem("admin_auth")
    if (adminAuth === "true") {
      setIsAuthenticated(true)
      fetchUsers() // Ambil data pengguna saat komponen dimuat
    }
  }, [])

  async function handleAdminLogin(e: React.FormEvent) {
    e.preventDefault()

    if (adminPassword === DEMO_ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      localStorage.setItem("admin_auth", "true")
      fetchUsers() // Ambil data pengguna setelah login
    } else {
      setError("Password admin salah")
    }
  }

  async function togglePremiumStatus(userId: string, currentStatus: boolean) {
    try {
      setError(null)
      setSuccess(null)

      const supabase = getSupabaseClient()

      // Set tanggal berakhir premium (30 hari dari sekarang)
      const expiresAt = currentStatus ? null : addDays(new Date(), 30).toISOString()

      // Update status premium di database
      const { error: updateError } = await supabase
        .from("users")
        .update({
          is_premium: !currentStatus,
          premium_expires_at: expiresAt,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) {
        console.error("Error updating premium status:", updateError)
        setError("Gagal mengubah status premium: " + updateError.message)
        return
      }

      // Update data di state
      setUsers(
        users.map((user) => {
          if (user.id === userId) {
            return {
              ...user,
              is_premium: !currentStatus,
              premium_expires_at: expiresAt,
            }
          }
          return user
        }),
      )

      setSuccess(`Status premium berhasil ${!currentStatus ? "diaktifkan" : "dinonaktifkan"}`)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      console.error("Error updating premium status:", err)
      setError("Gagal mengubah status premium")
    }
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.display_name && user.display_name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center p-4">
        <Card className="max-w-md w-full" color="bg-blank">
          <CardHeader>
            <CardTitle className="text-center">Admin Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-heading" htmlFor="admin-password">
                  Password Admin
                </label>
                <Input
                  id="admin-password"
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                />
              </div>

              {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{error}</div>}

              <Button type="submit" className="w-full">
                Login
              </Button>

              <div className="text-center text-xs text-mtext">Untuk demo, gunakan password: admin123</div>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 font-heading text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
              S
            </div>
            <span>Secreto</span>
          </Link>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                localStorage.removeItem("admin_auth")
                setIsAuthenticated(false)
              }}
            >
              Logout Admin
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4 max-w-6xl">
        <h1 className="text-3xl font-heading mb-6">Admin Panel</h1>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="w-full neo-brutalism bg-blank h-12">
            <TabsTrigger value="users" className="text-sm font-heading data-[state=active]:bg-main">
              Pengguna
            </TabsTrigger>
            <TabsTrigger value="stats" className="text-sm font-heading data-[state=active]:bg-main">
              Statistik
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <Card color="bg-blank">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Daftar Pengguna</CardTitle>
                <div className="w-64">
                  <Input
                    placeholder="Cari pengguna..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                {error && <div className="rounded-md bg-red-50 p-3 mb-4 text-sm text-red-500">{error}</div>}
                {success && <div className="rounded-md bg-green-50 p-3 mb-4 text-sm text-green-500">{success}</div>}

                {loading ? (
                  <div className="text-center py-8">Memuat data pengguna...</div>
                ) : filteredUsers.length === 0 ? (
                  <div className="text-center py-8 text-mtext">Tidak ada pengguna yang ditemukan.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b-2 border-bw">
                          <th className="py-2 px-4 text-left">Username</th>
                          <th className="py-2 px-4 text-left">Email</th>
                          <th className="py-2 px-4 text-left">Nama</th>
                          <th className="py-2 px-4 text-left">Tgl Daftar</th>
                          <th className="py-2 px-4 text-left">Status Premium</th>
                          <th className="py-2 px-4 text-left">Berlaku Hingga</th>
                          <th className="py-2 px-4 text-left">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredUsers.map((user) => (
                          <tr key={user.id} className="border-b border-gray-200 hover:bg-gray-50">
                            <td className="py-2 px-4">{user.username}</td>
                            <td className="py-2 px-4">{user.email}</td>
                            <td className="py-2 px-4">{user.display_name || "-"}</td>
                            <td className="py-2 px-4">{new Date(user.created_at).toLocaleDateString("id-ID")}</td>
                            <td className="py-2 px-4">
                              <div className="flex items-center gap-2">
                                <div
                                  className={`h-3 w-3 rounded-full ${user.is_premium ? "bg-green-500" : "bg-gray-400"}`}
                                ></div>
                                <span className={`text-sm ${user.is_premium ? "text-green-600" : "text-gray-600"}`}>
                                  {user.is_premium ? "Premium" : "Free"}
                                </span>
                              </div>
                            </td>
                            <td className="py-2 px-4">
                              {user.premium_expires_at
                                ? new Date(user.premium_expires_at).toLocaleDateString("id-ID")
                                : "-"}
                            </td>
                            <td className="py-2 px-4">
                              <Button
                                variant={user.is_premium ? "outline" : "blue"}
                                size="sm"
                                onClick={() => togglePremiumStatus(user.id, user.is_premium)}
                              >
                                {user.is_premium ? "Nonaktifkan Premium" : "Aktifkan Premium"}
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stats">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Statistik Aplikasi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blue-50">
                    <div className="text-3xl font-heading">{users.length}</div>
                    <div className="text-sm text-mtext">Total Pengguna</div>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-green-50">
                    <div className="text-3xl font-heading">{users.filter((user) => user.is_premium).length}</div>
                    <div className="text-sm text-mtext">Pengguna Premium</div>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-purple-50">
                    <div className="text-3xl font-heading">
                      {users.length > 0
                        ? Math.round((users.filter((user) => user.is_premium).length / users.length) * 100)
                        : 0}
                      %
                    </div>
                    <div className="text-sm text-mtext">Rasio Konversi Premium</div>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-yellow-50 rounded-base border-[3px] border-bw neo-brutalism">
                  <h2 className="text-xl font-heading mb-2">Catatan Admin</h2>
                  <p className="text-mtext">
                    Panel admin ini memungkinkan Anda untuk mengelola status premium pengguna secara manual. Dalam
                    aplikasi produksi, Anda mungkin ingin menambahkan fitur lain seperti:
                  </p>
                  <ul className="list-disc list-inside mt-2 text-mtext">
                    <li>Moderasi pesan</li>
                    <li>Pengelolaan konten</li>
                    <li>Laporan dan analitik yang lebih detail</li>
                    <li>Manajemen pembayaran</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

