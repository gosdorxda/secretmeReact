import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { content, recipientUsername, is_public = true } = body

    if (!content || content.trim() === "") {
      return NextResponse.json({ error: "Pesan tidak boleh kosong" }, { status: 400 })
    }

    if (!recipientUsername) {
      return NextResponse.json({ error: "Username penerima diperlukan" }, { status: 400 })
    }

    const supabase = getSupabaseServer()

    // Cari user berdasarkan username
    const { data: recipient, error: recipientError } = await supabase
      .from("users")
      .select("id")
      .eq("username", recipientUsername)
      .single()

    if (recipientError || !recipient) {
      console.error("Error finding recipient:", recipientError)
      return NextResponse.json({ error: "User tidak ditemukan" }, { status: 404 })
    }

    // Kirim pesan
    const { data: messageData, error: messageError } = await supabase
      .from("messages")
      .insert({
        recipient_id: recipient.id,
        content: content.trim(),
        is_read: false,
        is_public: is_public,
        created_at: new Date().toISOString(),
      })
      .select()

    if (messageError) {
      console.error("Error inserting message:", messageError)
      return NextResponse.json({ error: "Gagal menyimpan pesan: " + messageError.message }, { status: 500 })
    }

    // Increment message counter manually
    try {
      console.log("API route: Attempting to increment message count for user ID:", recipient.id)

      // Call the RPC function directly
      const { data: incrementResult, error: incrementError } = await supabase.rpc("increment_message_count", {
        user_id_param: recipient.id,
      })

      if (incrementError) {
        console.error("API route: Error calling increment_message_count RPC:", incrementError)

        // Fallback to direct update
        const { data: profileData } = await supabase
          .from("profiles")
          .select("total_messages")
          .eq("user_id", recipient.id)
          .single()

        const newCount = (profileData?.total_messages || 0) + 1

        const { error: updateError } = await supabase
          .from("profiles")
          .update({ total_messages: newCount })
          .eq("user_id", recipient.id)

        if (updateError) {
          console.error("API route: Error in fallback update:", updateError)
        } else {
          console.log("API route: Fallback update successful, new count:", newCount)
        }
      } else {
        console.log("API route: RPC increment successful, new count:", incrementResult)
      }
    } catch (countError) {
      console.error("API route: Error incrementing message count:", countError)
      // Continue even if counter fails
    }

    // Tambahkan notifikasi untuk penerima
    const { error: notifError } = await supabase.from("notifications").insert({
      user_id: recipient.id,
      type: "new_message",
      content: "Anda menerima pesan baru",
      is_read: false,
      created_at: new Date().toISOString(),
    })

    if (notifError) {
      console.error("Error creating notification (non-critical):", notifError)
      // Continue even if notification creation fails
    }

    return NextResponse.json({ success: true, message: messageData })
  } catch (error) {
    console.error("Unexpected error in API route:", error)
    return NextResponse.json({ error: "Terjadi kesalahan yang tidak terduga" }, { status: 500 })
  }
}

