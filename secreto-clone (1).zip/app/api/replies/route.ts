import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("Received reply request:", body)

    // Basic validation
    const { messageId, content, recipientUsername } = body

    if (!content || typeof content !== "string") {
      console.error("Missing or invalid content:", content)
      return NextResponse.json({ error: "Reply content is required" }, { status: 400 })
    }

    if (!messageId) {
      console.error("Missing messageId:", messageId)
      return NextResponse.json({ error: "Message ID is required" }, { status: 400 })
    }

    if (!recipientUsername) {
      console.error("Missing recipientUsername:", recipientUsername)
      return NextResponse.json({ error: "Recipient username is required" }, { status: 400 })
    }

    const supabase = createServerComponentClient({ cookies })

    // Get the recipient user ID from username
    const { data: recipient, error: recipientError } = await supabase
      .from("users")
      .select("id")
      .eq("username", recipientUsername)
      .single()

    if (recipientError || !recipient) {
      console.error("Error finding recipient:", recipientError)
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Verify that the message exists and belongs to the recipient
    const { data: message, error: messageError } = await supabase
      .from("messages")
      .select("id, recipient_id")
      .eq("id", messageId)
      .eq("recipient_id", recipient.id)
      .single()

    if (messageError || !message) {
      console.error("Error verifying message:", messageError)
      return NextResponse.json({ error: "Message not found" }, { status: 404 })
    }

    // Create the reply - use the recipient's user ID for all replies
    const { data: replyData, error: replyError } = await supabase
      .from("replies")
      .insert({
        message_id: messageId,
        user_id: recipient.id, // Use recipient's ID for all replies
        content,
        created_at: new Date().toISOString(),
      })
      .select()

    if (replyError) {
      console.error("Error creating reply:", replyError)
      return NextResponse.json({ error: replyError.message }, { status: 500 })
    }

    // Make the message public if it's not already
    const { error: updateError } = await supabase.from("messages").update({ is_public: true }).eq("id", messageId)

    if (updateError) {
      console.error("Error updating message visibility:", updateError)
      // Continue even if this fails
    }

    return NextResponse.json({ success: true, reply: replyData })
  } catch (error) {
    console.error("Unexpected error in API route:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}

