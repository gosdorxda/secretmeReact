import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    const supabase = createRouteHandlerClient({ cookies })

    // Increment the view count
    const { data, error } = await supabase.rpc("increment_profile_views", {
      user_id_param: userId,
    })

    if (error) {
      console.error("Error incrementing views:", error)

      // Fallback: try direct update if RPC fails
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ total_views: supabase.sql`total_views + 1` })
        .eq("user_id", userId)

      if (updateError) {
        console.error("Error with fallback update:", updateError)
        return NextResponse.json({ error: "Failed to increment view count" }, { status: 500 })
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Unexpected error:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}

