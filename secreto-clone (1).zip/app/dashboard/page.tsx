"use client"

import type React from "react"

import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Copy, ExternalLink, LogOut, Share2, UserIcon } from "lucide-react"
import { useState, useEffect } from "react"
import { NotificationSystem } from "@/components/notification-system"
import { getSupabaseClient } from "@/lib/supabase/client"
import { MessageList } from "@/components/message-list"
import { useRouter } from "next/navigation"
import { Textarea } from "@/components/ui/textarea"
import { uploadAvatarAction, deleteAvatarAction, initializeStorageBuckets } from "@/actions/profile-actions"

// Import the getProfileStats function
import { getProfileStats } from "@/actions/stats-actions"

type UserType = {
  id: string
  username: string
  display_name?: string
  avatar_url?: string
  email: string
}

type ProfileStatsType = {
  profileViews: number
  messageCount: number
}

type FormDataType = {
  username: string
  displayName: string
  bio: string
  instagram: string
  twitter: string
  tiktok: string
  facebook: string
  linkedin: string
}

export default function DashboardPage() {
  const [user, setUser] = useState<UserType | null>(null)
  const [loading, setLoading] = useState(true)
  const [profileStats, setProfileStats] = useState<ProfileStatsType>({
    profileViews: 0,
    messageCount: 0,
  })
  const router = useRouter()
  const [memberStatus, setMemberStatus] = useState<"Free" | "Premium">("Free")
  const [formData, setFormData] = useState<FormDataType>({
    username: "",
    displayName: "",
    bio: "",
    instagram: "",
    twitter: "",
    tiktok: "",
    facebook: "",
    linkedin: "",
  })
  const [debugInfo, setDebugInfo] = useState<string[]>([])
  const [whatsappEnabled, setWhatsappEnabled] = useState(false)
  const [emailEnabled, setEmailEnabled] = useState(false)

  const addDebugInfo = (info: string) => {
    setDebugInfo((prev) => [...prev, info])
  }

  const refreshUserData = async () => {
    addDebugInfo("Refreshing user data...")
    setLoading(true)
    try {
      const supabase = getSupabaseClient()

      // Get current user
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()

      if (!authUser) {
        console.log("No authenticated user found")
        setLoading(false)
        router.push("/login")
        return
      }

      // Get user data
      const { data: userData } = await supabase.from("users").select("*").eq("id", authUser.id).single()
      setUser(userData)

      // Fetch profile stats
      const { stats } = await getProfileStats(authUser.id)
      setProfileStats(stats)

      // Fetch profile data
      const { data: profileData } = await supabase.from("profiles").select("*").eq("user_id", authUser.id).single()

      if (profileData) {
        setFormData({
          username: userData?.username || "",
          displayName: userData?.display_name || "",
          bio: profileData.bio || "",
          instagram: profileData.instagram || "",
          twitter: profileData.twitter || "",
          tiktok: profileData.tiktok || "",
          facebook: profileData.facebook || "",
          linkedin: profileData.linkedin || "",
        })
      }

      // Fetch member status
      const { data: subscriptionData } = await supabase
        .from("subscriptions")
        .select("status")
        .eq("user_id", authUser.id)
        .single()

      if (subscriptionData && subscriptionData.status === "active") {
        setMemberStatus("Premium")
      } else {
        setMemberStatus("Free")
      }
    } catch (err) {
      console.error("Error:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refreshUserData()
  }, [router])

  const handleLogout = async () => {
    try {
      const supabase = getSupabaseClient()
      await supabase.auth.signOut()
      router.push("/login")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target

    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-main border-t-transparent"></div>
          <p className="text-lg font-heading">Memuat...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-6 p-4">
        <div className="text-center">
          <h1 className="text-3xl font-heading mb-2">Silakan login untuk melihat dashboard</h1>
          <p className="text-mtext mb-6">Anda perlu login terlebih dahulu untuk mengakses dashboard</p>
          <Button asChild variant="blue" size="lg">
            <Link href="/login">Login Sekarang</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-bg">
      <header className="flex h-16 items-center justify-between border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <div className="w-full mx-auto max-w-4xl flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 font-heading text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
              S
            </div>
            <span>Secreto</span>
          </Link>
          <div className="flex items-center gap-4">
            <NotificationSystem userId={user.id} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="h-10 w-10 rounded-full p-0">
                  <Avatar className="h-full w-full border-2 border-bw">
                    <AvatarImage src={user.avatar_url || "/placeholder.svg"} alt="@user" />
                    <AvatarFallback className="bg-purple-400 text-blank font-heading">
                      {user.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 border-[3px] border-bw shadow-shadow" align="end" forceMount>
                <DropdownMenuLabel className="font-base">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-heading leading-none">{user.username}</p>
                    <p className="text-xs leading-none text-mtext">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="border-bw" />
                <DropdownMenuItem className="font-base" asChild>
                  <Link href="/settings">
                    <UserIcon className="mr-2 h-4 w-4" />
                    <span>Pengaturan</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="border-bw" />
                <DropdownMenuItem className="font-base" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Keluar</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="mx-auto max-w-4xl space-y-6">
          <div className="space-y-2">
            <h1 className="text-3xl font-heading tracking-tight">Dashboard</h1>
            <p className="text-mtext font-base">Kelola pesan dan profil Anda</p>
          </div>
          <div className="flex flex-col gap-4 md:flex-row">
            <Card className="flex-1" color="bg-blue-100">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-heading">Link Profil Anda</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/u/${user.username}`)
                      alert("Link profil berhasil disalin!")
                    }}
                  >
                    <Copy className="h-4 w-4" />
                    <span className="sr-only">Salin link</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-sm font-heading text-blue-600">/u/{user.username}</div>
                <div className="mt-4 flex gap-2">
                  <Button
                    variant="blue"
                    size="sm"
                    className="h-9"
                    onClick={() => {
                      if (navigator.share) {
                        navigator.share({
                          title: "Kirim pesan anonim ke saya",
                          text: "Kirim pesan anonim ke saya melalui Secreto",
                          url: `${window.location.origin}/u/${user.username}`,
                        })
                      } else {
                        navigator.clipboard.writeText(`${window.location.origin}/u/${user.username}`)
                        alert("Link profil berhasil disalin!")
                      }
                    }}
                  >
                    <Share2 className="mr-2 h-4 w-4" />
                    Bagikan
                  </Button>
                </div>
                <div className="mt-4 pt-4 border-t border-blue-200">
                  <h4 className="text-sm font-medium mb-2">Sosial Media</h4>
                  <div className="flex flex-wrap gap-2">
                    {memberStatus === "Premium" ? (
                      <>
                        {/* Cek apakah ada data sosial media */}
                        {formData.instagram ||
                        formData.twitter ||
                        formData.tiktok ||
                        formData.facebook ||
                        formData.linkedin ? (
                          <div className="flex flex-wrap gap-2">
                            {formData.instagram && (
                              <a
                                href={formData.instagram}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center h-8 w-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full border-2 border-bw hover:opacity-90 transition-opacity"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                                </svg>
                              </a>
                            )}
                            {formData.twitter && (
                              <a
                                href={formData.twitter}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center h-8 w-8 bg-blue-400 text-white rounded-full border-2 border-bw hover:opacity-90 transition-opacity"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                                </svg>
                              </a>
                            )}
                            {formData.tiktok && (
                              <a
                                href={formData.tiktok}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center h-8 w-8 bg-black text-white rounded-full border-2 border-bw hover:opacity-90 transition-opacity"
                              >
                                <svg
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="currentColor"
                                  xmlns="http://www.w3.org/2000/svg"
                                >
                                  <path d="M19.321 5.562a5.124 5.124 0 0 1-3.414-1.267 5.124 5.124 0 0 1-1.53-3.25h-3.577v13.068c0 1.154-.933 2.088-2.087 2.088a2.088 2.088 0 0 1-2.088-2.088 2.088 2.088 0 0 1 2.088-2.088c.286 0 .559.057.809.16V8.131A6.125 6.125 0 0 0 3.437 19.28a6.125 6.125 0 0 0 8.476-2.042 6.125 6.125 0 0 0 .775-2.979V9.768a8.59 8.59 0 0 0 3.524.764h.02V7.075c-.238 0-.475-.019-.71-.057-.2-.033-.401-.074-.602-.123v3.254a8.59 8.59 0 0 1-3.524-.764v4.49c0 1.068-.264 2.112-.775 2.98a6.125 6.125 0 0 1-3.644 2.847 6.126 6.126 0 0 1-4.832-.805 6.125 6.125 0 0 1-2.847-3.644 6.125 6.125 0 0 1 .805-4.833 6.125 6.125 0 0 1 3.644-2.846 6.125 6.125 0 0 1 2.09-.362c.238 0 .476.014.71.043v3.67a2.088 2.088 0 0 0-.71-.124 2.088 2.088 0 0 0-2.087 2.088 2.088 2.088 0 0 0 2.088 2.088 2.088 2.088 0 0 0 2.087-2.088V1.045h3.577a5.124 5.124 0 0 0 1.53 3.25 5.124 5.124 0 0 0 3.414 1.267v3.254a8.665 8.665 0 0 1-3.544-.764v4.49c0 3.382-2.743 6.125-6.125 6.125a6.125 6.125 0 0 1-6.125-6.125 6.125 6.125 0 0 1 10.957-3.849V6.326a8.59 8.59 0 0 0 3.524.764V3.836c.2.05.401.09.602.123.235.038.472.057.71.057v4.457h-.02a8.665 8.665 0 0 1-3.524-.764" />
                                </svg>
                              </a>
                            )}
                            {formData.facebook && (
                              <a
                                href={formData.facebook}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center h-8 w-8 bg-blue-600 text-white rounded-full border-2 border-bw hover:opacity-90 transition-opacity"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                                </svg>
                              </a>
                            )}
                            {formData.linkedin && (
                              <a
                                href={formData.linkedin}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center h-8 w-8 bg-blue-700 text-white rounded-full border-2 border-bw hover:opacity-90 transition-opacity"
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="16"
                                  height="16"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                  <rect x="2" y="9" width="4" height="12"></rect>
                                  <circle cx="4" cy="4" r="2"></circle>
                                </svg>
                              </a>
                            )}
                          </div>
                        ) : (
                          <div className="text-xs text-blue-600">
                            <Link
                              href="#settings"
                              className="flex items-center gap-1 hover:underline"
                              onClick={() => {
                                const settingsTab = document.querySelector('[data-value="settings"]')
                                if (settingsTab) {
                                  ;(settingsTab as HTMLElement).click()
                                }
                              }}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="14"
                                height="14"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="8" x2="12" y2="16"></line>
                                <line x1="8" y1="12" x2="16" y2="12"></line>
                              </svg>
                              Tambahkan link sosial media Anda
                            </Link>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="flex flex-wrap gap-2 opacity-60">
                        <div className="flex items-center justify-center h-8 w-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full border-2 border-bw relative">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                          </svg>
                          <div className="absolute -top-1 -right-1 h-4 w-4 bg-gray-800 rounded-full flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                          </div>
                        </div>
                        <div className="flex items-center justify-center h-8 w-8 bg-blue-400 text-white rounded-full border-2 border-bw relative">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                          </svg>
                          <div className="absolute -top-1 -right-1 h-4 w-4 bg-gray-800 rounded-full flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                          </div>
                        </div>
                        <div className="flex items-center justify-center h-8 w-8 bg-blue-600 text-white rounded-full border-2 border-bw relative">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                          </svg>
                          <div className="absolute -top-1 -right-1 h-4 w-4 bg-gray-800 rounded-full flex items-center justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="flex-1" color="bg-purple-100">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-heading">Statistik</CardTitle>
                <div className="flex items-center gap-2">
                  <div
                    className={`px-2 py-1 rounded-full text-xs font-heading ${memberStatus === "Premium" ? "bg-main text-bw" : "bg-gray-200 text-gray-700"}`}
                  >
                    {memberStatus}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-3xl font-heading">{profileStats.messageCount}</div>
                    <div className="text-sm font-base text-mtext">Total Pesan</div>
                  </div>
                  <div>
                    <div className="text-3xl font-heading">{profileStats.profileViews}</div>
                    <div className="text-sm font-base text-mtext">Total Tayangan</div>
                  </div>
                </div>

                {/* Status Member */}
                <div className="mt-4 pt-4 border-t-2 border-dashed border-bw">
                  <div className="flex justify-between items-center">
                    <div className="text-sm font-heading">Status Member</div>
                    <div className="flex items-center gap-2">
                      {memberStatus === "Premium" ? (
                        <>
                          <div className="h-3 w-3 rounded-full bg-green-500"></div>
                          <span className="text-sm font-heading text-green-600">Premium</span>
                        </>
                      ) : (
                        <>
                          <div className="h-3 w-3 rounded-full bg-gray-400"></div>
                          <span className="text-sm font-heading text-gray-600">Free</span>
                        </>
                      )}
                    </div>
                  </div>

                  {memberStatus === "Premium" && (
                    <div className="mt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full text-xs h-8"
                        onClick={() => {
                          const settingsTab = document.querySelector('[data-value="settings"]')
                          if (settingsTab) {
                            ;(settingsTab as HTMLElement).click()
                          }
                        }}
                      >
                        Kelola Akun Premium
                      </Button>
                    </div>
                  )}

                  {memberStatus === "Free" && (
                    <div className="mt-2">
                      <Button asChild variant="outline" size="sm" className="w-full text-xs h-8">
                        <Link href="/premium">Upgrade ke Premium</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Premium Promotion Card */}
          {memberStatus === "Free" && (
            <div className="relative overflow-hidden rounded-base border-[3px] border-bw bg-gradient-to-r from-yellow-300 to-yellow-100 p-6 neo-brutalism">
              <div className="absolute -right-6 -top-6 h-24 w-24 rotate-12 rounded-full bg-main opacity-50"></div>
              <div className="absolute -bottom-8 -left-8 h-24 w-24 rotate-12 rounded-full bg-main opacity-50"></div>

              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-2 max-w-md">
                  <div className="inline-block rounded-full bg-main px-3 py-1 text-xs font-heading text-bw">
                    PREMIUM
                  </div>
                  <h3 className="text-2xl font-heading">Upgrade ke Premium!</h3>
                  <p className="text-sm font-base">
                    Dapatkan akses seumur hidup ke semua fitur premium!
                  </p>

                  <div className="flex flex-wrap gap-3 pt-2">
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Ganti Username</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Foto Avatar Kustom</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Link Profil Kustom</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Notifikasi WhatsApp</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Notifikasi Email</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Statistik Lanjutan</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                      </div>
                      <span className="text-xs font-heading">Link Sosial Media</span>
                    </div>
                  </div>
                </div>

                <Button
                  asChild
                  variant="outline"
                  size="sm"
                  className="h-10 rounded-base border-[3px] border-bw bg-main text-bw font-heading neo-brutalism"
                >
                  <Link href="/premium">Upgrade Sekarang</Link>
                </Button>
              </div>

              <div className="absolute bottom-2 right-2">
                <div className="text-xs font-heading text-mtext">Penawaran terbatas</div>
              </div>
            </div>
          )}

          <Tabs defaultValue="messages" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2 neo-brutalism bg-blank h-12">
              <TabsTrigger
                value="messages"
                className="font-heading data-[state=active]:bg-main"
                onClick={() => addDebugInfo("Messages tab clicked")}
              >
                Pesan
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="font-heading data-[state=active]:bg-main"
                onClick={() => addDebugInfo("Settings tab clicked")}
              >
                Pengaturan
              </TabsTrigger>
            </TabsList>
            <TabsContent value="messages" className="mt-4 space-y-4">
              <Card color="bg-blank">
                <CardHeader>
                  <CardTitle>Pesan Anda</CardTitle>
                  <CardDescription className="font-base">
                    Lihat semua pesan yang Anda terima. Gunakan toggle di atas untuk mengatur visibilitas semua pesan
                    sekaligus.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {user ? (
                    <div className="min-h-[200px]">
                      <MessageList userId={user.id} username={user.username} key={user.id} />
                    </div>
                  ) : (
                    <div className="text-center py-8 text-mtext">Silakan login untuk melihat pesan Anda.</div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="mt-4 space-y-4">
              {/* Premium Status Card - Shown to all users */}
              <Card
                color={memberStatus === "Premium" ? "bg-gradient-to-r from-yellow-300 to-yellow-100" : "bg-gray-50"}
              >
                <CardHeader>
                  <CardTitle>Status Akun</CardTitle>
                  <CardDescription className="font-base">
                    {memberStatus === "Premium"
                      ? "Anda memiliki akun Premium dengan fitur eksklusif"
                      : "Upgrade ke Premium untuk mendapatkan fitur eksklusif"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className={`h-3 w-3 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-400"}`}
                        ></div>
                        <span
                          className={`text-sm font-heading ${memberStatus === "Premium" ? "text-green-600" : "text-gray-600"}`}
                        >
                          {memberStatus === "Premium" ? "Premium Aktif" : "Akun Free"}
                        </span>
                      </div>
                      {memberStatus !== "Premium" && (
                        <Button asChild variant="blue" size="sm">
                          <Link href="/premium">Upgrade</Link>
                        </Button>
                      )}
                    </div>

                    {/* Premium Benefits */}
                    <div className="rounded-base border-[3px] border-bw p-4 bg-blue-50 neo-brutalism">
                      <h3 className="text-sm font-heading mb-2">Fitur Premium</h3>
                      <ul className="text-xs space-y-2">
                        <li className="flex items-center gap-2">
                          <div
                            className={`h-4 w-4 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span>Username Kustom</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div
                            className={`h-4 w-4 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span>Foto Avatar Kustom</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div
                            className={`h-4 w-4 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span>Link Profil Kustom</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div
                            className={`h-4 w-4 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span>Statistik Lanjutan</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div
                            className={`h-4 w-4 rounded-full ${memberStatus === "Premium" ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center`}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="10"
                              height="10"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="white"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span>Notifikasi WhatsApp & Email</span>
                        </li>
                      </ul>
                      {memberStatus !== "Premium" && (
                        <div className="mt-3">
                          <Button asChild variant="outline" size="sm" className="w-full text-xs">
                            <Link href="/premium">Lihat Detail Premium</Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Premium Settings Card */}
              <Card color="bg-blank" className="mt-6 relative">
                {memberStatus !== "Premium" && (
                  <div className="absolute inset-0 bg-gray-100/80 backdrop-blur-[1px] z-10 flex flex-col items-center justify-center rounded-base">
                    <div className="bg-yellow-100 p-4 rounded-base border-[3px] border-bw neo-brutalism max-w-xs text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mx-auto mb-2"
                      >
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                      </svg>
                      <h3 className="text-sm font-heading mb-2">Fitur Premium Terkunci</h3>
                      <p className="text-xs text-mtext mb-3">Upgrade ke Premium untuk mengakses pengaturan ini</p>
                      <Button asChild variant="blue" size="sm">
                        <Link href="/premium">Upgrade Sekarang</Link>
                      </Button>
                    </div>
                  </div>
                )}
                <CardHeader>
                  <CardTitle>Pengaturan Profil Premium</CardTitle>
                  <CardDescription className="font-base">Sesuaikan profil Anda dengan fitur premium</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Avatar Upload */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-heading">Foto Avatar</h3>
                    <div className="flex items-center gap-4">
                      <div className="h-20 w-20 rounded-full border-2 border-bw bg-gray-100 flex items-center justify-center overflow-hidden">
                        {user.avatar_url ? (
                          <img
                            src={user.avatar_url || "/placeholder.svg"}
                            alt="Avatar"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span className="text-2xl font-heading text-gray-400">
                            {user.username.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            addDebugInfo("Upload avatar button clicked")
                            try {
                              // Inisialisasi bucket terlebih dahulu menggunakan server action
                              addDebugInfo("Initializing storage buckets via server action...")
                              const initResult = await initializeStorageBuckets()

                              if (initResult.error) {
                                addDebugInfo(`Error initializing buckets: ${initResult.error}`)
                                alert(`Error initializing storage: ${initResult.error}`)
                                return
                              }

                              addDebugInfo("Storage buckets initialized successfully")

                              // Trigger file input click
                              const fileInput = document.createElement("input")
                              fileInput.type = "file"
                              fileInput.accept = "image/*"
                              fileInput.onchange = async (e) => {
                                const file = (e.target as HTMLInputElement).files?.[0]
                                if (!file) {
                                  addDebugInfo("No file selected")
                                  return
                                }

                                addDebugInfo(
                                  `File selected: ${file.name}, type: ${file.type}, size: ${file.size} bytes`,
                                )

                                // Validate file type
                                if (!file.type.startsWith("image/")) {
                                  addDebugInfo("Invalid file type")
                                  alert("Hanya file gambar yang diperbolehkan")
                                  return
                                }

                                // Validate file size (max 2MB)
                                if (file.size > 2 * 1024 * 1024) {
                                  addDebugInfo("File too large")
                                  alert("Ukuran file maksimal 2MB")
                                  return
                                }

                                try {
                                  addDebugInfo("Starting avatar upload via server action...")

                                  // Gunakan FormData untuk mengirim file ke server action
                                  const formData = new FormData()
                                  formData.append("file", file)
                                  formData.append("userId", user.id)

                                  const result = await uploadAvatarAction(formData)

                                  if (result.error) {
                                    addDebugInfo(`Error uploading avatar: ${result.error}`)
                                    alert(`Gagal mengunggah avatar: ${result.error}`)
                                    return
                                  }

                                  if (result.databaseUpdateFailed) {
                                    addDebugInfo(`Avatar uploaded but database update failed: ${result.databaseError}`)
                                    alert(
                                      `Avatar berhasil diunggah tetapi gagal memperbarui profil. Silakan coba lagi nanti.`,
                                    )
                                    // Refresh data untuk memastikan UI terupdate dengan benar
                                    refreshUserData()
                                    return
                                  }

                                  addDebugInfo(`Avatar uploaded successfully: ${result.url}`)
                                  alert("Avatar berhasil diperbarui!")
                                  refreshUserData()
                                } catch (error: any) {
                                  addDebugInfo(`Error uploading avatar: ${error.message || "Unknown error"}`)
                                  console.error("Error uploading avatar:", error)
                                  alert(`Gagal mengunggah avatar: ${error.message || "Terjadi kesalahan"}`)
                                }
                              }
                              fileInput.click()
                            } catch (error: any) {
                              addDebugInfo(`Error with file input: ${error.message || "Unknown error"}`)
                              console.error("Error:", error)
                            }
                          }}
                        >
                          Unggah Foto
                        </Button>

                        {user.avatar_url && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-500"
                            onClick={async () => {
                              addDebugInfo("Delete avatar button clicked")
                              try {
                                if (!user.avatar_url) {
                                  addDebugInfo("No avatar to delete")
                                  return
                                }

                                // Konfirmasi penghapusan
                                if (!confirm("Apakah Anda yakin ingin menghapus foto avatar?")) {
                                  addDebugInfo("Delete cancelled by user")
                                  return
                                }

                                // Ekstrak nama file dari URL
                                const fileName = user.avatar_url.split("/").pop()
                                if (!fileName) {
                                  addDebugInfo("Invalid avatar URL")
                                  alert("URL avatar tidak valid")
                                  return
                                }

                                // Hapus file dari storage dan update database
                                addDebugInfo(`Deleting avatar file: ${fileName}`)
                                const deleteResult = await deleteAvatarAction(fileName, user.id)

                                if (deleteResult.error) {
                                  addDebugInfo(`Error deleting avatar: ${deleteResult.error}`)
                                  alert(`Gagal menghapus avatar: ${deleteResult.error}`)
                                  return
                                }

                                addDebugInfo("Avatar deleted successfully")
                                alert("Avatar berhasil dihapus!")
                                refreshUserData()
                              } catch (error: any) {
                                addDebugInfo(`Error deleting avatar: ${error.message || "Unknown error"}`)
                                console.error("Error deleting avatar:", error)
                                alert(`Gagal menghapus avatar: ${error.message || "Terjadi kesalahan"}`)
                              }
                            }}
                          >
                            Hapus Foto
                          </Button>
                        )}

                        <p className="text-xs text-mtext">Format: JPG, PNG. Maks: 2MB</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="username">
                      Username
                    </label>
                    <Input
                      id="username"
                      value={formData.username}
                      onChange={handleChange}
                      placeholder="Username Anda"
                    />
                    <p className="text-xs text-mtext">Username akan digunakan untuk link profil Anda: /u/username</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="displayName">
                      Nama Tampilan
                    </label>
                    <Input
                      id="displayName"
                      value={formData.displayName}
                      onChange={handleChange}
                      placeholder="Nama yang ditampilkan di profil Anda"
                    />
                    <p className="text-xs text-mtext">Nama yang ditampilkan di profil Anda</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="bio">
                      Bio
                    </label>
                    <Textarea
                      id="bio"
                      value={formData.bio}
                      onChange={handleChange}
                      placeholder="Ceritakan sedikit tentang diri Anda"
                      rows={3}
                    />
                    <p className="text-xs text-mtext">Maksimal 150 karakter</p>
                  </div>

                  <div className="space-y-2 mt-4">
                    <h3 className="text-sm font-heading">Link Sosial Media</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-heading" htmlFor="instagram">
                          Instagram
                        </label>
                        <Input
                          id="instagram"
                          placeholder="https://instagram.com/username"
                          value={formData.instagram}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-heading" htmlFor="twitter">
                          Twitter
                        </label>
                        <Input
                          id="twitter"
                          placeholder="https://twitter.com/username"
                          value={formData.twitter}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-heading" htmlFor="tiktok">
                          TikTok
                        </label>
                        <Input
                          id="tiktok"
                          placeholder="https://tiktok.com/@username"
                          value={formData.tiktok}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-heading" htmlFor="facebook">
                          Facebook
                        </label>
                        <Input
                          id="facebook"
                          placeholder="https://facebook.com/username"
                          value={formData.facebook}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-heading" htmlFor="linkedin">
                          LinkedIn
                        </label>
                        <Input
                          id="linkedin"
                          placeholder="https://linkedin.com/in/username"
                          value={formData.linkedin}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="green"
                    className="mt-4"
                    onClick={async () => {
                      addDebugInfo("Save button clicked")
                      try {
                        addDebugInfo("Starting profile update...")
                        addDebugInfo(`Form data being saved: ${JSON.stringify(formData)}`)
                        const supabase = getSupabaseClient()

                        // Check if username has changed
                        if (formData.username !== user.username) {
                          addDebugInfo(
                            `Username changed from ${user.username} to ${formData.username}, checking availability`,
                          )

                          // Check if the new username is already taken by another user
                          const { data: existingUser, error: usernameCheckError } = await supabase
                            .from("users")
                            .select("id")
                            .eq("username", formData.username)
                            .neq("id", user.id)
                            .single()

                          // If we found a user with this username, it's already taken
                          if (existingUser) {
                            addDebugInfo(`Username ${formData.username} is already taken`)
                            alert(
                              `Username "${formData.username}" sudah digunakan oleh pengguna lain. Silakan pilih username lain.`,
                            )
                            return
                          }

                          // If there's no error or the error is "no rows returned", the username is available
                          addDebugInfo(`Username ${formData.username} is available`)
                        }

                        // Update user data
                        addDebugInfo(
                          `Updating user data: username=${formData.username}, display_name=${formData.displayName}`,
                        )
                        const { error: userError } = await supabase
                          .from("users")
                          .update({
                            username: formData.username,
                            display_name: formData.displayName,
                            updated_at: new Date().toISOString(),
                          })
                          .eq("id", user.id)

                        if (userError) {
                          addDebugInfo(`Error updating user: ${userError.message}`)
                          throw new Error(`Error updating user: ${userError.message}`)
                        }

                        // Update profile data
                        addDebugInfo(`Updating profile data: bio=${formData.bio}, custom_url=${formData.username}`)
                        const { error: profileError } = await supabase
                          .from("profiles")
                          .update({
                            bio: formData.bio,
                            custom_url: formData.username, // Use username for custom_url
                            instagram: formData.instagram,
                            twitter: formData.twitter,
                            tiktok: formData.tiktok,
                            facebook: formData.facebook,
                            linkedin: formData.linkedin,
                            updated_at: new Date().toISOString(),
                          })
                          .eq("user_id", user.id)

                        if (profileError) {
                          addDebugInfo(`Error updating profile: ${profileError.message}`)
                          throw new Error(`Error updating profile: ${profileError.message}`)
                        }

                        addDebugInfo("Profile updated successfully")
                        alert("Profil berhasil diperbarui!")
                        refreshUserData()
                      } catch (error: any) {
                        addDebugInfo(`Error saving profile: ${error.message || "Unknown error"}`)
                        console.error("Error saving profile:", error)
                        alert(`Gagal menyimpan perubahan: ${error.message || "Terjadi kesalahan"}`)
                      }
                    }}
                  >
                    Simpan Perubahan
                  </Button>
                </CardContent>
              </Card>

              {/* Notification Settings Card */}
              <Card color="bg-blank" className="mt-6 relative">
                {memberStatus !== "Premium" && (
                  <div className="absolute inset-0 bg-gray-100/80 backdrop-blur-[1px] z-10 flex flex-col items-center justify-center rounded-base">
                    <div className="bg-yellow-100 p-4 rounded-base border-[3px] border-bw neo-brutalism max-w-xs text-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="mx-auto mb-2"
                      >
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                      </svg>
                      <h3 className="text-sm font-heading mb-2">Fitur Premium Terkunci</h3>
                      <p className="text-xs text-mtext mb-3">
                        Upgrade ke Premium untuk mengakses pengaturan notifikasi
                      </p>
                      <Button asChild variant="blue" size="sm">
                        <Link href="/premium">Upgrade Sekarang</Link>
                      </Button>
                    </div>
                  </div>
                )}
                <CardHeader>
                  <CardTitle>Pengaturan Notifikasi</CardTitle>
                  <CardDescription className="font-base">
                    Atur bagaimana Anda ingin menerima notifikasi pesan baru
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-heading">Notifikasi Pesan Baru</h3>

                      <div className="rounded-base border-[3px] border-bw p-4 bg-green-50 neo-brutalism">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500 text-white border-2 border-bw">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                              </svg>
                            </div>
                            <div>
                              <h4 className="text-sm font-heading">WhatsApp</h4>
                              <p className="text-xs text-mtext">Terima notifikasi langsung ke WhatsApp Anda</p>
                            </div>
                          </div>
                          <div
                            className={`flex items-center h-6 w-11 cursor-pointer rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${whatsappEnabled ? "bg-green-500" : "bg-gray-200"}`}
                            onClick={() => setWhatsappEnabled(!whatsappEnabled)}
                          >
                            <div
                              className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 transform ${whatsappEnabled ? "translate-x-5" : "translate-x-0"}`}
                            ></div>
                          </div>
                        </div>
                        <div className="mt-3 pl-11">
                          <div className="space-y-2">
                            <label className="text-xs font-heading" htmlFor="whatsapp-number">
                              Nomor WhatsApp
                            </label>
                            <Input id="whatsapp-number" placeholder="+62 8xx xxxx xxxx" className="h-8 text-sm" />
                          </div>
                        </div>
                      </div>

                      <div className="rounded-base border-[3px] border-bw p-4 bg-blue-50 neo-brutalism">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500 text-white border-2 border-bw">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="16"
                                height="16"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <rect x="2" y="4" width="20" height="16" rx="2"></rect>
                                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                              </svg>
                            </div>
                            <div>
                              <h4 className="text-sm font-heading">Email</h4>
                              <p className="text-xs text-mtext">Terima notifikasi melalui email</p>
                            </div>
                          </div>
                          <div
                            className={`flex items-center h-6 w-11 cursor-pointer rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${emailEnabled ? "bg-blue-500" : "bg-gray-200"}`}
                            onClick={() => setEmailEnabled(!emailEnabled)}
                          >
                            <div
                              className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 transform ${emailEnabled ? "translate-x-5" : "translate-x-0"}`}
                            ></div>
                          </div>
                        </div>
                        <div className="mt-3 pl-11">
                          <div className="space-y-2">
                            <label className="text-xs font-heading" htmlFor="email-notification">
                              Email Notifikasi
                            </label>
                            <Input id="email-notification" defaultValue={user.email} className="h-8 text-sm" />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-sm font-heading">Frekuensi Notifikasi</h3>
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            id="instant"
                            name="notification-frequency"
                            className="h-4 w-4 accent-blue-500"
                            defaultChecked
                          />
                          <label htmlFor="instant" className="text-sm font-base">
                            Langsung (setiap ada pesan baru)
                          </label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            id="daily"
                            name="notification-frequency"
                            className="h-4 w-4 accent-blue-500"
                          />
                          <label htmlFor="daily" className="text-sm font-base">
                            Harian (ringkasan harian)
                          </label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            id="weekly"
                            name="notification-frequency"
                            className="h-4 w-4 accent-blue-500"
                          />
                          <label htmlFor="weekly" className="text-sm font-base">
                            Mingguan (ringkasan mingguan)
                          </label>
                        </div>
                      </div>
                    </div>

                    <Button variant="blue" className="w-full">
                      Simpan Pengaturan Notifikasi
                    </Button>
                  </div>
                </CardContent>
              </Card>
              {/* Debug Info Card - hanya tampil dalam mode development */}
              <Card className="border-red-500 mt-6">
                <CardHeader>
                  <CardTitle>Debug Info</CardTitle>
                  <CardDescription>Informasi debugging untuk membantu mengatasi masalah</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="max-h-40 overflow-y-auto">
                    <pre className="text-xs">
                      {debugInfo.map((info, index) => (
                        <div key={index}>{info}</div>
                      ))}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <div className="mt-8 text-center text-xs text-mtext">
        <Link href="/admin" className="hover:underline">
          Admin Panel
        </Link>
      </div>
    </div>
  )
}

