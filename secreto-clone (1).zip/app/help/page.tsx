import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <Link href="/" className="flex items-center gap-2 font-heading text-xl">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
            S
          </div>
          <span>Secreto</span>
        </Link>
      </header>

      <main className="container mx-auto p-4 py-12 max-w-4xl">
        <h1 className="text-3xl font-heading mb-6">Pusat Bantuan</h1>

        <Tabs defaultValue="getting-started" className="space-y-4">
          <TabsList className="w-full neo-brutalism bg-blank h-12">
            <TabsTrigger value="getting-started" className="text-sm font-heading data-[state=active]:bg-main">
              Memulai
            </TabsTrigger>
            <TabsTrigger value="features" className="text-sm font-heading data-[state=active]:bg-main">
              Fitur
            </TabsTrigger>
            <TabsTrigger value="premium" className="text-sm font-heading data-[state=active]:bg-main">
              Premium
            </TabsTrigger>
            <TabsTrigger value="faq" className="text-sm font-heading data-[state=active]:bg-main">
              FAQ
            </TabsTrigger>
          </TabsList>

          <TabsContent value="getting-started">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Memulai dengan Secreto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-heading">1. Buat Akun</h3>
                  <p className="text-mtext">
                    Untuk mulai menggunakan Secreto, Anda perlu membuat akun. Klik tombol "Daftar" di halaman utama dan
                    isi formulir pendaftaran dengan email dan password Anda.
                  </p>
                  <div className="rounded-base border-[3px] border-bw p-4 bg-blue-50">
                    <p className="text-sm">
                      <strong>Tip:</strong> Pilih username yang mudah diingat karena ini akan menjadi bagian dari link
                      profil Anda.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-heading">2. Bagikan Link Profil Anda</h3>
                  <p className="text-mtext">
                    Setelah membuat akun, Anda akan mendapatkan link profil unik yang dapat Anda bagikan dengan teman,
                    keluarga, atau pengikut Anda. Mereka dapat menggunakan link ini untuk mengirim pesan anonim kepada
                    Anda.
                  </p>
                  <div className="rounded-base border-[3px] border-bw p-4 bg-green-50">
                    <p className="text-sm">
                      <strong>Contoh:</strong> https://secreto.site/u/username
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-heading">3. Terima dan Balas Pesan</h3>
                  <p className="text-mtext">
                    Ketika seseorang mengirim pesan melalui link profil Anda, pesan tersebut akan muncul di dashboard
                    Anda. Anda dapat memilih untuk membalas pesan tersebut secara pribadi atau membuat balasan Anda
                    publik.
                  </p>
                </div>

                <div className="mt-6">
                  <Button asChild variant="blue">
                    <Link href="/register">Daftar Sekarang</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Fitur Secreto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blue-50">
                    <h3 className="text-lg font-heading mb-2">Pesan Anonim</h3>
                    <p className="text-sm text-mtext">
                      Terima pesan anonim dari siapa saja. Pengirim tidak perlu membuat akun untuk mengirim pesan.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-green-50">
                    <h3 className="text-lg font-heading mb-2">Balas Pesan</h3>
                    <p className="text-sm text-mtext">
                      Balas pesan yang Anda terima secara pribadi atau buat balasan Anda publik agar dapat dilihat oleh
                      semua orang.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-purple-50">
                    <h3 className="text-lg font-heading mb-2">Profil Kustom</h3>
                    <p className="text-sm text-mtext">
                      Sesuaikan profil Anda dengan bio dan foto profil (tersedia untuk pengguna premium).
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-pink-50">
                    <h3 className="text-lg font-heading mb-2">Notifikasi</h3>
                    <p className="text-sm text-mtext">
                      Dapatkan notifikasi saat Anda menerima pesan baru melalui email atau WhatsApp.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <Button asChild variant="blue">
                    <Link href="/dashboard">Lihat Dashboard</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="premium">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Fitur Premium</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-mtext">
                  Upgrade ke Secreto Premium untuk mendapatkan akses ke fitur eksklusif yang akan meningkatkan
                  pengalaman Anda.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Username Kustom</h3>
                    <p className="text-sm text-mtext">
                      Ganti username Anda kapan saja untuk mencerminkan identitas Anda.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Foto Avatar Kustom</h3>
                    <p className="text-sm text-mtext">
                      Unggah foto profil Anda sendiri untuk tampilan yang lebih personal.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Link Profil Kustom</h3>
                    <p className="text-sm text-mtext">
                      Buat link profil yang mudah diingat dan sesuai dengan brand Anda.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Tema Kustom</h3>
                    <p className="text-sm text-mtext">
                      Sesuaikan tampilan halaman profil Anda dengan warna dan tema pilihan.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Statistik Lanjutan</h3>
                    <p className="text-sm text-mtext">
                      Dapatkan wawasan mendalam tentang pengunjung dan interaksi profil Anda.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-yellow-50">
                    <h3 className="text-lg font-heading mb-2">Filter Pesan</h3>
                    <p className="text-sm text-mtext">
                      Filter pesan yang tidak diinginkan dan atur siapa yang dapat mengirim pesan.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <Button asChild variant="blue">
                    <Link href="/premium">Upgrade ke Premium</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="faq">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Pertanyaan Umum</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                    <h3 className="text-lg font-heading mb-2">Apakah Secreto benar-benar anonim?</h3>
                    <p className="text-mtext">
                      Ya, semua pesan yang dikirim melalui Secreto benar-benar anonim. Kami tidak menyimpan informasi
                      pengirim pesan.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                    <h3 className="text-lg font-heading mb-2">Apa perbedaan akun gratis dan premium?</h3>
                    <p className="text-mtext">
                      Akun gratis memungkinkan Anda menerima dan membalas pesan anonim. Akun premium menawarkan fitur
                      tambahan seperti username kustom, foto avatar, link profil kustom, tema kustom, statistik
                      lanjutan, dan filter pesan.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                    <h3 className="text-lg font-heading mb-2">Bagaimana cara menghapus pesan yang tidak pantas?</h3>
                    <p className="text-mtext">
                      Anda dapat menghapus pesan yang tidak pantas dari dashboard Anda. Pengguna premium juga memiliki
                      akses ke filter pesan otomatis yang dapat memblokir konten tidak pantas.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                    <h3 className="text-lg font-heading mb-2">Apakah saya bisa membatalkan langganan premium?</h3>
                    <p className="text-mtext">
                      Ya, Anda dapat membatalkan langganan premium kapan saja dari pengaturan akun Anda. Anda akan tetap
                      menikmati fitur premium hingga akhir periode langganan Anda.
                    </p>
                  </div>

                  <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                    <h3 className="text-lg font-heading mb-2">Bagaimana cara menghubungi dukungan?</h3>
                    <p className="text-mtext">
                      Anda dapat menghubungi tim dukungan kami melalui email di support@secreto.site atau melalui
                      formulir kontak di halaman Kontak.
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <Button asChild variant="outline">
                    <Link href="/contact">Hubungi Kami</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

