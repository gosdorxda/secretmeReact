"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { getSupabaseClient } from "@/lib/supabase/client"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const supabase = getSupabaseClient()

      console.log("Attempting login with:", { email })

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("Login error:", error)
        setError(error.message)
        return
      }

      console.log("Login successful:", data)
      router.push("/dashboard")
    } catch (err) {
      console.error("Unexpected error during login:", err)
      setError("Terjadi kesalahan saat login. Silakan coba lagi.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-4">
      <Card className="w-full max-w-md neo-brutalism">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <Link href="/" className="flex items-center gap-2 font-heading text-xl">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
                S
              </div>
              <span>Secreto</span>
            </Link>
          </div>
          <CardTitle className="text-2xl font-heading text-center">Login</CardTitle>
          <CardDescription className="text-center font-base">
            Masukkan email dan password untuk login ke akun Anda
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="p-3 rounded-md bg-red-100 border-2 border-red-300 text-red-800 text-sm">{error}</div>
          )}
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-heading" htmlFor="email">
                Email
              </label>
              <Input
                id="email"
                type="email"
                placeholder="nama@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-heading" htmlFor="password">
                  Password
                </label>
                <Link href="/forgot-password" className="text-xs text-blue-600 hover:underline">
                  Lupa password?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" variant="blue" className="w-full" disabled={loading}>
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-t-transparent border-current"></div>
                  <span>Memproses...</span>
                </div>
              ) : (
                "Login"
              )}
            </Button>
          </form>
          <div className="text-center text-sm">
            <span className="text-mtext">Belum punya akun? </span>
            <Link href="/register" className="text-blue-600 hover:underline">
              Daftar sekarang
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

