import Link from "next/link"
import { Button } from "@/components/ui/neo-button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 font-heading text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
              S
            </div>
            <span>Secretme</span>
          </Link>
          <div className="flex gap-4">
            <Button asChild variant="outline" size="sm">
              <Link href="/login">Masuk</Link>
            </Button>
            <Button asChild variant="blue" size="sm">
              <Link href="/register">Daftar</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-blue-200 opacity-50"></div>
          <div className="absolute -bottom-32 -left-32 h-64 w-64 rounded-full bg-pink-200 opacity-50"></div>

          <div className="container mx-auto px-4 md:px-6 relative">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="flex-1 space-y-6">
                <div className="inline-block rounded-full bg-main px-3 py-1 text-sm font-heading text-bw">
                  PLATFORM PESAN ANONIM #1
                </div>
                <h1 className="text-4xl md:text-6xl font-heading tracking-tighter leading-tight">
                  Terima Pesan <span className="text-blue-500">Anonim</span> dari Siapapun
                </h1>
                <p className="text-lg text-mtext md:text-xl font-base max-w-xl">
                  Platform untuk menerima pesan dan umpan balik secara anonim. Dapatkan kejujuran dari teman dan rekan
                  kerja Anda.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild variant="blue" size="lg" className="neo-brutalism">
                    <Link href="/register">Mulai Gratis</Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="neo-brutalism">
                    <Link href="#fitur-premium">Lihat Fitur Premium</Link>
                  </Button>
                </div>

                <div className="flex items-center gap-4 pt-4">
                  <div className="flex -space-x-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className={`h-8 w-8 rounded-full border-2 border-bw bg-${["blue", "green", "pink", "purple"][i - 1]}-400 flex items-center justify-center text-xs font-heading text-white`}
                      >
                        U
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-mtext">
                    <span className="font-heading">30,000+</span> pengguna sudah bergabung!
                  </p>
                </div>
              </div>

              <div className="flex-1 relative">
                <div className="relative z-10 rounded-base border-[3px] border-bw bg-blank p-6 neo-brutalism rotate-3 transform transition-transform hover:rotate-0">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-purple-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                        A
                      </div>
                      <div>
                        <div className="text-xs text-mtext">Pesan Anonim • Baru saja</div>
                        <div className="text-sm font-heading">Untuk: @budi</div>
                      </div>
                    </div>
                    <p className="text-base font-base">
                      Presentasimu minggu lalu sangat menginspirasi! Kamu punya cara yang bagus untuk menjelaskan konsep
                      yang kompleks dengan sederhana.
                    </p>
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm">
                        Balas
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="absolute top-12 -right-4 z-0 rounded-base border-[3px] border-bw bg-pink-100 p-6 neo-brutalism -rotate-6 transform transition-transform hover:rotate-0">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-blue-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                        A
                      </div>
                      <div>
                        <div className="text-xs text-mtext">Pesan Anonim • 5 menit yang lalu</div>
                        <div className="text-sm font-heading">Untuk: @username</div>
                      </div>
                    </div>
                    <p className="text-base font-base">
                      Kamu selalu bisa diandalkan saat saya butuh bantuan. Terima kasih sudah menjadi teman yang baik!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-16 bg-blank">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-heading mb-4">Cara Kerjanya</h2>
              <p className="text-mtext max-w-2xl mx-auto">Mulai terima pesan anonim dalam 3 langkah mudah</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blue-50">
                <div className="h-12 w-12 rounded-full bg-blue-500 text-white flex items-center justify-center font-heading text-xl mb-4">
                  1
                </div>
                <h3 className="text-xl font-heading mb-2">Buat Akun</h3>
                <p className="text-mtext">Daftar gratis dalam hitungan detik dengan email dan password Anda.</p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-green-50">
                <div className="h-12 w-12 rounded-full bg-green-500 text-white flex items-center justify-center font-heading text-xl mb-4">
                  2
                </div>
                <h3 className="text-xl font-heading mb-2">Bagikan Link</h3>
                <p className="text-mtext">Bagikan link profil Anda ke teman dan rekan kerja di media sosial.</p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-pink-50">
                <div className="h-12 w-12 rounded-full bg-pink-500 text-white flex items-center justify-center font-heading text-xl mb-4">
                  3
                </div>
                <h3 className="text-xl font-heading mb-2">Terima Pesan</h3>
                <p className="text-mtext">Terima pesan anonim dan balas jika Anda mau. Semua dalam satu tempat.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Premium Features */}
        <section id="fitur-premium" className="py-16 relative overflow-hidden">
          <div className="absolute -top-32 -left-32 h-64 w-64 rounded-full bg-yellow-200 opacity-50"></div>
          <div className="absolute -bottom-32 -right-32 h-64 w-64 rounded-full bg-blue-200 opacity-50"></div>

          <div className="container mx-auto px-4 md:px-6 relative">
            <div className="text-center mb-12">
              <div className="inline-block rounded-full bg-main px-3 py-1 text-sm font-heading text-bw mb-4">
                PREMIUM
              </div>
              <h2 className="text-3xl font-heading mb-4">Tingkatkan Pengalaman Anda</h2>
              <p className="text-mtext max-w-2xl mx-auto">Nikmati fitur eksklusif dengan Secreto Premium</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-blue-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-blue-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M20 7h-9"></path>
                      <path d="M14 17H5"></path>
                      <circle cx="17" cy="17" r="3"></circle>
                      <circle cx="7" cy="7" r="3"></circle>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Username Kustom</h3>
                </div>
                <p className="text-mtext mb-4">
                  Pilih username unik yang mencerminkan identitas Anda. Ganti kapan saja.
                </p>
                <div className="flex items-center gap-2 text-sm text-blue-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-pink-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-pink-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M15 8h.01"></path>
                      <rect x="3" y="3" width="18" height="18" rx="2"></rect>
                      <path d="m21 15-5-5L5 21"></path>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Foto Avatar Kustom</h3>
                </div>
                <p className="text-mtext mb-4">Unggah foto profil Anda sendiri untuk tampilan yang lebih personal.</p>
                <div className="flex items-center gap-2 text-sm text-pink-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-purple-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-purple-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Link Profil Kustom</h3>
                </div>
                <p className="text-mtext mb-4">Buat link profil yang mudah diingat dan sesuai dengan brand Anda.</p>
                <div className="flex items-center gap-2 text-sm text-purple-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-green-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-green-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Notifikasi WhatsApp</h3>
                </div>
                <p className="text-mtext mb-4">Dapatkan notifikasi langsung ke WhatsApp Anda saat ada pesan baru.</p>
                <div className="flex items-center gap-2 text-sm text-green-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-orange-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-orange-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Notifikasi Email</h3>
                </div>
                <p className="text-mtext mb-4">
                  Terima pemberitahuan email saat ada pesan atau interaksi baru di profil Anda.
                </p>
                <div className="flex items-center gap-2 text-sm text-orange-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank hover:bg-red-50 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-full bg-red-500 text-white flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
                      <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                  </div>
                  <h3 className="text-xl font-heading">Filter Pesan</h3>
                </div>
                <p className="text-mtext mb-4">
                  Filter pesan yang tidak diinginkan dan atur siapa yang dapat mengirim pesan.
                </p>
                <div className="flex items-center gap-2 text-sm text-red-600 font-heading">
                  <span>Eksklusif Premium</span>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6"></path>
                  </svg>
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <div className="inline-block rounded-base border-[3px] border-bw bg-gradient-to-r from-yellow-300 to-yellow-100 p-8 neo-brutalism max-w-3xl mx-auto">
                <h3 className="text-2xl font-heading mb-4">Upgrade ke Premium Sekarang!</h3>
                <p className="text-base mb-6">Nikmati semua fitur premium dengan harga spesial hanya Rp 49.000/bulan</p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button asChild variant="blue" size="lg" className="neo-brutalism">
                    <Link href="/register">Mulai 7 Hari Gratis</Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="neo-brutalism">
                    <Link href="/login">Sudah Punya Akun?</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-16 bg-blank">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-heading mb-4">Apa Kata Pengguna Kami</h2>
              <p className="text-mtext max-w-2xl mx-auto">
                Bergabunglah dengan ribuan pengguna yang puas dengan Secreto
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blue-50">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-full bg-blue-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                    RA
                  </div>
                  <div>
                    <div className="text-base font-heading">Rani A.</div>
                    <div className="text-xs text-mtext">Influencer</div>
                  </div>
                </div>
                <p className="text-base font-base mb-4">
                  "Secreto membantu saya mendapatkan umpan balik jujur dari followers saya. Fitur premium sangat worth
                  it!"
                </p>
                <div className="flex text-yellow-500">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <svg
                      key={i}
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                  ))}
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-green-50">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-full bg-green-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                    BS
                  </div>
                  <div>
                    <div className="text-base font-heading">Budi S.</div>
                    <div className="text-xs text-mtext">Manager</div>
                  </div>
                </div>
                <p className="text-base font-base mb-4">
                  "Saya menggunakan Secreto untuk mendapatkan umpan balik dari tim saya. Sangat membantu untuk evaluasi
                  kinerja."
                </p>
                <div className="flex text-yellow-500">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <svg
                      key={i}
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                  ))}
                </div>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-pink-50">
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-12 w-12 rounded-full bg-pink-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                    DW
                  </div>
                  <div>
                    <div className="text-base font-heading">Dina W.</div>
                    <div className="text-xs text-mtext">Mahasiswa</div>
                  </div>
                </div>
                <p className="text-base font-base mb-4">
                  "Secreto membantu saya mendapatkan masukan jujur dari teman-teman kuliah. Interface-nya juga keren!"
                </p>
                <div className="flex text-yellow-500">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <svg
                      key={i}
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill={i < 5 ? "currentColor" : "none"}
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                    </svg>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-16">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-heading mb-4">Pertanyaan Umum</h2>
              <p className="text-mtext max-w-2xl mx-auto">Jawaban untuk pertanyaan yang sering ditanyakan</p>
            </div>

            <div className="max-w-3xl mx-auto space-y-6">
              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank">
                <h3 className="text-xl font-heading mb-2">Apakah Secreto benar-benar anonim?</h3>
                <p className="text-mtext">
                  Ya, semua pesan yang dikirim melalui Secreto benar-benar anonim. Kami tidak menyimpan informasi
                  pengirim pesan.
                </p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank">
                <h3 className="text-xl font-heading mb-2">Apa perbedaan akun gratis dan premium?</h3>
                <p className="text-mtext">
                  Akun gratis memungkinkan Anda menerima dan membalas pesan anonim. Akun premium menawarkan fitur
                  tambahan seperti username kustom, foto avatar, link profil kustom, tema kustom, statistik lanjutan,
                  dan filter pesan.
                </p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank">
                <h3 className="text-xl font-heading mb-2">Bagaimana cara menghapus pesan yang tidak pantas?</h3>
                <p className="text-mtext">
                  Anda dapat menghapus pesan yang tidak pantas dari dashboard Anda. Pengguna premium juga memiliki akses
                  ke filter pesan otomatis yang dapat memblokir konten tidak pantas.
                </p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blank">
                <h3 className="text-xl font-heading mb-2">Apakah saya bisa membatalkan langganan premium?</h3>
                <p className="text-mtext">
                  Ya, Anda dapat membatalkan langganan premium kapan saja dari pengaturan akun Anda. Anda akan tetap
                  menikmati fitur premium hingga akhir periode langganan Anda.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-gradient-to-r from-blue-100 to-purple-100">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <h2 className="text-3xl md:text-4xl font-heading">Siap Menerima Pesan Anonim?</h2>
              <p className="text-lg text-mtext">
                Bergabunglah dengan ribuan pengguna dan mulai terima pesan anonim hari ini.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="blue" size="lg" className="neo-brutalism">
                  <Link href="/register">Daftar Gratis</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="neo-brutalism">
                  <Link href="/login">Sudah Punya Akun?</Link>
                </Button>
              </div>
              <p className="text-sm text-mtext">Tidak perlu kartu kredit. Mulai gratis dalam hitungan detik.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-blank border-t-[3px] border-bw py-8">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-heading text-xl mb-4 md:mb-0">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-main border-[3px] border-bw">
                S
              </div>
              <span>Secretme</span>
            </div>

            <div className="flex gap-6">
              <Link href="#" className="text-sm hover:underline">
                Tentang Kami
              </Link>
              <Link href="#" className="text-sm hover:underline">
                Kebijakan Privasi
              </Link>
              <Link href="#" className="text-sm hover:underline">
                Syarat & Ketentuan
              </Link>
              <Link href="#" className="text-sm hover:underline">
                Kontak
              </Link>
            </div>
          </div>

          <div className="mt-6 text-center text-sm text-mtext">
            &copy; {new Date().getFullYear()} Secretme. Semua hak dilindungi.
          </div>
        </div>
      </footer>
    </div>
  )
}

