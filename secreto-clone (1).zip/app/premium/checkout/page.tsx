"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Check, CreditCard, Calendar, Lock } from "lucide-react"

export default function CheckoutPage() {
  const [loading, setLoading] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const router = useRouter()

  // Form state
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [expiry, setExpiry] = useState("")
  const [cvc, setCvc] = useState("")

  // Untuk demo, kita akan mensimulasikan proses pembayaran
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    setLoading(true)

    // Simulasi proses pembayaran
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setLoading(false)
    setPaymentSuccess(true)

    // Redirect ke dashboard setelah pembayaran berhasil
    setTimeout(() => {
      router.push("/demo-dashboard")
    }, 3000)
  }

  if (paymentSuccess) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center p-4">
        <Card className="max-w-md w-full" color="bg-green-50">
          <CardContent className="p-8 text-center">
            <div className="mx-auto h-16 w-16 flex items-center justify-center rounded-full bg-green-500 text-white mb-4">
              <Check className="h-8 w-8" />
            </div>
            <h2 className="text-2xl font-heading mb-2">Pembayaran Berhasil!</h2>
            <p className="text-mtext mb-6">
              Terima kasih telah berlangganan Secreto Premium. Akun Anda telah diupgrade ke premium seumur hidup.
            </p>
            <Button asChild variant="blue">
              <Link href="/demo-dashboard">Kembali ke Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <Link href="/" className="flex items-center gap-2 font-heading text-xl">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
            S
          </div>
          <span>Secreto</span>
        </Link>
      </header>

      <main className="container mx-auto p-4 py-12 max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h1 className="text-3xl font-heading mb-4">Checkout</h1>
            <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-yellow-50 mb-6">
              <h2 className="text-xl font-heading mb-2">Secreto Premium</h2>
              <div className="flex justify-between items-center mb-4">
                <span className="text-mtext">Premium Seumur Hidup</span>
                <span className="font-heading">Rp 99.000</span>
              </div>
              <div className="border-t border-dashed border-bw pt-4">
                <div className="flex justify-between items-center">
                  <span className="font-heading">Total</span>
                  <span className="text-xl font-heading">Rp 99.000</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-heading">Yang Anda Dapatkan:</h3>
              {[
                "Username Kustom",
                "Foto Avatar Kustom",
                "Link Profil Kustom",
                "Tema Kustom",
                "Statistik Lanjutan",
                "Filter Pesan",
                "Premium Seumur Hidup",
              ].map((feature) => (
                <div key={feature} className="flex items-center gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-sm font-heading">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Informasi Pembayaran</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="name">
                      Nama Lengkap
                    </label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      disabled={loading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="email">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      disabled={loading}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-heading" htmlFor="card-number">
                      Nomor Kartu
                    </label>
                    <div className="relative">
                      <Input
                        id="card-number"
                        value={cardNumber}
                        onChange={(e) =>
                          setCardNumber(
                            e.target.value
                              .replace(/\D/g, "")
                              .replace(/(.{4})/g, "$1 ")
                              .trim(),
                          )
                        }
                        placeholder="1234 5678 9012 3456"
                        required
                        disabled={loading}
                      />
                      <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-mtext" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-heading" htmlFor="expiry">
                        Tanggal Kadaluarsa
                      </label>
                      <div className="relative">
                        <Input
                          id="expiry"
                          value={expiry}
                          onChange={(e) => {
                            const value = e.target.value.replace(/\D/g, "")
                            if (value.length <= 4) {
                              const month = value.slice(0, 2)
                              const year = value.slice(2, 4)
                              setExpiry(value.length > 2 ? `${month}/${year}` : month)
                            }
                          }}
                          placeholder="MM/YY"
                          required
                          disabled={loading}
                        />
                        <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-mtext" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-heading" htmlFor="cvc">
                        CVC
                      </label>
                      <div className="relative">
                        <Input
                          id="cvc"
                          value={cvc}
                          onChange={(e) => setCvc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                          placeholder="123"
                          required
                          disabled={loading}
                        />
                        <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-mtext" />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="w-full" variant="blue" type="submit" disabled={loading}>
                      {loading ? "Memproses..." : "Bayar Sekarang"}
                    </Button>
                    <div className="text-center mt-2 text-xs text-mtext">
                      Pembayaran aman dengan Midtrans. Premium seumur hidup.
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

