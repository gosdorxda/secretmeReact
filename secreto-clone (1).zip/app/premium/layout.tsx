import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Upgrade ke Premium - Secreto Clone",
  description: "Upgrade ke Secreto Premium dan dapatkan fitur eksklusif",
}

export default function PremiumLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}

