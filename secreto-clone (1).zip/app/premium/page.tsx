"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Check } from "lucide-react"

export default function PremiumPage() {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly")

  const plans = {
    monthly: {
      price: "Rp 49.000",
      period: "per bulan",
      originalPrice: "Rp 99.000",
      discount: "Hemat 50%",
    },
    yearly: {
      price: "Rp 399.000",
      period: "per tahun",
      originalPrice: "Rp 1.188.000",
      discount: "Hemat 66%",
    },
  }

  const features = [
    "Username Kustom",
    "Foto Avatar Kustom",
    "Link Profil Kustom",
    "Tema Kustom",
    "Statistik Lanjutan",
    "Filter Pesan",
    "Prioritas Dukungan",
    "Tanpa Iklan",
  ]

  return (
    <div className="min-h-screen bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <Link href="/" className="flex items-center gap-2 font-heading text-xl">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
            S
          </div>
          <span>Secreto</span>
        </Link>
      </header>

      <main className="container mx-auto p-4 py-12 max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-heading mb-4">Upgrade ke Premium</h1>
          <p className="text-mtext max-w-2xl mx-auto">
            Dapatkan fitur eksklusif dan tingkatkan pengalaman Secreto Anda dengan berlangganan Premium.
          </p>
        </div>

        <div className="mb-12">
          <div className="flex justify-center mb-8">
            <div className="inline-flex p-1 rounded-full bg-gray-100 border-[3px] border-bw neo-brutalism">
              <button
                className={`px-6 py-2 rounded-full text-sm font-heading ${
                  selectedPlan === "monthly" ? "bg-main text-bw" : "bg-transparent"
                }`}
                onClick={() => setSelectedPlan("monthly")}
              >
                Bulanan
              </button>
              <button
                className={`px-6 py-2 rounded-full text-sm font-heading ${
                  selectedPlan === "yearly" ? "bg-main text-bw" : "bg-transparent"
                }`}
                onClick={() => setSelectedPlan("yearly")}
              >
                Tahunan
              </button>
            </div>
          </div>

          <Card className="mx-auto max-w-2xl" color="bg-gradient-to-r from-yellow-300 to-yellow-100">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">Secreto Premium</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-5xl font-heading">{plans[selectedPlan].price}</div>
                <div className="text-sm text-mtext">{plans[selectedPlan].period}</div>
                <div className="mt-2">
                  <span className="text-sm text-mtext line-through mr-2">{plans[selectedPlan].originalPrice}</span>
                  <span className="text-sm font-heading text-green-600">{plans[selectedPlan].discount}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {features.map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-white">
                      <Check className="h-3 w-3" />
                    </div>
                    <span className="text-sm font-heading">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4">
                <Button asChild className="w-full" variant="blue" size="lg">
                  <Link href="/premium/checkout">Upgrade Sekarang</Link>
                </Button>
                <div className="text-center mt-2 text-xs text-mtext">
                  Pembayaran aman dengan Midtrans. Batalkan kapan saja.
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
          <div>
            <h2 className="text-2xl font-heading mb-4">Pertanyaan Umum</h2>
            <div className="space-y-4">
              <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                <h3 className="text-lg font-heading mb-2">Apa perbedaan akun gratis dan premium?</h3>
                <p className="text-mtext text-sm">
                  Akun gratis memungkinkan Anda menerima dan membalas pesan anonim. Akun premium menawarkan fitur
                  tambahan seperti username kustom, foto avatar, link profil kustom, tema kustom, statistik lanjutan,
                  dan filter pesan.
                </p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blank">
                <h3 className="text-lg font-heading mb-2">Apakah saya bisa membatalkan langganan premium?</h3>
                <p className="text-mtext text-sm">
                  Ya, Anda dapat membatalkan langganan premium kapan saja dari pengaturan akun Anda. Anda akan tetap
                  menikmati fitur premium hingga akhir periode langganan Anda.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-heading mb-4">Testimoni Pengguna Premium</h2>
            <div className="space-y-4">
              <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-blue-50">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-10 w-10 rounded-full bg-blue-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                    RA
                  </div>
                  <div>
                    <div className="text-base font-heading">Rani A.</div>
                    <div className="text-xs text-mtext">Influencer</div>
                  </div>
                </div>
                <p className="text-sm">
                  "Secreto Premium membantu saya mendapatkan umpan balik jujur dari followers saya. Fitur premium sangat
                  worth it!"
                </p>
              </div>

              <div className="rounded-base border-[3px] border-bw p-4 neo-brutalism bg-green-50">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-10 w-10 rounded-full bg-green-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
                    BS
                  </div>
                  <div>
                    <div className="text-base font-heading">Budi S.</div>
                    <div className="text-xs text-mtext">Manager</div>
                  </div>
                </div>
                <p className="text-sm">
                  "Saya menggunakan Secreto Premium untuk mendapatkan umpan balik dari tim saya. Sangat membantu untuk
                  evaluasi kinerja."
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

