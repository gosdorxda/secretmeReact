"use client"

import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { registerUser } from "@/actions/auth-actions"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function RegisterPage() {
  const [errors, setErrors] = useState<Record<string, string[]>>({})
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  async function handleSubmit(formData: FormData) {
    setIsLoading(true)
    setErrors({})

    const result = await registerUser(formData)

    if (result.error) {
      setErrors(result.error)
      setIsLoading(false)
      return
    }

    // Redirect ke login jika berhasil
    router.push("/login?registered=true")
  }

  return (
    <div className="flex min-h-screen flex-col bg-bg">
      <main className="flex flex-1 items-center justify-center p-4">
        <Card className="w-full max-w-md neo-brutalism" color="bg-green-100">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-3xl font-heading">Buat Akun</CardTitle>
            <CardDescription className="font-base">Masukkan detail Anda untuk membuat akun baru</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <form action={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-heading leading-none" htmlFor="username">
                  Username
                </label>
                <Input id="username" name="username" placeholder="johndoe" disabled={isLoading} />
                {errors.username && <p className="text-sm text-red-500">{errors.username[0]}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-heading leading-none" htmlFor="email">
                  Email
                </label>
                <Input
                  id="email"
                  name="email"
                  placeholder="m@example.com"
                  type="email"
                  autoCapitalize="none"
                  autoComplete="email"
                  autoCorrect="off"
                  disabled={isLoading}
                />
                {errors.email && <p className="text-sm text-red-500">{errors.email[0]}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-heading leading-none" htmlFor="password">
                  Password
                </label>
                <Input id="password" name="password" type="password" disabled={isLoading} />
                {errors.password && <p className="text-sm text-red-500">{errors.password[0]}</p>}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-heading leading-none" htmlFor="confirm-password">
                  Konfirmasi Password
                </label>
                <Input id="confirm-password" name="confirmPassword" type="password" disabled={isLoading} />
                {errors.confirmPassword && <p className="text-sm text-red-500">{errors.confirmPassword[0]}</p>}
              </div>
              {errors.general && (
                <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{errors.general[0]}</div>
              )}
              <Button className="w-full" variant="green" type="submit" disabled={isLoading}>
                {isLoading ? "Memproses..." : "Daftar"}
              </Button>
              <div className="text-center">
                <Link href="/login" className="text-sm font-heading text-blue-600 hover:underline">
                  Sudah punya akun? Masuk
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

