import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Pengaturan - Secreto Clone",
  description: "Kelola pengaturan profil dan akun Anda",
}

export default function SettingsLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}

