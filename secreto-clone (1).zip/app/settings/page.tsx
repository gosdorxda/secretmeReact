"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Textarea } from "@/components/ui/textarea"
import { updateProfile } from "@/actions/profile-actions"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AvatarUpload } from "@/components/avatar-upload"
import { initializeStorage } from "@/lib/supabase/storage"
import Link from "next/link"

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("profile")
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isPremium, setIsPremium] = useState(false)
  const [formData, setFormData] = useState({
    display_name: "",
    bio: "",
    custom_url: "",
    theme: "default",
    instagram: "",
    twitter: "",
    tiktok: "",
    facebook: "",
    linkedin: "",
  })

  useEffect(() => {
    async function loadUserData() {
      setIsLoading(true)

      try {
        // Inisialisasi storage buckets jika belum ada
        await initializeStorage()

        const supabase = getSupabaseClient()

        // Dapatkan data user
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          console.error("User not found")
          setIsLoading(false)
          return
        }

        // Dapatkan data dari tabel users
        const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", user.id).single()

        if (userError) {
          console.error("Error loading user data:", userError)
          setIsLoading(false)
          return
        }

        // Dapatkan data dari tabel profiles
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("user_id", user.id)
          .single()

        if (profileError) {
          console.error("Error loading profile data:", profileError)
        }

        setUser(userData)
        setProfile(profileData || {})
        setIsPremium(userData.is_premium || false)

        // Isi form dengan data yang ada
        setFormData({
          display_name: userData.display_name || "",
          bio: profileData?.bio || "",
          custom_url: profileData?.custom_url || "",
          theme: profileData?.theme || "default",
          instagram: profileData?.instagram || "",
          twitter: profileData?.twitter || "",
          tiktok: profileData?.tiktok || "",
          facebook: profileData?.facebook || "",
          linkedin: profileData?.linkedin || "",
        })
      } catch (error) {
        console.error("Error:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadUserData()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      const result = await updateProfile(formData)

      if (result.error) {
        alert(`Gagal menyimpan perubahan: ${result.error}`)
      } else {
        alert("Profil berhasil diperbarui")
      }
    } catch (error) {
      console.error("Error updating profile:", error)
      alert("Terjadi kesalahan saat memperbarui profil")
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex justify-center">
          <div className="w-full max-w-3xl">
            <Card>
              <CardHeader>
                <CardTitle>Memuat...</CardTitle>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-center">
        <div className="w-full max-w-3xl">
          {/* Tabs */}
          <div className="mb-6 grid grid-cols-2 gap-2 rounded-lg border-2 border-bw overflow-hidden">
            <button
              className={`py-3 px-4 text-center font-heading ${
                activeTab === "profile" ? "bg-main text-white" : "bg-white"
              }`}
              onClick={() => setActiveTab("profile")}
            >
              Profil
            </button>
            <button
              className={`py-3 px-4 text-center font-heading ${
                activeTab === "pengaturan" ? "bg-main text-white" : "bg-white"
              }`}
              onClick={() => setActiveTab("pengaturan")}
            >
              Pengaturan
            </button>
          </div>

          {activeTab === "profile" ? (
            <div className="space-y-6">
              {/* Status Premium Card */}
              <Card color={isPremium ? "bg-gradient-to-r from-yellow-300 to-yellow-100" : "bg-gray-50"}>
                <CardHeader>
                  <CardTitle>Status Akun</CardTitle>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      {isPremium ? (
                        <>
                          <div className="inline-block rounded-full bg-main px-3 py-1 text-xs font-heading text-bw mb-2">
                            PREMIUM AKTIF
                          </div>
                          <div className="text-sm font-heading">Anda memiliki akun Premium dengan fitur eksklusif</div>
                        </>
                      ) : (
                        <>
                          <div className="text-sm font-heading">Akun Free</div>
                          <div className="text-xs text-mtext mt-1">Upgrade ke Premium untuk fitur eksklusif</div>
                        </>
                      )}
                    </div>
                    {!isPremium && (
                      <Button asChild variant="blue" size="sm">
                        <Link href="/premium">Upgrade</Link>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Premium Features List */}
              {isPremium && (
                <Card>
                  <CardHeader>
                    <CardTitle>Fitur Premium</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <div className="mr-2 h-5 w-5 rounded-full bg-green-500 flex items-center justify-center text-white">
                          ✓
                        </div>
                        <span>Username Kustom</span>
                      </li>
                      <li className="flex items-center">
                        <div className="mr-2 h-5 w-5 rounded-full bg-green-500 flex items-center justify-center text-white">
                          ✓
                        </div>
                        <span>Link Profil Kustom</span>
                      </li>
                      <li className="flex items-center">
                        <div className="mr-2 h-5 w-5 rounded-full bg-green-500 flex items-center justify-center text-white">
                          ✓
                        </div>
                        <span>Link Sosial Media</span>
                      </li>
                      <li className="flex items-center">
                        <div className="mr-2 h-5 w-5 rounded-full bg-green-500 flex items-center justify-center text-white">
                          ✓
                        </div>
                        <span>Notifikasi WhatsApp & Email</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              )}

              {/* Profile Settings Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Pengaturan Profil Premium</CardTitle>
                </CardHeader>
                <CardContent>
                  {!isPremium && (
                    <div className="mb-6 p-4 bg-gray-100 rounded-lg border border-gray-200">
                      <p className="text-center font-medium">
                        Fitur ini hanya tersedia untuk pengguna premium.{" "}
                        <Link href="/premium" className="text-blue-600 hover:underline">
                          Upgrade sekarang
                        </Link>
                      </p>
                    </div>
                  )}

                  <div className="relative">
                    {!isPremium && (
                      <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px] z-10 flex items-center justify-center">
                        <div className="bg-white p-4 rounded-lg shadow-lg text-center">
                          <div className="text-3xl mb-2">🔒</div>
                          <h3 className="text-lg font-medium mb-2">Fitur Premium</h3>
                          <p className="mb-4">Upgrade ke premium untuk mengakses fitur ini</p>
                          <Button asChild variant="blue">
                            <Link href="/premium">Upgrade Sekarang</Link>
                          </Button>
                        </div>
                      </div>
                    )}

                    <div className="grid gap-6">
                      <div className="flex flex-col md:flex-row gap-6">
                        <div className="md:w-1/3">
                          <h3 className="text-lg font-medium mb-4">Foto Avatar</h3>
                          {user && <AvatarUpload userId={user.id} currentAvatarUrl={user.avatar_url} />}
                        </div>
                      </div>

                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="display_name">
                            Nama Tampilan
                          </label>
                          <Input
                            id="display_name"
                            name="display_name"
                            value={formData.display_name}
                            onChange={handleChange}
                            placeholder="Nama yang ditampilkan di profil Anda"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="bio">
                            Bio
                          </label>
                          <Textarea
                            id="bio"
                            name="bio"
                            value={formData.bio}
                            onChange={handleChange}
                            placeholder="Ceritakan sedikit tentang diri Anda"
                            rows={4}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="custom_url">
                            Link Profil Kustom
                          </label>
                          <Input
                            id="custom_url"
                            name="custom_url"
                            value={formData.custom_url}
                            onChange={handleChange}
                            placeholder="URL kustom untuk profil Anda (opsional)"
                            disabled={!isPremium}
                          />
                          <p className="text-xs text-gray-500">Hanya tersedia untuk pengguna premium</p>
                        </div>

                        <div className="mt-6 mb-4">
                          <h3 className="text-lg font-medium mb-4">Link Sosial Media</h3>
                          <p className="text-sm text-gray-500 mb-4">Fitur ini hanya tersedia untuk pengguna premium</p>

                          <div className="space-y-4">
                            <div className="space-y-2">
                              <label className="text-sm font-medium" htmlFor="instagram">
                                Instagram
                              </label>
                              <Input
                                id="instagram"
                                name="instagram"
                                value={formData.instagram}
                                onChange={handleChange}
                                placeholder="https://instagram.com/username"
                                disabled={!isPremium}
                              />
                            </div>

                            <div className="space-y-2">
                              <label className="text-sm font-medium" htmlFor="twitter">
                                Twitter
                              </label>
                              <Input
                                id="twitter"
                                name="twitter"
                                value={formData.twitter}
                                onChange={handleChange}
                                placeholder="https://twitter.com/username"
                                disabled={!isPremium}
                              />
                            </div>

                            <div className="space-y-2">
                              <label className="text-sm font-medium" htmlFor="tiktok">
                                TikTok
                              </label>
                              <Input
                                id="tiktok"
                                name="tiktok"
                                value={formData.tiktok}
                                onChange={handleChange}
                                placeholder="https://tiktok.com/@username"
                                disabled={!isPremium}
                              />
                            </div>

                            <div className="space-y-2">
                              <label className="text-sm font-medium" htmlFor="facebook">
                                Facebook
                              </label>
                              <Input
                                id="facebook"
                                name="facebook"
                                value={formData.facebook}
                                onChange={handleChange}
                                placeholder="https://facebook.com/username"
                                disabled={!isPremium}
                              />
                            </div>

                            <div className="space-y-2">
                              <label className="text-sm font-medium" htmlFor="linkedin">
                                LinkedIn
                              </label>
                              <Input
                                id="linkedin"
                                name="linkedin"
                                value={formData.linkedin}
                                onChange={handleChange}
                                placeholder="https://linkedin.com/in/username"
                                disabled={!isPremium}
                              />
                            </div>
                          </div>
                        </div>

                        <Button type="submit" disabled={isSaving}>
                          {isSaving ? "Menyimpan..." : "Simpan Perubahan"}
                        </Button>
                      </form>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Notification Settings Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Pengaturan Notifikasi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium">Notifikasi Pesan Baru</h3>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white mr-3">
                            <span>W</span>
                          </div>
                          <div>
                            <p className="font-medium">WhatsApp</p>
                            <p className="text-sm text-gray-500">Terima notifikasi via WhatsApp</p>
                          </div>
                        </div>
                        <div className="relative inline-block w-12 h-6 rounded-full bg-gray-200">
                          <input type="checkbox" id="whatsapp-toggle" className="sr-only" disabled={!isPremium} />
                          <span
                            className={`absolute left-1 top-1 w-4 h-4 rounded-full bg-white transition-transform ${isPremium ? "cursor-pointer" : "cursor-not-allowed"}`}
                          ></span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg mt-2">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white mr-3">
                            <span>E</span>
                          </div>
                          <div>
                            <p className="font-medium">Email</p>
                            <p className="text-sm text-gray-500">Terima notifikasi via Email</p>
                          </div>
                        </div>
                        <div className="relative inline-block w-12 h-6 rounded-full bg-gray-200">
                          <input type="checkbox" id="email-toggle" className="sr-only" disabled={!isPremium} />
                          <span
                            className={`absolute left-1 top-1 w-4 h-4 rounded-full bg-white transition-transform ${isPremium ? "cursor-pointer" : "cursor-not-allowed"}`}
                          ></span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 mt-6">
                      <h3 className="text-lg font-medium">Frekuensi Notifikasi</h3>
                      <div className="flex items-center space-x-4">
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="notification-frequency"
                            value="realtime"
                            className="mr-2"
                            disabled={!isPremium}
                          />
                          <span>Langsung</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="notification-frequency"
                            value="daily"
                            className="mr-2"
                            disabled={!isPremium}
                          />
                          <span>Harian</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="notification-frequency"
                            value="weekly"
                            className="mr-2"
                            disabled={!isPremium}
                          />
                          <span>Mingguan</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  <Button className="mt-6" disabled={!isPremium}>
                    Simpan Pengaturan Notifikasi
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

