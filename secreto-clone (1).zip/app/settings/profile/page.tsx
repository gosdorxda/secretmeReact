"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Textarea } from "@/components/ui/textarea"
import { updateProfile, checkUsernameAvailability } from "@/actions/profile-actions"
import { getSupabaseClient } from "@/lib/supabase/client"
import { AvatarUpload } from "@/components/avatar-upload"
import { initializeStorage } from "@/lib/supabase/storage"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function ProfileSettingsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isPremium, setIsPremium] = useState(false)
  const [usernameError, setUsernameError] = useState<string | null>(null)
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null)
  const [debugInfo, setDebugInfo] = useState<string[]>([])
  const [formData, setFormData] = useState({
    username: "",
    display_name: "",
    bio: "",
    custom_url: "",
    theme: "default",
    instagram: "",
    twitter: "",
    tiktok: "",
    facebook: "",
    linkedin: "",
  })

  const addDebugInfo = (info: string) => {
    console.log("DEBUG:", info)
    setDebugInfo((prev) => [...prev, `${new Date().toISOString().split("T")[1].split(".")[0]}: ${info}`])
  }

  useEffect(() => {
    async function loadUserData() {
      setIsLoading(true)
      addDebugInfo("Loading user data...")

      try {
        // Inisialisasi storage buckets jika belum ada
        addDebugInfo("Initializing storage buckets...")
        await initializeStorage()
        addDebugInfo("Storage buckets initialized")

        const supabase = getSupabaseClient()

        // Dapatkan data user
        addDebugInfo("Getting user from auth...")
        const {
          data: { user },
          error: authError,
        } = await supabase.auth.getUser()

        if (authError) {
          addDebugInfo(`Auth error: ${authError.message}`)
          throw authError
        }

        if (!user) {
          addDebugInfo("User not found in auth")
          setIsLoading(false)
          return
        }

        addDebugInfo(`User found: ${user.id}`)

        // Dapatkan data dari tabel users
        addDebugInfo("Getting user data from users table...")
        const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", user.id).single()

        if (userError) {
          addDebugInfo(`Error loading user data: ${userError.message}`)
          throw userError
        }

        addDebugInfo(`User data loaded: ${JSON.stringify(userData)}`)

        // Dapatkan data dari tabel profiles
        addDebugInfo("Getting profile data...")
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("user_id", user.id)
          .single()

        if (profileError) {
          addDebugInfo(`Error loading profile data: ${profileError.message}`)
          // Don't throw here, just log it
        }

        addDebugInfo(`Profile data loaded: ${JSON.stringify(profileData || {})}`)

        setUser(userData)
        setProfile(profileData || {})
        setIsPremium(userData.is_premium || false)
        addDebugInfo(`Is premium: ${userData.is_premium || false}`)

        // Isi form dengan data yang ada
        addDebugInfo("Setting form data...")
        setFormData({
          username: userData.username || "",
          display_name: userData.display_name || "",
          bio: profileData?.bio || "",
          custom_url: profileData?.custom_url || "",
          theme: profileData?.theme || "default",
          instagram: profileData?.instagram || "",
          twitter: profileData?.twitter || "",
          tiktok: profileData?.tiktok || "",
          facebook: profileData?.facebook || "",
          linkedin: profileData?.linkedin || "",
        })
        addDebugInfo("Form data set")
      } catch (error: any) {
        addDebugInfo(`Error in loadUserData: ${error.message || "Unknown error"}`)
        console.error("Error:", error)
      } finally {
        setIsLoading(false)
        addDebugInfo("Finished loading user data")
      }
    }

    loadUserData()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    addDebugInfo(`Form field changed: ${name} = ${value}`)
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Reset username validation when username changes
    if (name === "username") {
      setUsernameError(null)
      setUsernameAvailable(null)
    }
  }

  const checkUsername = async () => {
    if (!formData.username || formData.username === user?.username) {
      setUsernameError(null)
      setUsernameAvailable(null)
      return
    }

    addDebugInfo(`Checking username: ${formData.username}`)

    // Validasi format username
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(formData.username)) {
      setUsernameError("Username hanya boleh berisi huruf, angka, dan underscore (_), panjang 3-20 karakter")
      setUsernameAvailable(false)
      addDebugInfo("Username format invalid")
      return
    }

    try {
      addDebugInfo("Calling checkUsernameAvailability...")
      const result = await checkUsernameAvailability(formData.username)
      addDebugInfo(`Username check result: ${JSON.stringify(result)}`)

      if (result.error) {
        setUsernameError(result.error)
        setUsernameAvailable(false)
        addDebugInfo(`Username check error: ${result.error}`)
      } else {
        setUsernameAvailable(result.available)
        if (!result.available) {
          setUsernameError("Username sudah digunakan")
          addDebugInfo("Username already taken")
        } else {
          setUsernameError(null)
          addDebugInfo("Username available")
        }
      }
    } catch (error: any) {
      addDebugInfo(`Error checking username: ${error.message || "Unknown error"}`)
      console.error("Error checking username:", error)
      setUsernameError("Gagal memeriksa ketersediaan username")
      setUsernameAvailable(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    addDebugInfo("Form submitted")

    // Validasi username jika diubah
    if (formData.username !== user?.username) {
      addDebugInfo("Username changed, checking availability...")
      await checkUsername()
      if (!usernameAvailable) {
        addDebugInfo("Username not available, stopping submission")
        return
      }
    }

    setIsSaving(true)
    addDebugInfo("Saving profile changes...")

    try {
      addDebugInfo(`Calling updateProfile with data: ${JSON.stringify(formData)}`)
      const result = await updateProfile(formData)
      addDebugInfo(`Update profile result: ${JSON.stringify(result)}`)

      if (result.error) {
        addDebugInfo(`Error updating profile: ${result.error}`)
        alert(`Gagal menyimpan perubahan: ${result.error}`)
      } else {
        addDebugInfo("Profile updated successfully")
        alert("Profil berhasil diperbarui")

        // Jika username berubah, redirect ke halaman profil baru
        if (formData.username !== user?.username) {
          addDebugInfo(`Username changed, redirecting to /u/${formData.username}`)
          router.push(`/u/${formData.username}`)
        } else {
          // Refresh halaman untuk memuat data terbaru
          addDebugInfo("Reloading page to refresh data")
          window.location.reload()
        }
      }
    } catch (error: any) {
      addDebugInfo(`Error in handleSubmit: ${error.message || "Unknown error"}`)
      console.error("Error updating profile:", error)
      alert("Terjadi kesalahan saat memperbarui profil")
    } finally {
      setIsSaving(false)
      addDebugInfo("Save process completed")
    }
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex justify-center">
          <div className="w-full max-w-3xl">
            <Card>
              <CardHeader>
                <CardTitle>Memuat...</CardTitle>
              </CardHeader>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-center">
        <div className="w-full max-w-3xl space-y-6">
          {/* Debug Info Card */}
          <Card className="border-red-500">
            <CardHeader>
              <CardTitle>Debug Info</CardTitle>
              <CardDescription>Informasi debugging untuk membantu mengatasi masalah</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="max-h-40 overflow-y-auto">
                <pre className="text-xs">
                  {debugInfo.map((info, index) => (
                    <div key={index}>{info}</div>
                  ))}
                </pre>
              </div>
            </CardContent>
          </Card>

          {/* Status Premium Card */}
          <Card color={isPremium ? "bg-gradient-to-r from-yellow-300 to-yellow-100" : "bg-gray-50"}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  {isPremium ? (
                    <>
                      <div className="inline-block rounded-full bg-main px-3 py-1 text-xs font-heading text-bw mb-2">
                        PREMIUM
                      </div>
                      <div className="text-sm font-heading">Akun Premium Aktif</div>
                      <div className="text-xs text-mtext mt-1">Status premium seumur hidup</div>
                    </>
                  ) : (
                    <>
                      <div className="text-sm font-heading">Akun Free</div>
                      <div className="text-xs text-mtext mt-1">Upgrade ke Premium untuk fitur eksklusif</div>
                    </>
                  )}
                </div>
                {!isPremium && (
                  <Button asChild variant="blue" size="sm">
                    <Link href="/premium">Upgrade</Link>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Fitur Premium Card */}
          <Card>
            <CardHeader>
              <CardTitle>Fitur Premium</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <div className={`h-4 w-4 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"}`}></div>
                  <span>Username Kustom</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className={`h-4 w-4 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"}`}></div>
                  <span>Link Profil Kustom</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className={`h-4 w-4 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"}`}></div>
                  <span>Tema Kustom</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className={`h-4 w-4 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"}`}></div>
                  <span>Link Sosial Media</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className={`h-4 w-4 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"}`}></div>
                  <span>Notifikasi WhatsApp & Email</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Profile Settings Card */}
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Profil Premium</CardTitle>
              <CardDescription>Ubah informasi profil dan tampilan Anda</CardDescription>
            </CardHeader>
            <CardContent>
              {!isPremium && (
                <div className="mb-6 p-4 bg-gray-100 rounded-lg border border-gray-200">
                  <p className="text-center font-medium">
                    Fitur ini hanya tersedia untuk pengguna premium.{" "}
                    <Link href="/premium" className="text-blue-600 hover:underline">
                      Upgrade sekarang
                    </Link>
                  </p>
                </div>
              )}

              <div className="relative">
                {!isPremium && (
                  <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px] z-10 flex items-center justify-center">
                    <div className="bg-white p-4 rounded-lg shadow-lg text-center">
                      <div className="text-3xl mb-2">🔒</div>
                      <h3 className="text-lg font-medium mb-2">Fitur Premium</h3>
                      <p className="mb-4">Upgrade ke premium untuk mengakses fitur ini</p>
                      <Button asChild variant="blue">
                        <Link href="/premium">Upgrade Sekarang</Link>
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid gap-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/3">
                      <h3 className="text-lg font-medium mb-4">Avatar</h3>
                      {user && (
                        <AvatarUpload
                          userId={user.id}
                          currentAvatarUrl={user.avatar_url}
                          isPremium={isPremium}
                          onSuccess={(url) => {
                            addDebugInfo(`Avatar upload success: ${url}`)
                          }}
                        />
                      )}
                    </div>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium" htmlFor="username">
                        Username
                      </label>
                      <div className="relative">
                        <Input
                          id="username"
                          name="username"
                          value={formData.username}
                          onChange={handleChange}
                          onBlur={checkUsername}
                          placeholder="Username Anda"
                          disabled={!isPremium}
                          className={usernameError ? "border-red-500" : usernameAvailable ? "border-green-500" : ""}
                        />
                        {usernameAvailable === true && (
                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-green-500">✓</div>
                        )}
                      </div>
                      {usernameError && <p className="text-xs text-red-500">{usernameError}</p>}
                      <p className="text-xs text-gray-500">Hanya tersedia untuk pengguna premium</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium" htmlFor="display_name">
                        Nama Tampilan
                      </label>
                      <Input
                        id="display_name"
                        name="display_name"
                        value={formData.display_name}
                        onChange={handleChange}
                        placeholder="Nama yang ditampilkan di profil Anda"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium" htmlFor="bio">
                        Bio
                      </label>
                      <Textarea
                        id="bio"
                        name="bio"
                        value={formData.bio}
                        onChange={handleChange}
                        placeholder="Ceritakan sedikit tentang diri Anda"
                        rows={4}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium" htmlFor="custom_url">
                        URL Kustom
                      </label>
                      <Input
                        id="custom_url"
                        name="custom_url"
                        value={formData.custom_url}
                        onChange={handleChange}
                        placeholder="URL kustom untuk profil Anda (opsional)"
                        disabled={!isPremium}
                      />
                      <p className="text-xs text-gray-500">Hanya tersedia untuk pengguna premium</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium" htmlFor="theme">
                        Tema
                      </label>
                      <select
                        id="theme"
                        name="theme"
                        value={formData.theme}
                        onChange={handleChange}
                        className="w-full rounded-md border border-gray-300 px-3 py-2"
                        disabled={!isPremium}
                      >
                        <option value="default">Default</option>
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                        <option value="colorful">Colorful</option>
                        <option value="minimal">Minimal</option>
                      </select>
                      <p className="text-xs text-gray-500">Tema tambahan tersedia untuk pengguna premium</p>
                    </div>

                    <div className="mt-6 mb-4">
                      <h3 className="text-lg font-medium mb-4">Link Sosial Media</h3>
                      <p className="text-sm text-gray-500 mb-4">Fitur ini hanya tersedia untuk pengguna premium</p>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="instagram">
                            Instagram
                          </label>
                          <Input
                            id="instagram"
                            name="instagram"
                            value={formData.instagram}
                            onChange={handleChange}
                            placeholder="https://instagram.com/username"
                            disabled={!isPremium}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="twitter">
                            Twitter
                          </label>
                          <Input
                            id="twitter"
                            name="twitter"
                            value={formData.twitter}
                            onChange={handleChange}
                            placeholder="https://twitter.com/username"
                            disabled={!isPremium}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="tiktok">
                            TikTok
                          </label>
                          <Input
                            id="tiktok"
                            name="tiktok"
                            value={formData.tiktok}
                            onChange={handleChange}
                            placeholder="https://tiktok.com/@username"
                            disabled={!isPremium}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="facebook">
                            Facebook
                          </label>
                          <Input
                            id="facebook"
                            name="facebook"
                            value={formData.facebook}
                            onChange={handleChange}
                            placeholder="https://facebook.com/username"
                            disabled={!isPremium}
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium" htmlFor="linkedin">
                            LinkedIn
                          </label>
                          <Input
                            id="linkedin"
                            name="linkedin"
                            value={formData.linkedin}
                            onChange={handleChange}
                            placeholder="https://linkedin.com/in/username"
                            disabled={!isPremium}
                          />
                        </div>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={isSaving || !isPremium || (formData.username !== user?.username && !usernameAvailable)}
                      onClick={() => addDebugInfo("Save button clicked")}
                    >
                      {isSaving ? "Menyimpan..." : "Simpan Perubahan"}
                    </Button>
                  </form>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

