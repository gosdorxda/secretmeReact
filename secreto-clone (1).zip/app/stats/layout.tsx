import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Statistik - Secreto Clone",
  description: "Lihat statistik lanjutan profil Anda",
}

export default function StatsLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}

