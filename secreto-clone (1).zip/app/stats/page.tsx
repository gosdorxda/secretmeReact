"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { getSupabaseClient } from "@/lib/supabase/client"
import { getUserStats } from "@/lib/redis"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

type User = {
  id: string
  username: string
  display_name?: string
  is_premium: boolean
}

export default function StatsPage() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    profileViews: 0,
    messageCount: 0,
    dailyViews: [] as { date: string; views: number }[],
    dailyMessages: [] as { date: string; messages: number }[],
  })
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    async function getUser() {
      try {
        // Untuk demo, kita gunakan user dari localStorage
        const storedUser = localStorage.getItem("demo_user")

        if (!storedUser) {
          router.push("/demo-login")
          return
        }

        const parsedUser = JSON.parse(storedUser)

        // Ambil data lengkap user dari database
        const { data, error } = await supabase
          .from("users")
          .select("id, username, display_name, is_premium")
          .eq("id", parsedUser.id)
          .single()

        if (error) {
          throw error
        }

        setUser(data)

        // Ambil statistik dari database dan Redis
        await fetchStats(data.id)
      } catch (error) {
        console.error("Error fetching user:", error)
      } finally {
        setLoading(false)
      }
    }

    getUser()
  }, [router, supabase])

  async function fetchStats(userId: string) {
    try {
      // Ambil jumlah tampilan profil dari database
      const { data: profile } = await supabase.from("profiles").select("total_views").eq("user_id", userId).single()

      // Ambil jumlah pesan
      const { count: messageCount } = await supabase
        .from("messages")
        .select("id", { count: "exact" })
        .eq("recipient_id", userId)

      // Ambil statistik dari Redis
      const redisStats = await getUserStats(userId)

      // Generate data untuk chart (contoh data)
      const today = new Date()
      const dailyViews = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(today)
        date.setDate(date.getDate() - i)
        return {
          date: date.toLocaleDateString("id-ID", { weekday: "short" }),
          views: Math.floor(Math.random() * 50) + 10,
        }
      }).reverse()

      const dailyMessages = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(today)
        date.setDate(date.getDate() - i)
        return {
          date: date.toLocaleDateString("id-ID", { weekday: "short" }),
          messages: Math.floor(Math.random() * 20) + 5,
        }
      }).reverse()

      setStats({
        profileViews: Math.max(profile?.total_views || 0, redisStats.profileViews),
        messageCount: Math.max(messageCount || 0, redisStats.messageCount),
        dailyViews,
        dailyMessages,
      })
    } catch (error) {
      console.error("Error fetching stats:", error)
    }
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center">Memuat...</div>
  }

  if (!user) {
    return null // Akan di-redirect oleh useEffect
  }

  // Redirect ke halaman premium jika bukan pengguna premium
  if (!user.is_premium) {
    return (
      <div className="min-h-screen bg-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full" color="bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-center">Fitur Premium</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-center">
            <p className="text-mtext">
              Statistik lanjutan hanya tersedia untuk pengguna Premium. Upgrade sekarang untuk mengakses fitur ini.
            </p>
            <Button asChild variant="blue">
              <Link href="/premium">Upgrade ke Premium</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/demo-dashboard">Kembali ke Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-bg">
      <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 font-heading text-xl">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
              S
            </div>
            <span>Secreto</span>
          </Link>
          <div className="flex items-center gap-4">
            <Button asChild variant="outline" size="sm">
              <Link href="/demo-dashboard">Dashboard</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4 max-w-4xl">
        <h1 className="text-3xl font-heading mb-6">Statistik Lanjutan</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card color="bg-blue-50">
            <CardContent className="p-6">
              <div className="text-3xl font-heading">{stats.profileViews}</div>
              <div className="text-sm text-mtext">Total Tayangan</div>
            </CardContent>
          </Card>

          <Card color="bg-green-50">
            <CardContent className="p-6">
              <div className="text-3xl font-heading">{stats.messageCount}</div>
              <div className="text-sm text-mtext">Total Pesan</div>
            </CardContent>
          </Card>

          <Card color="bg-purple-50">
            <CardContent className="p-6">
              <div className="text-3xl font-heading">
                {Math.floor((stats.profileViews / Math.max(stats.messageCount, 1)) * 100) / 100}
              </div>
              <div className="text-sm text-mtext">Tayangan per Pesan</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="views" className="space-y-4">
          <TabsList className="w-full neo-brutalism bg-blank h-12">
            <TabsTrigger value="views" className="text-sm font-heading data-[state=active]:bg-main">
              Tayangan
            </TabsTrigger>
            <TabsTrigger value="messages" className="text-sm font-heading data-[state=active]:bg-main">
              Pesan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="views">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Tayangan Harian</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.dailyViews} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="views" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages">
            <Card color="bg-blank">
              <CardHeader>
                <CardTitle>Pesan Harian</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.dailyMessages} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="messages" fill="#10b981" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8 p-4 bg-yellow-50 rounded-base border-[3px] border-bw neo-brutalism">
          <h2 className="text-xl font-heading mb-2">Catatan</h2>
          <p className="text-mtext">
            Statistik ini hanya tersedia untuk pengguna Premium. Data yang ditampilkan adalah contoh untuk tujuan
            demonstrasi. Dalam aplikasi sebenarnya, data ini akan diperbarui secara real-time berdasarkan aktivitas
            profil Anda.
          </p>
        </div>
      </main>
    </div>
  )
}

