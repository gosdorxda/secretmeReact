"use server"

import { getSupabaseServer } from "@/lib/supabase/server"

export async function sendDirectMessage(content: string, recipientUsername: string, isPublic = true) {
  try {
    console.log("Server action received username:", recipientUsername) // Debug log
    console.log("Server action received content:", content) // Debug log
    console.log("Server action received isPublic:", isPublic) // Debug log

    if (!content || content.trim() === "") {
      return { error: "Pesan tidak boleh kosong" }
    }

    if (!recipientUsername) {
      console.error("Missing recipientUsername in server action")
      return { error: "Username penerima diperlukan" }
    }

    const supabase = getSupabaseServer()

    // Cari user berdasarkan username
    const { data: recipient, error: recipientError } = await supabase
      .from("users")
      .select("id")
      .eq("username", recipientUsername)
      .single()

    if (recipientError || !recipient) {
      console.error("Error finding recipient:", recipientError)
      return { error: "User tidak ditemukan" }
    }

    console.log("Found recipient in server action:", recipient) // Debug log

    // Kirim pesan
    const { data: messageData, error: messageError } = await supabase
      .from("messages")
      .insert({
        recipient_id: recipient.id,
        content,
        is_read: false,
        is_public: isPublic, // Use the passed isPublic value
        created_at: new Date().toISOString(),
      })
      .select()

    if (messageError) {
      console.error("Error inserting message:", messageError)
      return { error: "Gagal menyimpan pesan: " + messageError.message }
    }

    console.log("Message saved successfully:", messageData)

    // Increment message counter manually
    try {
      console.log("Server action: Attempting to increment message count for user ID:", recipient.id)

      // Call the RPC function directly
      const { data: incrementResult, error: incrementError } = await supabase.rpc("increment_message_count", {
        user_id_param: recipient.id,
      })

      if (incrementError) {
        console.error("Server action: Error calling increment_message_count RPC:", incrementError)

        // Fallback to direct update
        const { data: profileData } = await supabase
          .from("profiles")
          .select("total_messages")
          .eq("user_id", recipient.id)
          .single()

        const newCount = (profileData?.total_messages || 0) + 1

        const { error: updateError } = await supabase
          .from("profiles")
          .update({ total_messages: newCount })
          .eq("user_id", recipient.id)

        if (updateError) {
          console.error("Server action: Error in fallback update:", updateError)
        } else {
          console.log("Server action: Fallback update successful, new count:", newCount)
        }
      } else {
        console.log("Server action: RPC increment successful, new count:", incrementResult)
      }
    } catch (countError) {
      console.error("Server action: Error incrementing message count:", countError)
      // Continue even if counter fails
    }

    // Tambahkan notifikasi untuk penerima
    const { error: notifError } = await supabase.from("notifications").insert({
      user_id: recipient.id,
      type: "new_message",
      content: "Anda menerima pesan baru",
      is_read: false,
      created_at: new Date().toISOString(),
    })

    if (notifError) {
      console.error("Error creating notification (non-critical):", notifError)
      // Continue even if notification creation fails
    }

    return { success: true, message: messageData }
  } catch (error) {
    console.error("Unexpected error:", error)
    return { error: "Terjadi kesalahan yang tidak terduga" }
  }
}

