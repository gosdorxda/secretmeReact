"use client"

import type React from "react"

import { Button } from "@/components/ui/neo-button"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { sendDirectMessage } from "./direct-message-action"

interface MessageFormProps {
  username: string
}

export function MessageForm({ username }: MessageFormProps) {
  const [content, setContent] = useState("")
  const [isPublic, setIsPublic] = useState(true) // Default to public (TRUE)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!content.trim()) {
      setError("Pesan tidak boleh kosong")
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      // First try the API route
      try {
        console.log("Sending message to:", username) // Debug log
        console.log("Message is public:", isPublic) // Debug log

        const response = await fetch("/api/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            content: content.trim(),
            recipientUsername: username,
            is_public: isPublic, // Pass the public/private setting
          }),
        })

        if (!response.ok) {
          const result = await response.json()
          console.error("API route failed:", result)
          throw new Error(result.error || "Failed to send message")
        }

        const result = await response.json()

        if (result.success) {
          setContent("")
          setSuccess(true)

          // Reset success message after 3 seconds
          setTimeout(() => {
            setSuccess(false)
          }, 3000)
          return
        }
      } catch (apiError) {
        console.error("API route error, falling back to server action:", apiError)
      }

      // If API route fails, try the direct server action
      console.log("Falling back to server action with username:", username) // Debug log

      const result = await sendDirectMessage(content.trim(), username, isPublic)

      if (result.error) {
        throw new Error(result.error)
      }

      setContent("")
      setSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false)
      }, 3000)
    } catch (err) {
      console.error("Error sending message:", err)
      setError(err instanceof Error ? err.message : "Terjadi kesalahan saat mengirim pesan")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          name="content"
          placeholder="Tulis pesan anonim Anda di sini..."
          className="min-h-[150px] neo-input bg-blank"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={isLoading}
        />
      </div>

      {/* Public/Private option */}
      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="is-public"
          checked={isPublic}
          onChange={(e) => setIsPublic(e.target.checked)}
          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
        />
        <label htmlFor="is-public" className="text-sm font-medium text-gray-700">
          Tampilkan pesan ini di profil publik
        </label>
      </div>

      {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{error}</div>}

      {success && <div className="rounded-md bg-green-50 p-3 text-sm text-green-500">Pesan berhasil dikirim!</div>}

      <Button className="w-full" variant="blue" type="submit" disabled={isLoading || content.trim().length === 0}>
        {isLoading ? "Mengirim..." : "Kirim Pesan"}
      </Button>
    </form>
  )
}

export default MessageForm

