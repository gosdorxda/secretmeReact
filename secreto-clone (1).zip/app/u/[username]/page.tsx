import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { MessageForm } from "@/components/message-form"
import { PublicMessages } from "@/components/public-messages"
// Pertama, tambahkan import untuk ikon-ikon dari Lucide React
import { Instagram, Twitter, TwitterIcon as TikTok, Facebook, Linkedin } from "lucide-react"

// Tambahkan import untuk fungsi statistik
import { incrementProfileViewDirectly } from "@/actions/stats-actions"

type Props = {
  params: {
    username: string
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const username = params.username
  return {
    title: `Kirim Pesan Anonim ke ${username} | Secreto`,
    description: `Kirim pesan anonim ke ${username} melalui Secreto. Pesan Anda akan dirahasiakan.`,
  }
}

export default async function UserProfilePage({ params }: Props) {
  const { username } = params
  const supabase = createServerComponentClient({ cookies })

  // Fetch user data
  const { data: userData, error: userError } = await supabase
    .from("users")
    .select("id, username, display_name, avatar_url")
    .eq("username", username)
    .single()

  if (userError || !userData) {
    console.error("Error fetching user:", userError)
    notFound()
  }

  // Fetch profile data including social media links
  const { data: profileData, error: profileError } = await supabase
    .from("profiles")
    .select("bio, custom_url, instagram, twitter, tiktok, facebook, linkedin, total_views, total_messages")
    .eq("user_id", userData.id)
    .single()

  if (profileError) {
    console.error("Error fetching profile:", profileError)
  }

  // Fetch public messages
  const { data: messages, error: messagesError } = await supabase
    .from("messages")
    .select(`
      id,
      content,
      created_at,
      is_public,
      replies (
        id,
        content,
        created_at,
        user_id
      )
    `)
    .eq("recipient_id", userData.id)
    .eq("is_public", true)
    .order("created_at", { ascending: false })

  if (messagesError) {
    console.error("Error fetching messages:", messagesError)
  }

  // Check if message_attachments table exists before trying to query it
  let messagesWithAttachments = messages || []

  try {
    // First check if the table exists by querying system tables
    const { data: tableExists } = await supabase
      .from("information_schema.tables")
      .select("table_name")
      .eq("table_name", "message_attachments")
      .single()

    if (tableExists) {
      // Only fetch attachments if the table exists
      messagesWithAttachments = await Promise.all(
        (messages || []).map(async (message) => {
          try {
            const { data: attachments, error: attachmentsError } = await supabase
              .from("message_attachments")
              .select("id, url, file_name, file_type, file_size")
              .eq("message_id", message.id)

            if (attachmentsError) {
              console.error("Error fetching attachments:", attachmentsError)
              return message
            }

            if (attachments && attachments.length > 0) {
              return {
                ...message,
                attachments: attachments.map((attachment) => ({
                  id: attachment.id,
                  url: attachment.url,
                  fileName: attachment.file_name,
                  fileType: attachment.file_type,
                  fileSize: attachment.file_size,
                })),
              }
            }
            return message
          } catch (err) {
            console.error("Error processing attachments:", err)
            return message
          }
        }),
      )
    }
  } catch (error) {
    console.error("Error checking for message_attachments table:", error)
    // Continue without attachments
  }

  // Increment view counter dengan metode langsung
  const viewResult = await incrementProfileViewDirectly(userData.id)
  console.log("View increment result:", viewResult)

  // Ambil statistik profil dari database
  const databaseViews = profileData?.total_views || 0
  const databaseMessageCount = profileData?.total_messages || 0

  return (
    <div className="min-h-screen bg-bg">
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border-4 border-bw bg-main">
            {userData.avatar_url ? (
              <img
                src={userData.avatar_url || "/placeholder.svg"}
                alt={userData.display_name || userData.username}
                className="h-full w-full object-cover"
              />
            ) : (
              <span className="text-3xl font-heading text-white">{userData.username.charAt(0).toUpperCase()}</span>
            )}
          </div>
          <h1 className="text-2xl font-heading">{userData.display_name || userData.username}</h1>
          <p className="text-mtext">@{userData.username}</p>

          {/* Display bio if available */}
          {profileData?.bio && <p className="mt-2 text-sm max-w-md mx-auto">{profileData.bio}</p>}

          {/* Display social media links if available */}
          {profileData && (
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {profileData.instagram && (
                <a
                  href={profileData.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full text-sm font-medium shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5"
                >
                  <Instagram size={16} />
                  <span>Instagram</span>
                </a>
              )}
              {profileData.twitter && (
                <a
                  href={profileData.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-400 text-white rounded-full text-sm font-medium shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5"
                >
                  <Twitter size={16} />
                  <span>Twitter</span>
                </a>
              )}
              {profileData.tiktok && (
                <a
                  href={profileData.tiktok}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-black to-gray-800 text-white rounded-full text-sm font-medium shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5"
                >
                  <TikTok size={16} />
                  <span>TikTok</span>
                </a>
              )}
              {profileData.facebook && (
                <a
                  href={profileData.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-full text-sm font-medium shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5"
                >
                  <Facebook size={16} />
                  <span>Facebook</span>
                </a>
              )}
              {profileData.linkedin && (
                <a
                  href={profileData.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-700 text-white rounded-full text-sm font-medium shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5"
                >
                  <Linkedin size={16} />
                  <span>LinkedIn</span>
                </a>
              )}
            </div>
          )}

          {/* Call to action untuk mendaftar - subtle version */}
          <div className="mt-6">
            <p className="text-center text-xs font-light text-gray-500 opacity-80">
              Ingin menerima pesan anonim juga?{" "}
              <a href="/register" className="text-blue-500 hover:text-blue-700">
                Daftar sekarang
              </a>{" "}
              dan dapatkan link profil Anda sendiri.
            </p>
          </div>
        </div>

        <div className="mb-8">
          <MessageForm recipientId={userData.id} recipientUsername={userData.username} />
        </div>

        <div className="mt-12">
          <h2 className="mb-4 text-xl font-heading">Pesan Publik</h2>
          <PublicMessages messages={messagesWithAttachments || []} username={userData.username} />
        </div>
      </div>
    </div>
  )
}

