import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"

export default function UnauthorizedPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-4">
      <Card className="w-full max-w-md neo-brutalism">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-heading text-center">Akses Ditolak</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <div className="p-3 rounded-md bg-red-100 border-2 border-red-300 text-red-800">
            Anda tidak memiliki izin untuk mengakses halaman ini.
          </div>
          <p className="text-mtext">
            Halaman ini hanya dapat diakses oleh administrator. Jika Anda yakin seharusnya memiliki akses, silakan
            hubungi administrator sistem.
          </p>
          <div className="flex flex-col gap-2">
            <Button asChild variant="blue">
              <Link href="/">Kembali ke Beranda</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/login">Login dengan Akun Lain</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

