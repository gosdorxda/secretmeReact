"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { Check, AlertTriangle } from "lucide-react"

export default function VerifyEmailPage() {
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get("token")

  useEffect(() => {
    async function verifyEmail() {
      if (!token) {
        setStatus("error")
        return
      }

      try {
        // Dalam aplikasi sebenarnya, Anda akan mengirim token ke backend untuk verifikasi
        // Untuk demo, kita akan mensimulasikan verifikasi
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // Simulasi verifikasi berhasil
        setStatus("success")
      } catch (error) {
        console.error("Error verifying email:", error)
        setStatus("error")
      }
    }

    verifyEmail()
  }, [token, router])

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center p-4">
      <Card
        className="max-w-md w-full"
        color={status === "success" ? "bg-green-50" : status === "error" ? "bg-red-50" : "bg-blank"}
      >
        <CardHeader>
          <CardTitle className="text-2xl text-center">Verifikasi Email</CardTitle>
        </CardHeader>
        <CardContent className="p-8 text-center">
          {status === "loading" && (
            <>
              <div className="mx-auto h-16 w-16 border-4 border-t-main border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-mtext">Memverifikasi email Anda...</p>
            </>
          )}

          {status === "success" && (
            <>
              <div className="mx-auto h-16 w-16 flex items-center justify-center rounded-full bg-green-500 text-white mb-4">
                <Check className="h-8 w-8" />
              </div>
              <h2 className="text-xl font-heading mb-2">Email Berhasil Diverifikasi!</h2>
              <p className="text-mtext mb-6">
                Terima kasih telah memverifikasi email Anda. Sekarang Anda dapat menggunakan semua fitur Secreto.
              </p>
              <Button asChild variant="blue">
                <Link href="/dashboard">Lanjut ke Dashboard</Link>
              </Button>
            </>
          )}

          {status === "error" && (
            <>
              <div className="mx-auto h-16 w-16 flex items-center justify-center rounded-full bg-red-500 text-white mb-4">
                <AlertTriangle className="h-8 w-8" />
              </div>
              <h2 className="text-xl font-heading mb-2">Verifikasi Gagal</h2>
              <p className="text-mtext mb-6">
                Link verifikasi tidak valid atau sudah kadaluarsa. Silakan coba lagi atau minta link verifikasi baru.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild variant="outline">
                  <Link href="/login">Kembali ke Login</Link>
                </Button>
                <Button asChild variant="blue">
                  <Link href="/resend-verification">Kirim Ulang Verifikasi</Link>
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

