"use client"

import Link from "next/link"
import { Button } from "@/components/ui/neo-button"

interface AdminHeaderProps {
  onLogout: () => void
  adminEmail?: string
}

export function AdminHeader({ onLogout, adminEmail }: AdminHeaderProps) {
  return (
    <header className="flex h-16 items-center border-b-[3px] border-bw px-4 md:px-6 bg-blank">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2 font-heading text-xl">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-main border-[3px] border-bw">
            S
          </div>
          <span>Secreto</span>
        </Link>
        <div className="flex items-center gap-4">
          {adminEmail && (
            <div className="text-sm font-heading mr-2">
              Admin: <span className="text-blue-600">{adminEmail}</span>
            </div>
          )}
          <Button variant="outline" size="sm" onClick={onLogout}>
            Logout Admin
          </Button>
        </div>
      </div>
    </header>
  )
}

