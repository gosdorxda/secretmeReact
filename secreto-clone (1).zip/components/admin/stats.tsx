"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { getSupabaseClient } from "@/lib/supabase/client"

export function AdminStats() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    premiumUsers: 0,
    totalMessages: 0,
    conversionRate: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = getSupabaseClient()

  useEffect(() => {
    async function fetchStats() {
      try {
        setLoading(true)
        setError(null)

        // Fetch total users
        const { count: totalUsers, error: usersError } = await supabase
          .from("users")
          .select("*", { count: "exact", head: true })

        if (usersError) {
          throw usersError
        }

        // Fetch premium users
        const { count: premiumUsers, error: premiumError } = await supabase
          .from("users")
          .select("*", { count: "exact", head: true })
          .eq("is_premium", true)

        if (premiumError) {
          throw premiumError
        }

        // Fetch total messages
        const { count: totalMessages, error: messagesError } = await supabase
          .from("messages")
          .select("*", { count: "exact", head: true })

        if (messagesError) {
          throw messagesError
        }

        // Calculate conversion rate
        const conversionRate = totalUsers > 0 ? Math.round((premiumUsers / totalUsers) * 100) : 0

        setStats({
          totalUsers: totalUsers || 0,
          premiumUsers: premiumUsers || 0,
          totalMessages: totalMessages || 0,
          conversionRate,
        })
      } catch (err) {
        console.error("Error fetching stats:", err)
        setError("Gagal memuat statistik")
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [supabase])

  if (loading) {
    return (
      <Card color="bg-blank">
        <CardContent className="p-6">
          <div className="text-center py-8">Memuat statistik...</div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card color="bg-blank">
        <CardContent className="p-6">
          <div className="rounded-md bg-red-50 p-3 mb-4 text-sm text-red-500">{error}</div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card color="bg-blank">
      <CardHeader>
        <CardTitle>Statistik Aplikasi</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-blue-50">
            <div className="text-3xl font-heading">{stats.totalUsers}</div>
            <div className="text-sm text-mtext">Total Pengguna</div>
          </div>

          <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-green-50">
            <div className="text-3xl font-heading">{stats.premiumUsers}</div>
            <div className="text-sm text-mtext">Pengguna Premium</div>
          </div>

          <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-purple-50">
            <div className="text-3xl font-heading">{stats.conversionRate}%</div>
            <div className="text-sm text-mtext">Rasio Konversi Premium</div>
          </div>

          <div className="rounded-base border-[3px] border-bw p-6 neo-brutalism bg-pink-50">
            <div className="text-3xl font-heading">{stats.totalMessages}</div>
            <div className="text-sm text-mtext">Total Pesan</div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-yellow-50 rounded-base border-[3px] border-bw neo-brutalism">
          <h2 className="text-xl font-heading mb-2">Catatan Admin</h2>
          <p className="text-mtext">
            Panel admin ini memungkinkan Anda untuk melihat statistik aplikasi secara real-time. Data ini diambil lang
            Anda untuk melihat statistik aplikasi secara real-time. Data ini diambil langsung dari database Supabase dan
            diperbarui setiap kali halaman dimuat.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

