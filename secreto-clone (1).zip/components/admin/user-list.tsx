"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/neo-button"
import { Input } from "@/components/ui/neo-input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"
import { getSupabaseClient } from "@/lib/supabase/client"

type User = {
  id: string
  username: string
  email: string
  display_name?: string
  is_premium: boolean
  premium_expires_at?: string
  created_at: string
}

export function AdminUserList() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const supabase = getSupabaseClient()

  // Fungsi untuk mengambil data pengguna dari database
  async function fetchUsers() {
    try {
      setLoading(true)
      setError(null)

      const { data, error } = await supabase
        .from("users")
        .select("id, username, email, display_name, is_premium, premium_expires_at, created_at")
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching users:", error)
        setError("Gagal memuat data pengguna")
        return
      }

      console.log("Fetched users:", data)
      setUsers(data || [])
    } catch (err) {
      console.error("Unexpected error:", err)
      setError("Terjadi kesalahan yang tidak terduga")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  async function togglePremiumStatus(userId: string, currentStatus: boolean) {
    try {
      setError(null)
      setSuccess(null)

      // Update status premium di database
      // Tidak perlu set tanggal kadaluarsa karena premium seumur hidup
      const { error: updateError } = await supabase
        .from("users")
        .update({
          is_premium: !currentStatus,
          premium_expires_at: null, // Set null karena tidak ada tanggal kadaluarsa
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) {
        console.error("Error updating premium status:", updateError)
        setError("Gagal mengubah status premium: " + updateError.message)
        return
      }

      // Juga update atau buat record subscription untuk menjaga konsistensi
      if (!currentStatus) {
        // Membuat subscription premium baru (seumur hidup)
        const { error: subscriptionError } = await supabase.from("subscriptions").insert({
          user_id: userId,
          plan_type: "premium_lifetime", // Ubah tipe plan menjadi premium_lifetime
          status: "active",
          starts_at: new Date().toISOString(),
          expires_at: null, // Set null karena tidak ada tanggal kadaluarsa
        })

        if (subscriptionError && subscriptionError.code !== "23505") {
          // Abaikan error duplicate key
          console.error("Error creating subscription:", subscriptionError)
          // Lanjutkan meskipun ini gagal
        }
      } else {
        // Membatalkan subscription yang ada
        const { error: subscriptionError } = await supabase
          .from("subscriptions")
          .update({
            status: "cancelled",
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", userId)
          .eq("status", "active")

        if (subscriptionError) {
          console.error("Error updating subscription:", subscriptionError)
          // Lanjutkan meskipun ini gagal
        }
      }

      // Update data di state
      setUsers(
        users.map((user) => {
          if (user.id === userId) {
            return {
              ...user,
              is_premium: !currentStatus,
              premium_expires_at: null, // Set null karena tidak ada tanggal kadaluarsa
            }
          }
          return user
        }),
      )

      setSuccess(`Status premium berhasil ${!currentStatus ? "diaktifkan" : "dinonaktifkan"}`)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      console.error("Error updating premium status:", err)
      setError("Gagal mengubah status premium")
    }
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.display_name && user.display_name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  return (
    <Card color="bg-blank">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Daftar Pengguna</CardTitle>
        <div className="w-64">
          <Input placeholder="Cari pengguna..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
      </CardHeader>
      <CardContent>
        {error && <div className="rounded-md bg-red-50 p-3 mb-4 text-sm text-red-500">{error}</div>}
        {success && <div className="rounded-md bg-green-50 p-3 mb-4 text-sm text-green-500">{success}</div>}

        {loading ? (
          <div className="text-center py-8">Memuat data pengguna...</div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-8 text-mtext">Tidak ada pengguna yang ditemukan.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b-2 border-bw">
                  <th className="py-2 px-4 text-left">Username</th>
                  <th className="py-2 px-4 text-left">Email</th>
                  <th className="py-2 px-4 text-left">Nama</th>
                  <th className="py-2 px-4 text-left">Tgl Daftar</th>
                  <th className="py-2 px-4 text-left">Status Premium</th>
                  <th className="py-2 px-4 text-left">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-2 px-4">{user.username}</td>
                    <td className="py-2 px-4">{user.email}</td>
                    <td className="py-2 px-4">{user.display_name || "-"}</td>
                    <td className="py-2 px-4">{new Date(user.created_at).toLocaleDateString("id-ID")}</td>
                    <td className="py-2 px-4">
                      <div className="flex items-center gap-2">
                        <div
                          className={`h-3 w-3 rounded-full ${user.is_premium ? "bg-green-500" : "bg-gray-400"}`}
                        ></div>
                        <span className={`text-sm ${user.is_premium ? "text-green-600" : "text-gray-600"}`}>
                          {user.is_premium ? "Premium" : "Free"}
                        </span>
                      </div>
                    </td>
                    <td className="py-2 px-4">
                      <Button
                        variant={user.is_premium ? "outline" : "blue"}
                        size="sm"
                        onClick={() => togglePremiumStatus(user.id, user.is_premium)}
                      >
                        {user.is_premium ? "Nonaktifkan Premium" : "Aktifkan Premium"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

