"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface Message {
  id: number
  avatar: string
  avatarBg: string
  time: string
  content: string
  rotate: number
  bg: string
}

export function AnimatedMessageCards() {
  const messages: Message[] = [
    {
      id: 1,
      avatar: "A",
      avatarBg: "bg-purple-400",
      time: "Pesan Anonim • Baru saja",
      content:
        "Presentasimu minggu lalu sangat menginspirasi! Kamu punya cara yang bagus untuk menjelaskan konsep yang kompleks dengan sederhana.",
      rotate: 3,
      bg: "bg-blank",
    },
    {
      id: 2,
      avatar: "A",
      avatarBg: "bg-blue-400",
      time: "Pesan Anonim • 5 menit yang lalu",
      content: "Kamu selalu bisa diandalkan saat saya butuh bantuan. Terima kasih sudah menjadi teman yang baik!",
      rotate: -6,
      bg: "bg-pink-100",
    },
    {
      id: 3,
      avatar: "A",
      avatarBg: "bg-green-400",
      time: "Pesan Anonim • 10 menit yang lalu",
      content: "Ide-idemu di rapat kemarin sangat kreatif! Kita harus sering berkolaborasi di masa depan.",
      rotate: 5,
      bg: "bg-blue-100",
    },
    {
      id: 4,
      avatar: "A",
      avatarBg: "bg-pink-400",
      time: "Pesan Anonim • 1 jam yang lalu",
      content:
        "Terima kasih sudah selalu mendengarkan. Kamu adalah pendengar yang sangat baik dan memberikan saran yang bijak.",
      rotate: -4,
      bg: "bg-green-100",
    },
  ]

  const [activeIndex, setActiveIndex] = useState(0)
  const [secondaryIndex, setSecondaryIndex] = useState(1)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % messages.length)
      setSecondaryIndex((current) => (current + 1) % messages.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [messages.length])

  return (
    <div className="relative flex-1">
      <AnimatePresence mode="wait">
        <motion.div
          key={`primary-${activeIndex}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className={`relative z-10 rounded-base border-[3px] border-bw ${messages[activeIndex].bg} p-6 neo-brutalism rotate-${messages[activeIndex].rotate} transform transition-transform hover:rotate-0`}
        >
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full ${messages[activeIndex].avatarBg} border-2 border-bw flex items-center justify-center text-sm font-heading text-white`}
              >
                {messages[activeIndex].avatar}
              </div>
              <div>
                <div className="text-xs text-mtext">{messages[activeIndex].time}</div>
                <div className="text-sm font-heading">Untuk: @username</div>
              </div>
            </div>
            <p className="text-base font-base">{messages[activeIndex].content}</p>
            <div className="flex justify-end">
              <button className="rounded-md border-2 border-bw bg-blank px-3 py-1 text-sm font-medium hover:bg-gray-100">
                Balas
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      <AnimatePresence mode="wait">
        <motion.div
          key={`secondary-${secondaryIndex}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className={`absolute top-12 -right-4 z-0 rounded-base border-[3px] border-bw ${messages[secondaryIndex].bg} p-6 neo-brutalism -rotate-${Math.abs(messages[secondaryIndex].rotate)} transform transition-transform hover:rotate-0`}
        >
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full ${messages[secondaryIndex].avatarBg} border-2 border-bw flex items-center justify-center text-sm font-heading text-white`}
              >
                {messages[secondaryIndex].avatar}
              </div>
              <div>
                <div className="text-xs text-mtext">{messages[secondaryIndex].time}</div>
                <div className="text-sm font-heading">Untuk: @username</div>
              </div>
            </div>
            <p className="text-base font-base">{messages[secondaryIndex].content}</p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

