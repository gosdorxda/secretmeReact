"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient } from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, LogOut, Settings, UserIcon } from "lucide-react"

export function AuthStatus() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = getSupabaseClient()

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Cek status autentikasi saat komponen dimount
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [supabase])

  if (loading) {
    return null
  }

  if (!user) {
    return (
      <div className="flex gap-4">
        <Button asChild variant="outline" size="sm">
          <Link href="/login">Masuk</Link>
        </Button>
        <Button asChild variant="blue" size="sm">
          <Link href="/register">Daftar</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-4">
      <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
        <Bell className="h-5 w-5" />
        <span className="sr-only">Notifikasi</span>
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="h-10 w-10 rounded-full p-0">
            <Avatar className="h-full w-full border-2 border-bw">
              <AvatarImage src="/placeholder.svg" alt="@user" />
              <AvatarFallback className="bg-purple-400 text-blank font-heading">
                {user.email?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 border-[3px] border-bw shadow-shadow" align="end" forceMount>
          <DropdownMenuLabel className="font-base">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-heading leading-none">{user.email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator className="border-bw" />
          <DropdownMenuItem className="font-base" asChild>
            <Link href="/dashboard">
              <UserIcon className="mr-2 h-4 w-4" />
              <span>Dashboard</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem className="font-base" asChild>
            <Link href="/settings">
              <Settings className="mr-2 h-4 w-4" />
              <span>Pengaturan</span>
            </Link>
          </DropdownMenuItem>
          <DropdownMenuSeparator className="border-bw" />
          <DropdownMenuItem className="font-base" asChild>
            <form action="/api/auth/logout" method="post">
              <button className="flex w-full items-center">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Keluar</span>
              </button>
            </form>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}

