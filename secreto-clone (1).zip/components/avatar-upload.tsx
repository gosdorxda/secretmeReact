"use client"

import type React from "react"

import { useState, useRef } from "react"
import Image from "next/image"
import { uploadAvatarAction, deleteAvatarAction } from "@/actions/storage-actions"
import { useToast } from "@/hooks/use-toast"

interface AvatarUploadProps {
  userId: string
  currentAvatarUrl?: string | null
  onAvatarChange?: (url: string | null) => void
  className?: string
}

export function AvatarUpload({ userId, currentAvatarUrl, onAvatarChange, className = "" }: AvatarUploadProps) {
  const [avatarUrl, setAvatarUrl] = useState<string | null>(currentAvatarUrl || null)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Reset error state
    setError(null)

    // Validasi tipe file
    if (!["image/jpeg", "image/png", "image/webp", "image/jpg"].includes(file.type)) {
      toast({
        title: "Error",
        description: "Hanya file gambar (JPG, PNG, WEBP) yang diperbolehkan",
        variant: "destructive",
      })
      return
    }

    // Validasi ukuran file (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "Error",
        description: "Ukuran file maksimal 2MB",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    try {
      // Buat FormData untuk upload
      const formData = new FormData()
      formData.append("file", file)
      formData.append("userId", userId)

      // Upload avatar
      const result = await uploadAvatarAction(formData)

      if (result.error) {
        console.error("Error uploading avatar:", result.error)
        setError(`Gagal mengunggah avatar: ${result.error}`)
        setIsUploading(false)
        toast({
          title: "Error",
          description: `Gagal mengunggah avatar: ${result.error}`,
          variant: "destructive",
        })
        return
      }

      if (result.success) {
        setAvatarUrl(result.url)
        if (onAvatarChange) {
          onAvatarChange(result.url)
        }
        toast({
          title: "Success",
          description: "Avatar uploaded successfully",
        })
      }
    } catch (error) {
      console.error("Error uploading avatar:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to upload avatar",
        variant: "destructive",
      })
      setError("Terjadi kesalahan saat mengunggah avatar")
    } finally {
      setIsUploading(false)
    }
  }

  const handleRemoveAvatar = async () => {
    if (!avatarUrl) return

    setIsUploading(true)

    try {
      // Ekstrak nama file dari URL
      const fileName = avatarUrl.split("/").pop()
      if (!fileName) {
        throw new Error("Invalid avatar URL")
      }

      // Hapus avatar
      const result = await deleteAvatarAction(fileName, userId)

      if (result.error) {
        throw new Error(result.error)
      }

      if (result.success) {
        setAvatarUrl(null)
        if (onAvatarChange) {
          onAvatarChange(null)
        }
        toast({
          title: "Success",
          description: "Avatar removed successfully",
        })
      }
    } catch (error) {
      console.error("Error removing avatar:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove avatar",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="relative mb-4">
        {avatarUrl ? (
          <Image
            src={avatarUrl || "/placeholder.svg"}
            alt="Avatar"
            width={100}
            height={100}
            className="rounded-full object-cover"
            style={{ width: "100px", height: "100px" }}
          />
        ) : (
          <div
            className="flex items-center justify-center rounded-full bg-gray-200 text-gray-500"
            style={{ width: "100px", height: "100px" }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="40"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </div>
        )}
        {isUploading && (
          <div className="absolute inset-0 flex items-center justify-center rounded-full bg-black bg-opacity-50">
            <svg
              className="h-8 w-8 animate-spin text-white"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
          </div>
        )}
      </div>
      <div className="flex space-x-2">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600 disabled:opacity-50"
        >
          {avatarUrl ? "Change" : "Upload"}
        </button>
        {avatarUrl && (
          <button
            type="button"
            onClick={handleRemoveAvatar}
            disabled={isUploading}
            className="rounded bg-red-500 px-3 py-1 text-sm text-white hover:bg-red-600 disabled:opacity-50"
          >
            Remove
          </button>
        )}
        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
      </div>
      {error && <div className="text-red-500 text-sm mt-2">{error}</div>}
    </div>
  )
}

