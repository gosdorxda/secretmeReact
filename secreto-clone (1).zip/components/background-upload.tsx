"use client"

import type React from "react"

import { useState, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/neo-button"
import { uploadBackground } from "@/lib/supabase/storage"

interface BackgroundUploadProps {
  userId: string
  currentBackgroundUrl?: string | null
  onSuccess?: (url: string) => void
}

export function BackgroundUpload({ userId, currentBackgroundUrl, onSuccess }: BackgroundUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentBackgroundUrl || null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validasi tipe file
    if (!file.type.startsWith("image/")) {
      alert("Hanya file gambar yang diperbolehkan")
      return
    }

    // Validasi ukuran file (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert("Ukuran file maksimal 5MB")
      return
    }

    // Tampilkan preview
    const reader = new FileReader()
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string)
    }
    reader.readAsDataURL(file)

    // Unggah file
    setIsUploading(true)
    try {
      const url = await uploadBackground(file, userId)

      // Update profil pengguna - remove background_url
      // Comment out this line since the column doesn't exist
      // await updateProfile({ background_url: url })

      if (onSuccess) {
        onSuccess(url)
      }
    } catch (error) {
      console.error("Error uploading background:", error)
      alert("Gagal mengunggah gambar latar belakang")
    } finally {
      setIsUploading(false)
    }
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="relative h-40 w-full overflow-hidden rounded-lg border-2 border-bw bg-gray-100">
        {previewUrl ? (
          <Image src={previewUrl || "/placeholder.svg"} alt="Background" fill className="object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xl font-bold text-gray-400">
            Belum ada gambar latar belakang
          </div>
        )}
      </div>

      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

      <Button onClick={triggerFileInput} disabled={isUploading} variant="outline" size="sm">
        {isUploading ? "Mengunggah..." : "Ubah Latar Belakang"}
      </Button>
    </div>
  )
}

