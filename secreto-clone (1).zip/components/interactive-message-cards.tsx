"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/neo-button"

export function InteractiveMessageCards() {
  const [isFlipped, setIsFlipped] = useState(false)

  const handleInteraction = () => {
    setIsFlipped(!isFlipped)
  }

  return (
    <div
      className="flex-1 relative h-[300px]"
      onClick={handleInteraction}
      onMouseEnter={handleInteraction}
      onMouseLeave={handleInteraction}
    >
      <motion.div
        initial={false}
        animate={{
          zIndex: isFlipped ? 0 : 10,
          x: isFlipped ? -20 : 0,
          y: isFlipped ? 20 : 0,
          opacity: isFlipped ? 0.8 : 1,
          rotate: isFlipped ? -6 : 3,
          scale: isFlipped ? 0.95 : 1,
        }}
        transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
        className="absolute rounded-base border-[3px] border-bw bg-blank p-6 neo-brutalism transform cursor-pointer"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-purple-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
              A
            </div>
            <div>
              <div className="text-xs text-mtext">Pesan Anonim • Baru saja</div>
              <div className="text-sm font-heading">Untuk: @username</div>
            </div>
          </div>
          <p className="text-base font-base">
            Presentasimu minggu lalu sangat menginspirasi! Kamu punya cara yang bagus untuk menjelaskan konsep yang
            kompleks dengan sederhana.
          </p>
          <div className="flex justify-end">
            <Button variant="outline" size="sm">
              Balas
            </Button>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={false}
        animate={{
          zIndex: isFlipped ? 10 : 0,
          x: isFlipped ? 0 : 20,
          y: isFlipped ? 0 : 40,
          opacity: isFlipped ? 1 : 0.8,
          rotate: isFlipped ? 3 : -6,
          scale: isFlipped ? 1 : 0.95,
        }}
        transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
        className="absolute rounded-base border-[3px] border-bw bg-pink-100 p-6 neo-brutalism transform cursor-pointer"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-blue-400 border-2 border-bw flex items-center justify-center text-sm font-heading text-white">
              A
            </div>
            <div>
              <div className="text-xs text-mtext">Pesan Anonim • 5 menit yang lalu</div>
              <div className="text-sm font-heading">Untuk: @username</div>
            </div>
          </div>
          <p className="text-base font-base">
            Kamu selalu bisa diandalkan saat saya butuh bantuan. Terima kasih sudah menjadi teman yang baik!
          </p>
        </div>
      </motion.div>
    </div>
  )
}

