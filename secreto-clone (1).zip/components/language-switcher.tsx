"use client"

import { useI18n } from "./i18n-provider"
import { Button } from "@/components/ui/neo-button"

export function LanguageSwitcher() {
  const { language, setLanguage, t } = useI18n()

  return (
    <div className="flex items-center gap-2">
      <Button
        variant={language === "id" ? "default" : "outline"}
        size="sm"
        onClick={() => setLanguage("id")}
        className="px-3 py-1 h-8"
      >
        ID
      </Button>
      <Button
        variant={language === "en" ? "default" : "outline"}
        size="sm"
        onClick={() => setLanguage("en")}
        className="px-3 py-1 h-8"
      >
        EN
      </Button>
    </div>
  )
}

