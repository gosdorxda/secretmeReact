"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/neo-button"
import { uploadMessageAttachment } from "@/lib/supabase/storage"
import { Paperclip, X, File, Image } from "lucide-react"

interface MessageAttachmentUploadProps {
  onAttach: (attachment: {
    url: string
    fileName: string
    fileType: string
    fileSize: number
  }) => void
  onRemove: (url: string) => void
  attachments: Array<{
    url: string
    fileName: string
    fileType: string
    fileSize: number
  }>
  messageId?: string
}

export function MessageAttachmentUpload({
  onAttach,
  onRemove,
  attachments,
  messageId = "temp",
}: MessageAttachmentUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validasi tipe file
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg", "image/webp", "application/pdf"]
    if (!allowedTypes.includes(file.type)) {
      alert("Hanya file gambar dan PDF yang diperbolehkan")
      return
    }

    // Validasi ukuran file (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert("Ukuran file maksimal 5MB")
      return
    }

    // Unggah file
    setIsUploading(true)
    try {
      const attachment = await uploadMessageAttachment(file, messageId)
      onAttach(attachment)
    } catch (error) {
      console.error("Error uploading attachment:", error)
      alert("Gagal mengunggah lampiran")
    } finally {
      setIsUploading(false)
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={triggerFileInput}
          disabled={isUploading}
          className="flex items-center gap-1"
        >
          <Paperclip className="h-4 w-4" />
          {isUploading ? "Mengunggah..." : "Lampirkan File"}
        </Button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/png,image/jpeg,image/jpg,image/webp,application/pdf"
          className="hidden"
        />
        <p className="text-xs text-muted-foreground">Maks. 5MB (Gambar, PDF)</p>
      </div>

      {attachments.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Lampiran:</p>
          <div className="space-y-2">
            {attachments.map((attachment) => (
              <div key={attachment.url} className="flex items-center justify-between rounded-md border p-2 text-sm">
                <div className="flex items-center gap-2">
                  {attachment.fileType.startsWith("image/") ? (
                    <Image className="h-4 w-4" />
                  ) : (
                    <File className="h-4 w-4" />
                  )}
                  <span className="truncate max-w-[200px]">{attachment.fileName}</span>
                  <span className="text-xs text-muted-foreground">({formatFileSize(attachment.fileSize)})</span>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemove(attachment.url)}
                  className="h-6 w-6 p-0"
                >
                  <X className="h-4 w-4" />
                  <span className="sr-only">Hapus</span>
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

