"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/neo-button"
import { File, Download, X, Maximize } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog"

interface MessageAttachmentViewerProps {
  attachments: Array<{
    url: string
    fileName: string
    fileType: string
    fileSize: number
  }>
}

export function MessageAttachmentViewer({ attachments }: MessageAttachmentViewerProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [imageError, setImageError] = useState<Record<string, boolean>>({})

  if (!attachments || attachments.length === 0) {
    return null
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  const handleImageError = (url: string) => {
    setImageError((prev) => ({ ...prev, [url]: true }))
  }

  return (
    <div className="mt-3 space-y-2">
      <p className="text-sm font-medium">Lampiran:</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {attachments.map((attachment) => (
          <div key={attachment.url} className="relative overflow-hidden rounded-md border bg-gray-50 p-2">
            {attachment.fileType.startsWith("image/") && !imageError[attachment.url] ? (
              <div className="space-y-1">
                <div className="relative aspect-square w-full overflow-hidden rounded-md">
                  <Image
                    src={attachment.url || "/placeholder.svg"}
                    alt={attachment.fileName}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 33vw"
                    onError={() => handleImageError(attachment.url)}
                  />
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="absolute right-1 top-1 h-6 w-6 rounded-full bg-white/80 p-1"
                        onClick={() => setSelectedImage(attachment.url)}
                      >
                        <Maximize className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-xl">
                      <DialogHeader>
                        <DialogTitle>{attachment.fileName}</DialogTitle>
                        <DialogClose className="absolute right-4 top-4">
                          <X className="h-4 w-4" />
                          <span className="sr-only">Close</span>
                        </DialogClose>
                      </DialogHeader>
                      <div className="relative aspect-auto h-[60vh] w-full">
                        <Image
                          src={attachment.url || "/placeholder.svg"}
                          alt={attachment.fileName}
                          fill
                          className="object-contain"
                          sizes="(max-width: 768px) 100vw, 80vw"
                          onError={() => handleImageError(attachment.url)}
                        />
                      </div>
                      <div className="flex justify-end">
                        <Button asChild variant="outline" size="sm">
                          <a href={attachment.url} download target="_blank" rel="noopener noreferrer">
                            <Download className="mr-2 h-4 w-4" />
                            Unduh
                          </a>
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                <div className="truncate text-xs">{attachment.fileName}</div>
                <div className="text-xs text-muted-foreground">{formatFileSize(attachment.fileSize)}</div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center space-y-2 py-2">
                <File className="h-8 w-8 text-blue-500" />
                <div className="truncate text-xs text-center w-full">{attachment.fileName}</div>
                <div className="text-xs text-muted-foreground">{formatFileSize(attachment.fileSize)}</div>
                <Button asChild variant="outline" size="sm">
                  <a href={attachment.url} download target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-3 w-3" />
                    Unduh
                  </a>
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

