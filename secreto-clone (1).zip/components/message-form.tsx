"use client"

import type React from "react"

import { Button } from "@/components/ui/neo-button"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { sendDirectMessage } from "@/app/u/[username]/direct-message-action"

interface MessageFormProps {
  recipientId: string
  recipientUsername: string
}

export function MessageForm({ recipientId, recipientUsername }: MessageFormProps) {
  const [content, setContent] = useState("")
  const isPublic = true // All messages sent through profile are public by default
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!content.trim()) {
      setError("Pesan tidak boleh kosong")
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      // First try the API route
      try {
        const response = await fetch("/api/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            content: content.trim(),
            recipientUsername: recipientUsername,
            is_public: isPublic,
          }),
        })

        if (!response.ok) {
          const result = await response.json()
          throw new Error(result.error || "Failed to send message")
        }

        const result = await response.json()

        if (result.success) {
          setContent("")
          setSuccess(true)

          // Reset success message after 3 seconds
          setTimeout(() => {
            setSuccess(false)
          }, 3000)
          return
        }
      } catch (apiError) {
        console.error("API route error, falling back to server action:", apiError)
      }

      // If API route fails, try the direct server action
      const result = await sendDirectMessage(content.trim(), recipientUsername, isPublic)

      if (result.error) {
        throw new Error(result.error)
      }

      setContent("")
      setSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false)
      }, 3000)
    } catch (err) {
      console.error("Error sending message:", err)
      setError(err instanceof Error ? err.message : "Terjadi kesalahan saat mengirim pesan")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Tulis pesan anonim Anda di sini..."
          className="min-h-[150px] neo-input bg-blank"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={isLoading}
        />
      </div>

      {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{error}</div>}

      {success && <div className="rounded-md bg-green-50 p-3 text-sm text-green-500">Pesan berhasil dikirim!</div>}

      <Button className="w-full" variant="blue" type="submit" disabled={isLoading || content.trim().length === 0}>
        {isLoading ? "Mengirim..." : "Kirim Pesan"}
      </Button>
    </form>
  )
}

