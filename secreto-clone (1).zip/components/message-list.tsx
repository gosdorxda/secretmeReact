"use client"

import { useEffect, useState, useCallback } from "react"
import { getSupabaseClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent } from "@/components/ui/neo-card"
import { formatDistanceToNow } from "date-fns"
import { id } from "date-fns/locale"
import { MessageAttachmentViewer } from "@/components/message-attachment-viewer"
import { Eye, EyeOff } from "lucide-react"
import { ReplyForm } from "@/components/reply-form"
import { useRouter } from "next/navigation"

type MessageAttachment = {
  id: string
  url: string
  fileName: string
  fileType: string
  fileSize: number
}

type Message = {
  id: string
  content: string
  created_at: string
  is_public: boolean
  replies: Reply[]
  attachments?: MessageAttachment[]
}

type Reply = {
  id: string
  content: string
  created_at: string
  user_id?: string
}

export function MessageList({ userId, username }: { userId: string; username: string }) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [updatingMessage, setUpdatingMessage] = useState<string | null>(null)
  const [allMessagesPublic, setAllMessagesPublic] = useState(true)
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const supabase = getSupabaseClient()
  const router = useRouter()

  const fetchMessages = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      console.log("Fetching messages for user ID:", userId)

      // First, check if there are any messages
      const { count, error: countError } = await supabase
        .from("messages")
        .select("*", { count: "exact", head: true })
        .eq("recipient_id", userId)

      if (countError) {
        console.error("Error counting messages:", countError)
        throw countError
      }

      console.log("Message count:", count)

      if (count === 0) {
        setMessages([])
        setLoading(false)
        return
      }

      // Then fetch the actual messages
      const { data, error } = await supabase
        .from("messages")
        .select(`
          id,
          content,
          created_at,
          is_public,
          replies (
            id,
            content,
            created_at,
            user_id
          )
        `)
        .eq("recipient_id", userId)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching messages:", error)
        throw error
      }

      console.log("Fetched messages:", data?.length || 0, data)

      // Set messages without attachments first
      const messagesWithoutAttachments = data || []
      setMessages(messagesWithoutAttachments)

      // Check if all messages are public to set the initial toggle state
      const allPublic = messagesWithoutAttachments.every((msg) => msg.is_public)
      setAllMessagesPublic(allPublic)

      // Try to fetch attachments, but don't fail if the table doesn't exist
      try {
        // Check if the message_attachments table exists
        const { error: tableCheckError } = await supabase
          .from("message_attachments")
          .select("id")
          .limit(1)
          .throwOnError()

        // If we get here, the table exists, so we can fetch attachments
        if (!tableCheckError) {
          const messagesWithAttachments = await Promise.all(
            (data || []).map(async (message) => {
              try {
                const { data: attachments, error: attachmentsError } = await supabase
                  .from("message_attachments")
                  .select("id, url, file_name, file_type, file_size")
                  .eq("message_id", message.id)

                if (attachmentsError) {
                  console.error("Error fetching attachments for message:", attachmentsError)
                  return message
                }

                if (attachments && attachments.length > 0) {
                  return {
                    ...message,
                    attachments: attachments.map((attachment) => ({
                      id: attachment.id,
                      url: attachment.url,
                      fileName: attachment.file_name,
                      fileType: attachment.fileType,
                      fileSize: attachment.fileSize,
                    })),
                  }
                }
                return message
              } catch (err) {
                console.error("Error processing attachments for message:", err)
                return message
              }
            }),
          )

          setMessages(messagesWithAttachments)
        }
      } catch (attachmentError) {
        // Table doesn't exist or other error, just continue without attachments
        console.log("Skipping attachments: message_attachments table may not exist")
      }
    } catch (err) {
      console.error("Error fetching messages:", err)
      setError(`Gagal memuat pesan. Silakan coba lagi nanti.`)
    } finally {
      setLoading(false)
    }
  }, [userId, supabase])

  useEffect(() => {
    if (userId) {
      fetchMessages()
    }
  }, [userId, fetchMessages])

  async function togglePublicStatus(messageId: string, currentStatus: boolean) {
    try {
      setUpdatingMessage(messageId)

      const { error } = await supabase.from("messages").update({ is_public: !currentStatus }).eq("id", messageId)

      if (error) {
        throw error
      }

      // Update local state
      setMessages(
        messages.map((message) => (message.id === messageId ? { ...message, is_public: !currentStatus } : message)),
      )

      // Check if all messages are now public
      const updatedMessages = messages.map((message) =>
        message.id === messageId ? { ...message, is_public: !currentStatus } : message,
      )
      const allPublic = updatedMessages.every((msg) => msg.is_public)
      setAllMessagesPublic(allPublic)
    } catch (err) {
      console.error("Error updating message:", err)
      setError("Gagal mengubah status pesan. Silakan coba lagi nanti.")
    } finally {
      setUpdatingMessage(null)
    }
  }

  async function toggleAllMessagesPublic(makePublic: boolean) {
    try {
      setLoading(true)

      // Update all messages in the database
      const { error } = await supabase.from("messages").update({ is_public: makePublic }).eq("recipient_id", userId)

      if (error) {
        throw error
      }

      // Update local state
      setMessages(messages.map((message) => ({ ...message, is_public: makePublic })))
      setAllMessagesPublic(makePublic)
    } catch (err) {
      console.error("Error updating all messages:", err)
      setError("Gagal mengubah status semua pesan. Silakan coba lagi nanti.")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-main border-t-transparent"></div>
        <p className="mt-2">Memuat pesan...</p>
      </div>
    )
  }

  if (error) {
    return <div className="text-center py-8 text-red-500">{error}</div>
  }

  if (messages.length === 0) {
    return <div className="text-center py-8 text-mtext">Belum ada pesan.</div>
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4 p-4 rounded-base border-[3px] border-bw bg-blue-50 neo-brutalism">
        <div>
          <h3 className="text-sm font-heading">Tampilkan Semua Pesan di Profil Publik</h3>
          <p className="text-xs text-mtext">Mengatur visibilitas semua pesan sekaligus</p>
        </div>
        <div
          className={`flex items-center h-6 w-11 cursor-pointer rounded-full p-1 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${
            allMessagesPublic ? "bg-green-500" : "bg-gray-200"
          }`}
          onClick={() => toggleAllMessagesPublic(!allMessagesPublic)}
        >
          <div
            className={`h-4 w-4 rounded-full bg-white transition-transform duration-200 transform ${
              allMessagesPublic ? "translate-x-5" : "translate-x-0"
            }`}
          ></div>
        </div>
      </div>

      {messages.map((message) => (
        <Card key={message.id} color={message.is_public ? "bg-green-50" : "bg-blue-50"}>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div className="text-xs text-mtext">
                  Anonim • {formatDistanceToNow(new Date(message.created_at), { addSuffix: true, locale: id })}
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`px-2 py-1 rounded-full text-xs font-heading ${
                      message.is_public ? "bg-green-500 text-white" : "bg-gray-200 text-gray-700"
                    }`}
                  >
                    {message.is_public ? "Publik" : "Privat"}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 w-7 p-0"
                    onClick={() => togglePublicStatus(message.id, message.is_public)}
                    disabled={updatingMessage === message.id}
                  >
                    {updatingMessage === message.id ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-t-transparent border-current" />
                    ) : message.is_public ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                    <span className="sr-only">{message.is_public ? "Jadikan Privat" : "Jadikan Publik"}</span>
                  </Button>
                </div>
              </div>

              {message.content && <p className="font-base">{message.content}</p>}

              {/* Display attachments if any */}
              {message.attachments && message.attachments.length > 0 && (
                <MessageAttachmentViewer
                  attachments={message.attachments.map((att) => ({
                    url: att.url,
                    fileName: att.fileName,
                    fileType: att.fileType,
                    fileSize: att.fileSize,
                  }))}
                />
              )}

              <Button variant="outline" size="sm" className="text-xs h-8" onClick={() => setReplyingTo(message.id)}>
                Balas
              </Button>

              {replyingTo === message.id && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <ReplyForm
                    messageId={message.id}
                    recipientUsername={username}
                    onSuccess={() => {
                      setReplyingTo(null)
                      // Refresh messages
                      fetchMessages()
                    }}
                    onCancel={() => setReplyingTo(null)}
                  />
                </div>
              )}

              {/* Tampilkan balasan jika ada */}
              {message.replies && message.replies.length > 0 && (
                <div className="mt-4 pt-4 border-t-2 border-dashed border-bw">
                  {message.replies.map((reply) => (
                    <div key={reply.id} className="space-y-2 mb-4">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 rounded-full bg-main border-2 border-bw flex items-center justify-center text-xs font-heading">
                          {username.charAt(0).toUpperCase()}
                        </div>
                        <div className="text-xs text-mtext">
                          Balasan • {formatDistanceToNow(new Date(reply.created_at), { addSuffix: true, locale: id })}
                        </div>
                      </div>
                      <p className="text-sm font-base">{reply.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

