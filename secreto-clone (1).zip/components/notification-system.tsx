"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/neo-button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

type Notification = {
  id: string
  message: string
  timestamp: string
  read: boolean
}

export function NotificationSystem({ userId }: { userId: string }) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)

  // Fungsi untuk mengambil notifikasi (dummy untuk demo)
  useEffect(() => {
    // Simulasi notifikasi
    const dummyNotifications: Notification[] = [
      {
        id: "1",
        message: "Anda menerima pesan baru",
        timestamp: new Date().toISOString(),
        read: false,
      },
      {
        id: "2",
        message: "Seseorang melihat profil Anda",
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        read: false,
      },
      {
        id: "3",
        message: "Selamat datang di Secreto!",
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        read: true,
      },
    ]

    setNotifications(dummyNotifications)
    setUnreadCount(dummyNotifications.filter((n) => !n.read).length)

    // Dalam aplikasi sebenarnya, Anda akan menggunakan Supabase Realtime atau WebSockets
    // untuk menerima notifikasi secara real-time
  }, [userId])

  // Fungsi untuk menandai notifikasi sebagai telah dibaca
  const markAsRead = (notificationId: string) => {
    setNotifications(
      notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, read: true } : notification,
      ),
    )
    setUnreadCount((prev) => Math.max(0, prev - 1))
  }

  // Fungsi untuk menandai semua notifikasi sebagai telah dibaca
  const markAllAsRead = () => {
    setNotifications(notifications.map((notification) => ({ ...notification, read: true })))
    setUnreadCount(0)
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="h-10 w-10 rounded-full relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
              {unreadCount}
            </span>
          )}
          <span className="sr-only">Notifikasi</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 border-[3px] border-bw shadow-shadow" align="end">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="font-heading">Notifikasi</h3>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              Tandai semua dibaca
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-4 text-center text-mtext">Tidak ada notifikasi</div>
          ) : (
            notifications.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`p-4 border-b border-gray-100 cursor-pointer ${!notification.read ? "bg-blue-50" : ""}`}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="w-full">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-base">{notification.message}</p>
                    {!notification.read && <span className="h-2 w-2 rounded-full bg-blue-500"></span>}
                  </div>
                  <p className="text-xs text-mtext mt-1">
                    {new Date(notification.timestamp).toLocaleString("id-ID", {
                      hour: "2-digit",
                      minute: "2-digit",
                      day: "2-digit",
                      month: "2-digit",
                      year: "numeric",
                    })}
                  </p>
                </div>
              </DropdownMenuItem>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

