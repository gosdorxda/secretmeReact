"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"

interface PremiumFeaturesCardProps {
  isPremium: boolean
}

export function PremiumFeaturesCard({ isPremium }: PremiumFeaturesCardProps) {
  return (
    <Card color={isPremium ? "bg-gradient-to-r from-yellow-300 to-yellow-100" : "bg-gray-50"}>
      <CardHeader>
        <CardTitle>Fitur Premium</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          <li className="flex items-start">
            <div
              className={`mr-2 mt-0.5 h-5 w-5 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center text-white`}
            >
              {isPremium ? "✓" : ""}
            </div>
            <div>
              <p className="font-medium">Username Kustom</p>
              <p className="text-sm text-mtext">Ubah username Anda kapan saja</p>
            </div>
          </li>
          <li className="flex items-start">
            <div
              className={`mr-2 mt-0.5 h-5 w-5 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center text-white`}
            >
              {isPremium ? "✓" : ""}
            </div>
            <div>
              <p className="font-medium">Link Profil Kustom</p>
              <p className="text-sm text-mtext">Gunakan URL yang mudah diingat</p>
            </div>
          </li>
          <li className="flex items-start">
            <div
              className={`mr-2 mt-0.5 h-5 w-5 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center text-white`}
            >
              {isPremium ? "✓" : ""}
            </div>
            <div>
              <p className="font-medium">Link Sosial Media</p>
              <p className="text-sm text-mtext">Tampilkan link sosial media di profil Anda</p>
            </div>
          </li>
          <li className="flex items-start">
            <div
              className={`mr-2 mt-0.5 h-5 w-5 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center text-white`}
            >
              {isPremium ? "✓" : ""}
            </div>
            <div>
              <p className="font-medium">Tema Profil</p>
              <p className="text-sm text-mtext">Pilih dari berbagai tema eksklusif</p>
            </div>
          </li>
          <li className="flex items-start">
            <div
              className={`mr-2 mt-0.5 h-5 w-5 rounded-full ${isPremium ? "bg-green-500" : "bg-gray-300"} flex items-center justify-center text-white`}
            >
              {isPremium ? "✓" : ""}
            </div>
            <div>
              <p className="font-medium">Notifikasi Lanjutan</p>
              <p className="text-sm text-mtext">Dapatkan notifikasi WhatsApp dan Email</p>
            </div>
          </li>
        </ul>
      </CardContent>
    </Card>
  )
}

