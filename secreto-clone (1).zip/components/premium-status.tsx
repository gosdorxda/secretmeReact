"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/neo-button"
import { Card, CardContent } from "@/components/ui/neo-card"
import { getSupabaseClient } from "@/lib/supabase/client"

interface PremiumStatusProps {
  userId: string
}

export function PremiumStatus({ userId }: PremiumStatusProps) {
  const [loading, setLoading] = useState(true)
  const [isPremium, setIsPremium] = useState(false)

  useEffect(() => {
    async function checkPremiumStatus() {
      try {
        setLoading(true)

        // Untuk implementasi nyata, ambil langsung dari Supabase
        const supabase = getSupabaseClient()

        // Dapatkan data user terbaru
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("is_premium")
          .eq("id", userId)
          .single()

        if (userError) {
          console.error("Error fetching user premium status:", userError)
          // Fallback ke data demo
          const premiumUsers = ["2", "4"]
          const isUserPremium = premiumUsers.includes(userId)
          setIsPremium(isUserPremium)
        } else {
          // Gunakan data nyata dari database
          setIsPremium(userData.is_premium)
        }
      } catch (error) {
        console.error("Error checking premium status:", error)
      } finally {
        setLoading(false)
      }
    }

    checkPremiumStatus()

    // Set up interval refresh untuk memeriksa perubahan status premium
    const refreshInterval = setInterval(checkPremiumStatus, 30000) // Periksa setiap 30 detik

    return () => clearInterval(refreshInterval)
  }, [userId])

  if (loading) {
    return (
      <Card color="bg-gray-50">
        <CardContent className="p-4">
          <div className="animate-pulse flex space-x-4">
            <div className="flex-1 space-y-4 py-1">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (isPremium) {
    return (
      <Card color="bg-gradient-to-r from-yellow-300 to-yellow-100">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="inline-block rounded-full bg-main px-3 py-1 text-xs font-heading text-bw mb-2">
                PREMIUM
              </div>
              <div className="text-sm font-heading">Akun Premium Aktif</div>
              <div className="text-xs text-mtext mt-1">Status premium seumur hidup</div>
            </div>
            <Button asChild variant="outline" size="sm">
              <Link href="/settings/profile">Kelola</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card color="bg-gray-50">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-heading">Akun Free</div>
            <div className="text-xs text-mtext mt-1">Upgrade ke Premium untuk fitur eksklusif</div>
          </div>
          <Button asChild variant="blue" size="sm">
            <Link href="/premium">Upgrade</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

