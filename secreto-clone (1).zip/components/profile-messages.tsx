"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/neo-card"
import { formatDistanceToNow } from "date-fns"
import { id } from "date-fns/locale"
import { MessageAttachmentViewer } from "@/components/message-attachment-viewer"

type MessageAttachment = {
  id: string
  url: string
  fileName: string
  fileType: string
  fileSize: number
}

type Message = {
  id: string
  content: string
  created_at: string
  is_public: boolean
  has_attachments?: boolean // Make this optional
  replies: Reply[]
  attachments?: MessageAttachment[]
}

type Reply = {
  id: string
  content: string
  created_at: string
}

export function ProfileMessages({ username }: { username: string }) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = getSupabaseClient()

  async function fetchMessages() {
    try {
      setLoading(true)
      console.log("Fetching messages for username:", username)

      // First get the user ID from the username
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("username", username)
        .single()

      if (userError) {
        console.error("Error fetching user data:", userError)
        setError("Pengguna tidak ditemukan")
        setLoading(false)
        return
      }

      console.log("Found user ID:", userData.id)

      // Then fetch public messages for this user
      const { data, error } = await supabase
        .from("messages")
        .select(`
        id,
        content,
        created_at,
        is_public,
        replies (
          id,
          content,
          created_at
        )
      `)
        .eq("recipient_id", userData.id)
        .eq("is_public", true)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching messages:", error)
        setError("Gagal memuat pesan. Silakan coba lagi nanti.")
        setLoading(false)
        return
      }

      console.log("Fetched public messages:", data)

      // Jika tidak ada pesan, setel messages ke array kosong
      if (!data || data.length === 0) {
        console.log("No public messages found")
        setMessages([])
        setLoading(false)
        return
      }

      // Check for attachments for all messages
      const messagesWithAttachments = await Promise.all(
        data.map(async (message) => {
          try {
            // Always check for attachments for each message
            const { data: attachments, error: attachmentsError } = await supabase
              .from("message_attachments")
              .select("id, url, file_name, file_type, file_size")
              .eq("message_id", message.id)

            if (attachmentsError) {
              console.error("Error fetching attachments for message", message.id, ":", attachmentsError)
              return message
            }

            // Only add attachments property if there are any attachments
            if (attachments && attachments.length > 0) {
              return {
                ...message,
                attachments: attachments.map((attachment) => ({
                  id: attachment.id,
                  url: attachment.url,
                  fileName: attachment.file_name,
                  fileType: attachment.file_type,
                  fileSize: attachment.file_size,
                })),
              }
            }
            return message
          } catch (err) {
            console.error("Error processing attachments for message", message.id, ":", err)
            return message
          }
        }),
      )

      console.log("Messages with attachments:", messagesWithAttachments)
      setMessages(messagesWithAttachments)
    } catch (err) {
      console.error("Error in fetchMessages:", err)
      setError("Gagal memuat pesan. Silakan coba lagi nanti.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMessages()
  }, [username, supabase])

  if (loading) {
    return <div className="text-center py-8">Memuat pesan...</div>
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-500 mb-4">{error}</p>
        <button
          onClick={() => {
            setError(null)
            setLoading(true)
            fetchMessages()
          }}
          className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
        >
          Coba Lagi
        </button>
      </div>
    )
  }

  if (messages.length === 0) {
    return (
      <div className="text-center py-8 space-y-4">
        <p className="text-mtext">Belum ada pesan publik.</p>
        <p className="text-sm text-mtext mt-2">Pesan yang diatur sebagai publik akan muncul di sini.</p>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md text-left">
          <p className="text-sm font-medium text-yellow-800">Informasi Debug:</p>
          <p className="text-xs text-yellow-700 mt-1">Username: {username}</p>
          <p className="text-xs text-yellow-700">Status: Pesan berhasil disimpan tetapi tidak ditampilkan</p>
          <button
            onClick={fetchMessages}
            className="mt-2 px-3 py-1 bg-blue-500 text-white text-xs rounded-md hover:bg-blue-600"
          >
            Muat Ulang Pesan
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-heading mb-4">Pesan Publik</h3>
      {messages.map((message) => (
        <Card key={message.id} color="bg-green-50">
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div className="text-xs text-mtext">
                  Anonim • {formatDistanceToNow(new Date(message.created_at), { addSuffix: true, locale: id })}
                </div>
              </div>

              {message.content && <p className="font-base">{message.content}</p>}

              {/* Display attachments if any */}
              {message.attachments && message.attachments.length > 0 && (
                <MessageAttachmentViewer
                  attachments={message.attachments.map((att) => ({
                    url: att.url,
                    fileName: att.fileName,
                    fileType: att.fileType,
                    fileSize: att.fileSize,
                  }))}
                />
              )}

              {/* Tampilkan balasan jika ada */}
              {message.replies && message.replies.length > 0 && (
                <div className="mt-4 pt-4 border-t-2 border-dashed border-bw">
                  {message.replies.map((reply) => (
                    <div key={reply.id} className="space-y-2 mb-4">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 rounded-full bg-main border-2 border-bw flex items-center justify-center text-xs font-heading">
                          {username.charAt(0).toUpperCase()}
                        </div>
                        <div className="text-xs text-mtext">
                          Balasan • {formatDistanceToNow(new Date(reply.created_at), { addSuffix: true, locale: id })}
                        </div>
                      </div>
                      <p className="text-sm font-base">{reply.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

