"use client"

import { formatDistanceToNow } from "date-fns"
import { id } from "date-fns/locale"

type Reply = {
  id: string
  content: string
  created_at: string
  user_id?: string
}

type ProfileReplyViewProps = {
  replies: Reply[]
  username: string
}

export function ProfileReplyView({ replies, username }: ProfileReplyViewProps) {
  if (!replies || replies.length === 0) {
    return null
  }

  return (
    <div className="mt-4 pt-4 border-t-2 border-dashed border-bw">
      {replies.map((reply) => (
        <div key={reply.id} className="space-y-2 mb-4">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-full bg-main border-2 border-bw flex items-center justify-center text-xs font-heading text-white">
              {username.charAt(0).toUpperCase()}
            </div>
            <div className="text-xs text-mtext">
              Balasan • {formatDistanceToNow(new Date(reply.created_at), { addSuffix: true, locale: id })}
            </div>
          </div>
          <p className="text-sm font-base">{reply.content}</p>
        </div>
      ))}
    </div>
  )
}

