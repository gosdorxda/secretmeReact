"use client"

import { useEffect, useState } from "react"
import { getUserStats } from "@/lib/redis"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/neo-card"

interface ProfileStatsProps {
  userId: string
  databaseViews: number
  databaseMessageCount: number
}

export function ProfileStats({ userId, databaseViews, databaseMessageCount }: ProfileStatsProps) {
  const [stats, setStats] = useState({
    profileViews: databaseViews,
    messageCount: databaseMessageCount,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchStats() {
      try {
        const redisStats = await getUserStats(userId)

        // Gabungkan data dari database dan Redis
        // Redis mungkin memiliki data yang lebih baru (real-time)
        setStats({
          profileViews: Math.max(databaseViews || 0, redisStats.profileViews || 0),
          messageCount: Math.max(databaseMessageCount || 0, redisStats.messageCount || 0),
        })
      } catch (error) {
        console.error("Error fetching Redis stats:", error)
        // Fallback ke data database jika Redis gagal
        setStats({
          profileViews: databaseViews || 0,
          messageCount: databaseMessageCount || 0,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [userId, databaseViews, databaseMessageCount])

  return (
    <Card color="bg-purple-50">
      <CardHeader>
        <CardTitle>Statistik Profil</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-white rounded-base border-2 border-bw">
            <div className="text-3xl font-heading">{loading ? "..." : stats.profileViews}</div>
            <div className="text-sm text-mtext">Total Tayangan</div>
          </div>
          <div className="text-center p-4 bg-white rounded-base border-2 border-bw">
            <div className="text-3xl font-heading">{loading ? "..." : stats.messageCount}</div>
            <div className="text-sm text-mtext">Total Pesan</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

