"use client"

import { useState } from "react"
import { formatDistanceToNow } from "date-fns"
import { id } from "date-fns/locale"
import { Card, CardContent } from "@/components/ui/neo-card"
import { MessageAttachmentViewer } from "@/components/message-attachment-viewer"
import { ProfileReplyView } from "@/components/profile-reply-view"
import { Button } from "@/components/ui/neo-button"
import { ReplyForm } from "@/components/reply-form"

type MessageAttachment = {
  id: string
  url: string
  fileName: string
  fileType: string
  fileSize: number
}

type Message = {
  id: string
  content: string
  created_at: string
  replies: Reply[]
  attachments?: MessageAttachment[]
}

type Reply = {
  id: string
  content: string
  created_at: string
  user_id?: string
}

export function PublicMessages({ messages, username }: { messages: Message[]; username: string }) {
  const [replyingTo, setReplyingTo] = useState<string | null>(null)

  if (messages.length === 0) {
    return <div className="text-center py-8 text-mtext">Belum ada pesan publik.</div>
  }

  return (
    <div className="space-y-4">
      {messages.map((message) => (
        <Card key={message.id}>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="text-xs text-mtext">
                Anonim • {formatDistanceToNow(new Date(message.created_at), { addSuffix: true, locale: id })}
              </div>

              {message.content && <p className="font-base">{message.content}</p>}

              {/* Display attachments if any - with error handling */}
              {message.attachments && message.attachments.length > 0 && (
                <MessageAttachmentViewer
                  attachments={message.attachments.map((att) => ({
                    url: att.url,
                    fileName: att.fileName,
                    fileType: att.fileType,
                    fileSize: att.fileSize,
                  }))}
                />
              )}

              {/* Reply button */}
              {replyingTo !== message.id && (
                <Button variant="outline" size="sm" className="text-xs h-8" onClick={() => setReplyingTo(message.id)}>
                  Balas
                </Button>
              )}

              {/* Reply form */}
              {replyingTo === message.id && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <ReplyForm
                    messageId={message.id}
                    recipientUsername={username}
                    onSuccess={() => setReplyingTo(null)}
                    onCancel={() => setReplyingTo(null)}
                  />
                </div>
              )}

              {message.replies && message.replies.length > 0 && (
                <ProfileReplyView replies={message.replies} username={username} />
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

