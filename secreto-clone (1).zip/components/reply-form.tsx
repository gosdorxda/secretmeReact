"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/neo-button"
import { Textarea } from "@/components/ui/textarea"
import { replyToMessage } from "@/actions/reply-actions"
import { useRouter } from "next/navigation"

interface ReplyFormProps {
  messageId: string
  recipientUsername: string
  onSuccess?: () => void
  onCancel?: () => void
}

export function ReplyForm({ messageId, recipientUsername, onSuccess, onCancel }: ReplyFormProps) {
  const [content, setContent] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!content.trim()) {
      setError("Balasan tidak boleh kosong")
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      // First try the API route
      try {
        const response = await fetch("/api/replies", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            messageId,
            content: content.trim(),
            recipientUsername,
          }),
        })

        if (!response.ok) {
          const result = await response.json()
          throw new Error(result.error || "Failed to send reply")
        }

        const result = await response.json()

        if (result.success) {
          setContent("")
          setSuccess(true)

          // Reset success message after 3 seconds
          setTimeout(() => {
            setSuccess(false)
            if (onSuccess) {
              onSuccess()
            }
          }, 3000)

          router.refresh()
          return
        }
      } catch (apiError) {
        console.error("API route error, falling back to server action:", apiError)
      }

      // If API route fails, try the server action
      const formData = new FormData()
      formData.append("messageId", messageId)
      formData.append("content", content.trim())
      formData.append("recipientUsername", recipientUsername)

      const result = await replyToMessage(formData)

      if (result.error) {
        throw new Error(result.error)
      }

      setContent("")
      setSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false)
        if (onSuccess) {
          onSuccess()
        }
      }, 3000)

      // Refresh the page data
      router.refresh()
    } catch (err) {
      console.error("Error replying to message:", err)
      setError(err instanceof Error ? err.message : "Terjadi kesalahan saat membalas pesan")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Tulis balasan Anda di sini..."
          className="min-h-[100px] neo-input bg-blank"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={isLoading}
        />
      </div>

      {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{error}</div>}

      {success && <div className="rounded-md bg-green-50 p-3 text-sm text-green-500">Balasan berhasil dikirim!</div>}

      <div className="flex gap-2">
        <Button type="button" variant="outline" className="flex-1" onClick={onCancel} disabled={isLoading}>
          Batal
        </Button>
        <Button type="submit" variant="blue" className="flex-1" disabled={isLoading || content.trim().length === 0}>
          {isLoading ? "Mengirim..." : "Kirim Balasan"}
        </Button>
      </div>
    </form>
  )
}

