"use client"

import type React from "react"

import { useState } from "react"
import { getSupabaseClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/neo-button"
import { Textarea } from "@/components/ui/textarea"

export function SendMessageForm({ recipientUsername }: { recipientUsername: string }) {
  const [content, setContent] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const supabase = getSupabaseClient()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!content.trim()) {
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      // Cari user berdasarkan username
      const { data: user, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("username", recipientUsername)
        .single()

      if (userError) {
        throw new Error("User tidak ditemukan")
      }

      // Kirim pesan
      const { error: messageError } = await supabase.from("messages").insert({
        recipient_id: user.id,
        content: content.trim(),
      })

      if (messageError) {
        throw messageError
      }

      // Tambahkan notifikasi untuk penerima
      await supabase.from("notifications").insert({
        user_id: user.id,
        type: "new_message",
        content: "Anda menerima pesan baru",
      })

      setContent("")
      setSuccess(true)

      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false)
      }, 3000)
    } catch (err) {
      console.error("Error sending message:", err)
      setError(err instanceof Error ? err.message : "Gagal mengirim pesan. Silakan coba lagi nanti.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Tulis pesan anonim Anda di sini..."
          className="min-h-[150px] neo-input bg-blank"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={isLoading}
        />
      </div>

      {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-500">{error}</div>}
      {success && <div className="rounded-md bg-green-50 p-3 text-sm text-green-500">Pesan berhasil dikirim!</div>}

      <Button className="w-full" variant="blue" type="submit" disabled={isLoading || content.trim().length === 0}>
        {isLoading ? "Mengirim..." : "Kirim Pesan"}
      </Button>
    </form>
  )
}

