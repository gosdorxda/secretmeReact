import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-base text-sm font-heading ring-offset-ringOffset transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 neo-button",
  {
    variants: {
      variant: {
        default: "bg-main text-bw hover:bg-yellow-300",
        blue: "bg-blue-500 text-blank hover:bg-blue-400",
        green: "bg-green-500 text-blank hover:bg-green-400",
        red: "bg-red-500 text-blank hover:bg-red-400",
        pink: "bg-pink-500 text-blank hover:bg-pink-400",
        purple: "bg-purple-500 text-blank hover:bg-purple-400",
        outline: "bg-blank text-bw hover:bg-gray-100",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-base px-3",
        lg: "h-11 rounded-base px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        type={props.type || "button"} // Pastikan type default adalah "button"
        {...props}
      />
    )
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }

