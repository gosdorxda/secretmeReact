"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

// Tambahkan import untuk ikon sosial media dari lucide-react
import { Instagram, Twitter, Facebook, Linkedin } from "lucide-react"

const Card = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    color?: string
    isProfileLink?: boolean
    profileUrl?: string
    isPremium?: boolean
    socialLinks?: {
      instagram?: string
      twitter?: string
      tiktok?: string
      facebook?: string
      linkedin?: string
    }
  }
>(({ className, color = "bg-blank", isProfileLink, profileUrl, isPremium = false, ...props }, ref) => (
  <div ref={ref} className={cn("rounded-base neo-card overflow-hidden", color, className)} {...props}>
    {isProfileLink && (
      <>
        <div className="p-4 flex flex-col space-y-2">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-heading">Link Profil Anda</h3>
            <div className="flex gap-2">
              <button
                className="h-8 w-8 flex items-center justify-center rounded-md bg-blank border-2 border-bw"
                onClick={() => {
                  if (profileUrl) {
                    navigator.clipboard.writeText(profileUrl)
                    alert("Link profil berhasil disalin!")
                  }
                }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
              <button
                className="h-8 w-8 flex items-center justify-center rounded-md bg-blank border-2 border-bw"
                onClick={() => {
                  if (profileUrl) {
                    window.open(profileUrl, "_blank")
                  }
                }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                  <polyline points="15 3 21 3 21 9"></polyline>
                  <line x1="10" y1="14" x2="21" y2="3"></line>
                </svg>
              </button>
            </div>
          </div>
          <a href={profileUrl} className="text-blue-500 font-base">
            {profileUrl || "https://secreto.site/u/username"}
          </a>
          <div className="mt-2">
            <button
              className="inline-flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-base border-2 border-bw neo-button"
              onClick={() => {
                if (profileUrl) {
                  // Share API if available, otherwise fallback to clipboard
                  if (navigator.share) {
                    navigator.share({
                      title: "Kirim pesan anonim ke saya",
                      text: "Kirim pesan anonim ke saya melalui Secreto",
                      url: profileUrl,
                    })
                  } else {
                    navigator.clipboard.writeText(profileUrl)
                    alert("Link profil berhasil disalin!")
                  }
                }
              }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-2"
              >
                <circle cx="18" cy="5" r="3"></circle>
                <circle cx="6" cy="12" r="3"></circle>
                <circle cx="18" cy="19" r="3"></circle>
                <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
              </svg>
              Bagikan
            </button>
          </div>

          {/* Social Media Links Section */}
          {isProfileLink && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h4 className="text-sm font-medium mb-3">Sosial Media</h4>

              {/* Jika premium tapi belum ada link sosmed */}
              {isPremium && props.socialLinks && !Object.values(props.socialLinks).some((link) => link) && (
                <div className="bg-yellow-50 p-3 rounded-base border border-yellow-200 mb-3">
                  <p className="text-sm text-yellow-700">
                    Anda memiliki akun premium! Tambahkan link sosial media Anda di pengaturan profil untuk meningkatkan
                    tampilan profil Anda.
                  </p>
                </div>
              )}

              {/* Jika bukan premium dan belum ada link sosmed */}
              {!isPremium && (!props.socialLinks || !Object.values(props.socialLinks).some((link) => link)) && (
                <div className="bg-gray-50 p-3 rounded-base border border-gray-200 mb-3">
                  <p className="text-sm text-gray-700 mb-2">
                    Upgrade ke premium untuk menambahkan link sosial media Anda!
                  </p>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 opacity-60">
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-base border-2 border-bw neo-button text-sm relative">
                      <Instagram size={16} />
                      <span>Instagram</span>
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center rounded-base">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-white"
                        >
                          <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 bg-blue-400 text-white rounded-base border-2 border-bw neo-button text-sm relative">
                      <Twitter size={16} />
                      <span>Twitter</span>
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center rounded-base">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-white"
                        >
                          <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-base border-2 border-bw neo-button text-sm relative">
                      <Facebook size={16} />
                      <span>Facebook</span>
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center rounded-base">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-white"
                        >
                          <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tampilkan link sosial media jika ada */}
              {props.socialLinks && Object.values(props.socialLinks).some((link) => link) && (
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {props.socialLinks.instagram && (
                    <a
                      href={props.socialLinks.instagram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-base border-2 border-bw neo-button text-sm hover:opacity-90 transition-opacity"
                    >
                      <Instagram size={16} />
                      <span>Instagram</span>
                    </a>
                  )}
                  {props.socialLinks.twitter && (
                    <a
                      href={props.socialLinks.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-blue-400 text-white rounded-base border-2 border-bw neo-button text-sm hover:opacity-90 transition-opacity"
                    >
                      <Twitter size={16} />
                      <span>Twitter</span>
                    </a>
                  )}
                  {props.socialLinks.tiktok && (
                    <a
                      href={props.socialLinks.tiktok}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-black text-white rounded-base border-2 border-bw neo-button text-sm hover:opacity-90 transition-opacity"
                    >
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        className="shrink-0"
                      >
                        <path d="M19.321 5.562a5.124 5.124 0 0 1-3.414-1.267 5.124 5.124 0 0 1-1.53-3.25h-3.577v13.068c0 1.154-.933 2.088-2.087 2.088a2.088 2.088 0 0 1-2.088-2.088 2.088 2.088 0 0 1 2.088-2.088c.286 0 .559.057.809.16V8.131A6.125 6.125 0 0 0 3.437 19.28a6.125 6.125 0 0 0 8.476-2.042 6.125 6.125 0 0 0 .775-2.979V9.768a8.59 8.59 0 0 0 3.524.764h.02V7.075c-.238 0-.475-.019-.71-.057-.2-.033-.401-.074-.602-.123v3.254a8.59 8.59 0 0 1-3.524-.764v4.49c0 1.068-.264 2.112-.775 2.98a6.125 6.125 0 0 1-3.644 2.847 6.126 6.126 0 0 1-4.832-.805 6.125 6.125 0 0 1-2.847-3.644 6.125 6.125 0 0 1 .805-4.833 6.125 6.125 0 0 1 3.644-2.846 6.125 6.125 0 0 1 2.09-.362c.238 0 .476.014.71.043v3.67a2.088 2.088 0 0 0-.71-.124 2.088 2.088 0 0 0-2.087 2.088 2.088 2.088 0 0 0 2.088 2.088 2.088 2.088 0 0 0 2.087-2.088V1.045h3.577a5.124 5.124 0 0 0 1.53 3.25 5.124 5.124 0 0 0 3.414 1.267v3.254a8.665 8.665 0 0 1-3.544-.764v4.49c0 3.382-2.743 6.125-6.125 6.125a6.125 6.125 0 0 1-6.125-6.125 6.125 6.125 0 0 1 10.957-3.849V6.326a8.59 8.59 0 0 0 3.524.764V3.836c.2.05.401.09.602.123.235.038.472.057.71.057v4.457h-.02a8.665 8.665 0 0 1-3.524-.764" />
                      </svg>
                      <span>TikTok</span>
                    </a>
                  )}
                  {props.socialLinks.facebook && (
                    <a
                      href={props.socialLinks.facebook}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-base border-2 border-bw neo-button text-sm hover:opacity-90 transition-opacity"
                    >
                      <Facebook size={16} />
                      <span>Facebook</span>
                    </a>
                  )}
                  {props.socialLinks.linkedin && (
                    <a
                      href={props.socialLinks.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-3 py-2 bg-blue-700 text-white rounded-base border-2 border-bw neo-button text-sm hover:opacity-90 transition-opacity"
                    >
                      <Linkedin size={16} />
                      <span>LinkedIn</span>
                    </a>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </>
    )}
    {!isProfileLink && props.children}
  </div>
))
Card.displayName = "Card"

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  ),
)
CardHeader.displayName = "CardHeader"

const CardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3 ref={ref} className={cn("text-2xl font-heading leading-none tracking-tight", className)} {...props} />
  ),
)
CardTitle.displayName = "CardTitle"

const CardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => <p ref={ref} className={cn("text-sm text-mtext", className)} {...props} />,
)
CardDescription.displayName = "CardDescription"

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />,
)
CardContent.displayName = "CardContent"

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex items-center p-6 pt-0", className)} {...props} />
  ),
)
CardFooter.displayName = "CardFooter"

export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter }

