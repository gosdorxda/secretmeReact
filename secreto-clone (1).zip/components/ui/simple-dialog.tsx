"use client"

import type * as React from "react"
import { X } from "lucide-react"
import { Button } from "@/components/ui/neo-button"

interface SimpleDialogProps {
  isOpen: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
}

export function SimpleDialog({ isOpen, onClose, title, children }: SimpleDialogProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Dialog content */}
      <div className="relative z-50 w-full max-w-md rounded-lg border-[3px] border-bw bg-blank p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-heading">{title}</h2>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={onClose}>
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </div>

        <div className="mt-4">{children}</div>
      </div>
    </div>
  )
}

