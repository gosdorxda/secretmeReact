import { redis } from "@/lib/redis"

// Fungsi untuk menyimpan data di cache
export async function setCache<T>(key: string, data: T, expirationInSeconds = 3600): Promise<void> {
  await redis.set(key, JSON.stringify(data), { ex: expirationInSeconds })
}

// Fungsi untuk mengambil data dari cache
export async function getCache<T>(key: string): Promise<T | null> {
  const data = await redis.get<string>(key)
  if (!data) return null
  return JSON.parse(data) as T
}

// Fungsi untuk menghapus data dari cache
export async function deleteCache(key: string): Promise<void> {
  await redis.del(key)
}

// Fungsi untuk mengambil data dengan cache
export async function withCache<T>(key: string, fetchFn: () => Promise<T>, expirationInSeconds = 3600): Promise<T> {
  // Coba ambil dari cache dulu
  const cachedData = await getCache<T>(key)

  if (cachedData) {
    return cachedData
  }

  // Jika tidak ada di cache, ambil data baru
  const freshData = await fetchFn()

  // Simpan ke cache
  await setCache(key, freshData, expirationInSeconds)

  return freshData
}

