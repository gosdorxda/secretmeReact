// Konfigurasi i18n
export const locales = ["id", "en"] as const
export type Locale = (typeof locales)[number]

export const defaultLocale: Locale = "id"

// Nama bahasa untuk ditampilkan di UI
export const localeNames: Record<Locale, string> = {
  id: "Bahasa Indonesia",
  en: "English",
}

