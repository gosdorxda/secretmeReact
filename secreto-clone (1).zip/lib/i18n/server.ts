import { cookies, headers } from "next/headers"
import { defaultLocale, locales, type Locale } from "./config"

// Fungsi untuk mendapatkan locale dari cookies atau headers
export async function getLocale(): Promise<Locale> {
  // Cek cookies terlebih dahulu
  const cookieStore = cookies()
  const localeCookie = cookieStore.get("locale")

  if (localeCookie && locales.includes(localeCookie.value as Locale)) {
    return localeCookie.value as Locale
  }

  // Jika tidak ada di cookies, cek Accept-Language header
  const headersList = headers()
  const acceptLanguage = headersList.get("Accept-Language")

  if (acceptLanguage) {
    // Parse Accept-Language header
    const preferredLocale = acceptLanguage
      .split(",")
      .map((lang) => lang.split(";")[0].trim().substring(0, 2))
      .find((lang) => locales.includes(lang as Locale))

    if (preferredLocale) {
      return preferredLocale as Locale
    }
  }

  // Default ke bahasa default
  return defaultLocale
}

// Fungsi untuk mendapatkan terjemahan berdasarkan locale
export async function getTranslations(locale?: Locale) {
  const currentLocale = locale || (await getLocale())

  // Import file terjemahan secara dinamis
  const messages = {
    id: (await import("../../messages/id.json")).default,
    en: (await import("../../messages/en.json")).default,
  }

  // Fungsi untuk mengambil terjemahan berdasarkan key
  return function t(key: string): string {
    const keys = key.split(".")
    let value = messages[currentLocale]

    for (const k of keys) {
      if (value && typeof value === "object" && k in value) {
        value = value[k]
      } else {
        console.warn(`Translation key not found: ${key}`)
        return key
      }
    }

    return typeof value === "string" ? value : key
  }
}

