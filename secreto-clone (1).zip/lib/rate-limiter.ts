import { Redis } from "@upstash/redis"

// Initialize Redis client
const redis = Redis.fromEnv()

// Rate Limiter Function that doesn't depend on next/headers
export async function rateLimit(
  key: string,
  limit: number,
  timeFrame: number,
): Promise<{
  success: boolean
  resetTime: Date
}> {
  const now = Date.now()
  const windowStart = now - timeFrame
  const multi = redis.multi()

  multi.zremrangebyscore(key, "-inf", String(windowStart))
  multi.zadd(key, { score: String(now), member: String(now) })
  multi.zcard(key)
  multi.expire(key, timeFrame / 1000) // Convert milliseconds to seconds

  const results = await multi.exec()
  const remaining = limit - Number(results?.[2])
  const success = remaining >= 0

  const resetTime = new Date(now + timeFrame)

  return {
    success,
    resetTime,
  }
}

