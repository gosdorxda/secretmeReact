import { Redis } from "@upstash/redis"

// Inisialisasi Redis client
export const redis = Redis.fromEnv()

// Fungsi untuk menambah jumlah tampilan profil
export async function incrementProfileViews(userId: string): Promise<number> {
  const key = `user:${userId}:profile_views`
  return await redis.incr(key)
}

// Fungsi untuk menambah jumlah pesan
export async function incrementMessageCount(userId: string): Promise<number> {
  const key = `user:${userId}:message_count`
  return await redis.incr(key)
}

// Fungsi untuk mendapatkan statistik
export async function getUserStats(userId: string): Promise<{
  profileViews: number
  messageCount: number
}> {
  const [profileViews, messageCount] = await Promise.all([
    redis.get<number>(`user:${userId}:profile_views`) || 0,
    redis.get<number>(`user:${userId}:message_count`) || 0,
  ])

  return {
    profileViews,
    messageCount,
  }
}

// Fungsi untuk menyimpan data sementara (misalnya untuk rate limiting)
export async function setTemporaryData(key: string, value: any, expirationInSeconds: number): Promise<void> {
  await redis.set(key, value, { ex: expirationInSeconds })
}

// Fungsi untuk mendapatkan data sementara
export async function getTemporaryData<T>(key: string): Promise<T | null> {
  return await redis.get<T>(key)
}

