import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

// Versi alternatif dari getSupabaseServer untuk digunakan di Pages Router
export function getSupabaseClientPages() {
  return createClientComponentClient()
}

