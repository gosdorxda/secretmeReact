import { getSupabaseClient } from "./client"
import {
  uploadAvatar as serverUploadAvatar,
  deleteAvatar as serverDeleteAvatar,
  initializeStorageBuckets,
} from "@/actions/storage-actions"

// Nama bucket untuk penyimpanan file
export const AVATAR_BUCKET = "avatars"
export const MESSAGE_ATTACHMENTS_BUCKET = "message-attachments"

// Fungsi untuk mengunggah avatar (client-side)
export async function uploadAvatar(file: File, userId: string) {
  console.log("[Storage] Starting avatar upload for user:", userId)

  try {
    // Panggil server action untuk upload
    return await serverUploadAvatar(file, userId)
  } catch (error) {
    console.error("[Storage] Error in uploadAvatar:", error)
    throw error
  }
}

// Fungsi untuk menghapus avatar
export async function deleteAvatar(filePath: string) {
  console.log("[Storage] Deleting avatar:", filePath)

  try {
    // Ekstrak nama file dari URL
    const fileName = filePath.split("/").pop()

    if (!fileName) {
      console.error("[Storage] Invalid file path:", filePath)
      throw new Error("Invalid file path")
    }

    console.log("[Storage] Extracted filename:", fileName)

    // Panggil server action untuk delete
    return await serverDeleteAvatar(fileName)
  } catch (error) {
    console.error("[Storage] Error in deleteAvatar:", error)
    throw error
  }
}

// Fungsi untuk mengunggah gambar latar belakang
export async function uploadBackground(file: File, userId: string) {
  console.log("[Storage] Starting background upload for user:", userId)
  const supabase = getSupabaseClient()

  // Buat nama file unik berdasarkan userId
  const fileExt = file.name.split(".").pop()
  const fileName = `background-${userId}-${Date.now()}.${fileExt}`
  console.log("[Storage] Generated filename:", fileName)

  const { data, error } = await supabase.storage.from(AVATAR_BUCKET).upload(fileName, file, {
    cacheControl: "3600",
    upsert: true,
  })

  console.log("[Storage] Upload result:", { data, error })

  if (error) {
    console.error("[Storage] Error uploading background:", error)
    throw error
  }

  // Dapatkan URL publik dari file yang diunggah
  const {
    data: { publicUrl },
  } = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(fileName)

  console.log("[Storage] Public URL:", publicUrl)
  return publicUrl
}

// Fungsi-fungsi berikut hanya akan digunakan jika tabel message_attachments sudah ada
// Fungsi untuk mengunggah lampiran pesan
export async function uploadMessageAttachment(file: File, messageId: string) {
  try {
    const supabase = getSupabaseClient()

    // Periksa apakah tabel message_attachments ada dengan cara yang lebih aman
    try {
      const { count, error } = await supabase.from("message_attachments").select("*", { count: "exact", head: true })

      if (error) {
        console.error("Skipping attachments: message_attachments table may not exist", error)
        throw new Error("message_attachments table does not exist")
      }
    } catch (e) {
      console.error("Skipping attachments: message_attachments table may not exist", e)
      throw new Error("message_attachments table does not exist")
    }

    // Buat nama file unik berdasarkan messageId
    const fileExt = file.name.split(".").pop()
    const fileName = `${messageId}-${Date.now()}.${fileExt}`

    const { data, error } = await supabase.storage.from(MESSAGE_ATTACHMENTS_BUCKET).upload(fileName, file, {
      cacheControl: "3600",
      upsert: true,
    })

    if (error) {
      console.error("Error uploading message attachment:", error)
      throw error
    }

    // Dapatkan URL publik dari file yang diunggah
    const {
      data: { publicUrl },
    } = supabase.storage.from(MESSAGE_ATTACHMENTS_BUCKET).getPublicUrl(fileName)

    return {
      url: publicUrl,
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size,
    }
  } catch (error) {
    console.error("Error in uploadMessageAttachment:", error)
    // Return a default object if the table doesn't exist
    return {
      url: "",
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size,
    }
  }
}

// Fungsi untuk menghapus lampiran pesan
export async function deleteMessageAttachment(filePath: string) {
  try {
    const supabase = getSupabaseClient()

    // Periksa apakah tabel message_attachments ada dengan cara yang lebih aman
    try {
      const { count, error } = await supabase.from("message_attachments").select("*", { count: "exact", head: true })

      if (error) {
        console.error("Skipping attachments: message_attachments table may not exist", error)
        return true
      }
    } catch (e) {
      console.error("Skipping attachments: message_attachments table may not exist", e)
      return true
    }

    // Ekstrak nama file dari URL
    const fileName = filePath.split("/").pop()

    if (!fileName) {
      throw new Error("Invalid file path")
    }

    const { error } = await supabase.storage.from(MESSAGE_ATTACHMENTS_BUCKET).remove([fileName])

    if (error) {
      console.error("Error deleting message attachment:", error)
      throw error
    }

    return true
  } catch (error) {
    console.error("Error in deleteMessageAttachment:", error)
    return true
  }
}

// Fungsi untuk mendapatkan semua lampiran pesan
export async function getMessageAttachments(messageId: string) {
  try {
    const supabase = getSupabaseClient()

    // Periksa apakah tabel message_attachments ada dengan cara yang lebih aman
    try {
      const { count, error } = await supabase.from("message_attachments").select("*", { count: "exact", head: true })

      if (error) {
        console.error("Skipping attachments: message_attachments table may not exist", error)
        return []
      }
    } catch (e) {
      console.error("Skipping attachments: message_attachments table may not exist", e)
      return []
    }

    const { data, error } = await supabase.storage.from(MESSAGE_ATTACHMENTS_BUCKET).list(undefined, {
      limit: 100,
      search: messageId,
    })

    if (error) {
      console.error("Error getting message attachments:", error)
      throw error
    }

    return data.map((file) => {
      const {
        data: { publicUrl },
      } = supabase.storage.from(MESSAGE_ATTACHMENTS_BUCKET).getPublicUrl(file.name)

      return {
        name: file.name,
        url: publicUrl,
        size: file.metadata.size,
        created: file.created_at,
      }
    })
  } catch (error) {
    console.error("Error in getMessageAttachments:", error)
    return []
  }
}

export async function initializeStorage() {
  try {
    // Panggil server action untuk inisialisasi bucket dan buat kebijakan publik
    const result = await initializeStorageBuckets()

    if (result.error) {
      console.error("[Storage] Error initializing storage:", result.error)
      return false
    }

    return true
  } catch (error) {
    console.error("[Storage] Error in initializeStorage:", error)
    return false
  }
}

