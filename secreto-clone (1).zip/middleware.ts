import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const pathname = req.nextUrl.pathname

  // Create a Supabase client configured to use cookies
  const supabase = createMiddlewareClient({ req, res })

  // Refresh session if expired - required for Server Components
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Protected routes that require authentication
  const protectedRoutes = ["/dashboard"]

  // Admin routes that require admin authentication
  const adminRoutes = ["/admin-panel"]

  // Auth routes that should redirect to dashboard if already logged in
  const authRoutes = ["/login", "/register"]

  // If accessing a protected route without being logged in, redirect to login
  if (protectedRoutes.some((route) => pathname.startsWith(route)) && !session) {
    const redirectUrl = new URL("/login", req.url)
    redirectUrl.searchParams.set("redirectedFrom", pathname)
    return NextResponse.redirect(redirectUrl)
  }

  // If accessing admin routes, check if user is admin
  if (adminRoutes.some((route) => pathname.startsWith(route))) {
    if (!session) {
      const redirectUrl = new URL("/admin-login", req.url)
      redirectUrl.searchParams.set("redirectedFrom", pathname)
      return NextResponse.redirect(redirectUrl)
    }

    // Check if user is admin
    const { data: adminData } = await supabase.from("admins").select("id").eq("id", session.user.id).single()

    if (!adminData) {
      // User is not an admin, redirect to unauthorized page
      return NextResponse.redirect(new URL("/unauthorized", req.url))
    }
  }

  // If accessing auth routes while logged in, redirect to dashboard
  if (authRoutes.some((route) => pathname.startsWith(route)) && session) {
    return NextResponse.redirect(new URL("/dashboard", req.url))
  }

  return res
}

// Specify which routes this middleware should run on
export const config = {
  matcher: ["/dashboard/:path*", "/login", "/register", "/admin-panel/:path*", "/admin-login"],
}

