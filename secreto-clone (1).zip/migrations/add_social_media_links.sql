-- Add social media link columns to the profiles table
ALTER TABLE profiles 
ADD COLUMN instagram TEXT,
ADD COLUMN twitter TEXT,
ADD COLUMN tiktok TEXT,
ADD COLUMN facebook TEXT,
ADD COLUMN linkedin TEXT;

-- Comment on columns for documentation
COMMENT ON COLUMN profiles.instagram IS 'Instagram profile URL';
COMMENT ON COLUMN profiles.twitter IS 'Twitter profile URL';
COMMENT ON COLUMN profiles.tiktok IS 'TikTok profile URL';
COMMENT ON COLUMN profiles.facebook IS 'Facebook profile URL';
COMMENT ON COLUMN profiles.linkedin IS 'LinkedIn profile URL';

