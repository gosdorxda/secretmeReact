-- Menambahkan kolom statistik ke tabel profiles jika belum ada
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_views INTEGER DEFAULT 0;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_messages INTEGER DEFAULT 0;

-- Memastikan kolom memiliki nilai default 0 dan bukan NULL
UPDATE profiles SET total_views = 0 WHERE total_views IS NULL;
UPDATE profiles SET total_messages = 0 WHERE total_messages IS NULL;

