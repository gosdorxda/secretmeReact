-- Menambahkan kolom total_messages ke tabel profiles jika belum ada
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS total_messages INTEGER DEFAULT 0;

-- Memastikan kolom total_views ada dan memiliki nilai default 0
ALTER TABLE profiles ALTER COLUMN total_views SET DEFAULT 0;

