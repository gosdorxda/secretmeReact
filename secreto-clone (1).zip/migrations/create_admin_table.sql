-- Create admin table
CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Create policy for admins table
CREATE POLICY "Admins can view all admins" ON admins
  FOR SELECT USING (auth.uid() IN (SELECT id FROM admins));

CREATE POLICY "Admins can insert admins" ON admins
  FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM admins));

CREATE POLICY "Admins can update their own data" ON admins
  FOR UPDATE USING (auth.uid() = id);

-- Create policy for users table to allow admins to view and update
CREATE POLICY "Admins can view all users" ON users
  FOR SELECT USING (auth.uid() IN (SELECT id FROM admins));

CREATE POLICY "Admins can update users" ON users
  FOR UPDATE USING (auth.uid() IN (SELECT id FROM admins));

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admins WHERE id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

