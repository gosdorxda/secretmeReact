-- Fungsi untuk mengeksekusi SQL mentah (hanya untuk admin)
CREATE OR REPLACE FUNCTION execute_sql(sql_query text)
RETURNS json AS $$
DECLARE
  result json;
BEGIN
  EXECUTE sql_query INTO result;
  RETURN result;
EXCEPTION WHEN OTHERS THEN
  RETURN json_build_object('error', SQLERRM);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Berikan izin hanya ke role yang diperlukan
REVOKE ALL ON FUNCTION execute_sql(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION execute_sql(text) TO service_role;

