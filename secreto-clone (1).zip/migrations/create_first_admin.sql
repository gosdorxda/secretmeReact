-- Pastikan user sudah terdaftar di auth.users
-- Ganti YOUR_USER_ID dengan ID user yang ingin dijadikan admin
-- Ganti YOUR_EMAIL dengan email admin

INSERT INTO admins (id, email, role, created_at, updated_at)
VALUES ('8004a92b-80ed-4f52-ba23-8d095489e9cf', 'asu@gmail.com', 'super_admin', NOW(), NOW());

