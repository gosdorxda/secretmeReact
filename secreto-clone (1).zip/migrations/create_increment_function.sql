-- Membuat fungsi increment untuk menambah nilai kolom
CREATE OR REPLACE FUNCTION increment_counter(
  table_name text,
  column_name text,
  user_id_value uuid
)
RETURNS void AS $$
BEGIN
  EXECUTE format('UPDATE %I SET %I = COALESCE(%I, 0) + 1 WHERE user_id = %L', 
                 table_name, column_name, column_name, user_id_value);
END;
$$ LANGUAGE plpgsql;

