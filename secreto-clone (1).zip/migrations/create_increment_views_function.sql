-- Fungsi untuk menambah jumlah views pada profil
CREATE OR REPLACE FUNCTION increment_views(row_id INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE profiles
  SET total_views = total_views + 1
  WHERE id = row_id;
END;
$$ LANGUAGE plpgsql;

