-- Function to create message_attachments table
CREATE OR REPLACE FUNCTION create_message_attachments_table()
RETURNS void AS $$
BEGIN
  -- Create message_attachments table if it doesn't exist
  CREATE TABLE IF NOT EXISTS message_attachments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  );

  -- Add has_attachments column to messages table if it doesn't exist
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'has_attachments'
  ) THEN
    ALTER TABLE messages ADD COLUMN has_attachments BOOLEAN DEFAULT FALSE;
  END IF;

  -- Create index on message_id for faster lookups
  CREATE INDEX IF NOT EXISTS idx_message_attachments_message_id ON message_attachments(message_id);
END;
$$ LANGUAGE plpgsql;

