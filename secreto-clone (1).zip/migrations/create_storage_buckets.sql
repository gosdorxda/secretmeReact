-- Insert buckets
INSERT INTO storage.buckets (id, name, public, avif_autodetection, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', true, false, 2097152, '{image/png,image/jpeg,image/jpg,image/webp}')
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, avif_autodetection, file_size_limit, allowed_mime_types)
VALUES ('message-attachments', 'message-attachments', true, false, 5242880, '{image/png,image/jpeg,image/jpg,image/webp,application/pdf}')
ON CONFLICT (id) DO NOTHING;

-- Set up storage policies for avatars bucket
INSERT INTO storage.policies (name, bucket_id, definition, owner)
VALUES ('Avatar Policy', 'avatars', '(bucket_id = ''avatars''::text)', 'authenticated')
ON CONFLICT (name, bucket_id) DO NOTHING;

-- Set up storage policies for message-attachments bucket
INSERT INTO storage.policies (name, bucket_id, definition, owner)
VALUES ('Message Attachments Policy', 'message-attachments', '(bucket_id = ''message-attachments''::text)', 'authenticated')
ON CONFLICT (name, bucket_id) DO NOTHING;

