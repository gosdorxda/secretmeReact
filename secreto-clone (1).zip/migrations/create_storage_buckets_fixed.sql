-- Insert buckets only
INSERT INTO storage.buckets (id, name, public, avif_autodetection, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', true, false, 2097152, '{image/png,image/jpeg,image/jpg,image/webp}')
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public, avif_autodetection, file_size_limit, allowed_mime_types)
VALUES ('message-attachments', 'message-attachments', true, false, 5242880, '{image/png,image/jpeg,image/jpg,image/webp,application/pdf}')
ON CONFLICT (id) DO NOTHING;

