-- Pastikan kolom total_messages ada di tabel profiles
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'profiles' AND column_name = 'total_messages'
    ) THEN
        ALTER TABLE profiles ADD COLUMN total_messages INTEGER DEFAULT 0;
    END IF;
END $$;

-- Update semua nilai NULL menjadi 0
UPDATE profiles SET total_messages = 0 WHERE total_messages IS NULL;

-- Buat fungsi khusus untuk increment pesan
CREATE OR REPLACE FUNCTION increment_message_count(user_id_param UUID)
RETURNS INTEGER AS $$
DECLARE
    new_count INTEGER;
BEGIN
    -- Update counter dan return nilai baru
    UPDATE profiles 
    SET total_messages = COALESCE(total_messages, 0) + 1 
    WHERE user_id = user_id_param
    RETURNING total_messages INTO new_count;
    
    RETURN new_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Berikan izin ke semua role yang diperlukan
GRANT EXECUTE ON FUNCTION increment_message_count(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION increment_message_count(UUID) TO service_role;
GRANT EXECUTE ON FUNCTION increment_message_count(UUID) TO anon;

-- Buat trigger untuk otomatis increment counter saat pesan baru dibuat
CREATE OR REPLACE FUNCTION auto_increment_message_count()
RETURNS TRIGGER AS $$
BEGIN
    -- Panggil fungsi increment untuk recipient_id
    PERFORM increment_message_count(NEW.recipient_id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Hapus trigger jika sudah ada
DROP TRIGGER IF EXISTS message_counter_trigger ON messages;

-- Buat trigger baru
CREATE TRIGGER message_counter_trigger
AFTER INSERT ON messages
FOR EACH ROW
EXECUTE FUNCTION auto_increment_message_count();

