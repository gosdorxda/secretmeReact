export type User = {
  id: string
  username: string
  email: string
  display_name?: string
  avatar_url?: string
  created_at: string
  updated_at: string
  is_premium: boolean
  premium_expires_at?: string
}

export type Profile = {
  id: string
  user_id: string
  bio?: string
  custom_url?: string
  theme: string
  total_views: number
  created_at: string
  updated_at: string
  // Add social media links
  instagram?: string
  twitter?: string
  tiktok?: string
  facebook?: string
  linkedin?: string
}

export type Message = {
  id: string
  recipient_id: string
  content: string
  is_public: boolean
  is_read: boolean
  has_attachments: boolean
  created_at: string
  attachments?: MessageAttachment[]
}

export type MessageAttachment = {
  id: string
  message_id: string
  url: string
  file_name: string
  file_type: string
  file_size: number
  created_at: string
}

export type Reply = {
  id: string
  message_id: string
  user_id: string
  content: string
  created_at: string
}

export type Subscription = {
  id: string
  user_id: string
  plan_type: string
  status: string
  starts_at: string
  expires_at: string
  created_at: string
  updated_at: string
}

export type Notification = {
  id: string
  user_id: string
  type: string
  content: string
  is_read: boolean
  created_at: string
}

export type NotificationSetting = {
  id: string
  user_id: string
  email_enabled: boolean
  whatsapp_enabled: boolean
  whatsapp_number?: string
  frequency: "instant" | "daily" | "weekly"
  created_at: string
  updated_at: string
}

